# Maquettes d'interface utilisateur pour la plateforme de bilans de compétences

## Introduction

Ce document présente les maquettes d'interface utilisateur pour la plateforme de gestion des bilans de compétences. Ces maquettes illustrent les principales interfaces et flux d'utilisation pour les trois types d'utilisateurs : administrateurs, consultants et bénéficiaires.

## Structure générale de l'interface

L'interface utilisateur suivra une structure cohérente avec :

- Une barre de navigation principale en haut
- Un menu latéral à gauche (rétractable sur mobile)
- Une zone de contenu principale
- Un pied de page avec informations légales et liens utiles

Le design sera responsive pour s'adapter à tous les appareils (ordinateurs, tablettes, smartphones).

## Charte graphique

### Palette de couleurs
- **Couleur principale** : Bleu professionnel (#2563EB)
- **Couleur secondaire** : Vert apaisant (#10B981)
- **Couleur d'accentuation** : Orange dynamique (#F59E0B)
- **Couleurs neutres** : Gris clair (#F3F4F6), Gris moyen (#9CA3AF), Gris foncé (#4B5563)
- **Couleurs sémantiques** : Succès (#22C55E), Erreur (#EF4444), Avertissement (#F59E0B), Information (#3B82F6)

### Typographie
- **Titres** : Montserrat, sans-serif
- **Corps de texte** : Open Sans, sans-serif
- **Hiérarchie des tailles** : 
  - H1: 24px
  - H2: 20px
  - H3: 18px
  - Corps: 16px
  - Petit texte: 14px

### Composants UI
- Boutons arrondis avec effets de survol
- Cartes avec ombres légères
- Icônes cohérentes (utilisation de la bibliothèque Font Awesome ou Material Icons)
- Formulaires avec validation visuelle

## Maquettes par type d'utilisateur

### 1. Interfaces communes

#### 1.1 Page de connexion

```
┌─────────────────────────────────────────────────────────┐
│                                                         │
│                  [Logo de la plateforme]                │
│                                                         │
│                  Connexion à la plateforme              │
│                                                         │
│   ┌─────────────────────────────────────────────────┐   │
│   │ Adresse email                                   │   │
│   └─────────────────────────────────────────────────┘   │
│                                                         │
│   ┌─────────────────────────────────────────────────┐   │
│   │ Mot de passe                            [👁️]    │   │
│   └─────────────────────────────────────────────────┘   │
│                                                         │
│   [✓] Se souvenir de moi     [Mot de passe oublié ?]    │
│                                                         │
│   ┌─────────────────────────────────────────────────┐   │
│   │                  Se connecter                    │   │
│   └─────────────────────────────────────────────────┘   │
│                                                         │
│   Vous n'avez pas de compte ? [Créer un compte]         │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

#### 1.2 Page d'accueil après connexion

```
┌─────────────────────────────────────────────────────────┐
│ [Logo] Plateforme Bilan de Compétences    [🔔] [👤▼]    │
├─────────┬───────────────────────────────────────────────┤
│         │                                               │
│  Menu   │           Bienvenue, [Nom Utilisateur]        │
│         │                                               │
│ [📊]    │  ┌─────────────┐  ┌─────────────┐  ┌─────────┐│
│ Tableau │  │             │  │             │  │         ││
│ de bord │  │  Bilans     │  │  Rendez-vous│  │ Messages││
│         │  │  en cours   │  │  à venir    │  │ non lus ││
│ [👥]    │  │             │  │             │  │         ││
│ Bénéfi- │  │    12       │  │     3       │  │    5    ││
│ ciaires │  │             │  │             │  │         ││
│         │  └─────────────┘  └─────────────┘  └─────────┘│
│ [📅]    │                                               │
│ Rendez- │  Activité récente                             │
│ vous    │  ┌───────────────────────────────────────────┐│
│         │  │ • Nouveau bilan démarré avec Jean Dupont  ││
│ [📝]    │  │ • RDV confirmé avec Marie Martin          ││
│ Bilans  │  │ • Document de synthèse généré pour...     ││
│         │  │ • Test de personnalité complété par...    ││
│ [📊]    │  └───────────────────────────────────────────┘│
│ Outils  │                                               │
│         │  Tâches à effectuer                           │
│ [📁]    │  ┌───────────────────────────────────────────┐│
│ Documents│  │ • Valider le document de synthèse de...  ││
│         │  │ • Préparer l'entretien avec...            ││
│ [⚙️]     │  │ • Rappeler le RDV à...                    ││
│ Paramètres│ └───────────────────────────────────────────┘│
│         │                                               │
└─────────┴───────────────────────────────────────────────┘
```

### 2. Interfaces pour les administrateurs

#### 2.1 Tableau de bord administrateur

```
┌─────────────────────────────────────────────────────────┐
│ [Logo] Plateforme Bilan de Compétences    [🔔] [👤▼]    │
├─────────┬───────────────────────────────────────────────┤
│         │                                               │
│  Menu   │           Tableau de bord administrateur      │
│         │                                               │
│ [📊]    │  ┌─────────────┐  ┌─────────────┐  ┌─────────┐│
│ Tableau │  │             │  │             │  │         ││
│ de bord │  │  Bilans     │  │ Consultants │  │ Bénéfi- ││
│         │  │  actifs     │  │  actifs     │  │ ciaires ││
│ [👥]    │  │             │  │             │  │         ││
│ Utilisa-│  │    45       │  │     8       │  │   52    ││
│ teurs   │  │             │  │             │  │         ││
│         │  └─────────────┘  └─────────────┘  └─────────┘│
│ [📊]    │                                               │
│ Bilans  │  Statistiques                                 │
│         │  ┌───────────────────────────────────────────┐│
│ [💰]    │  │                                           ││
│ Finance │  │         [Graphique d'activité]            ││
│         │  │                                           ││
│ [📈]    │  └───────────────────────────────────────────┘│
│ Rapports│                                               │
│         │  Dernières activités                          │
│ [🔧]    │  ┌───────────────────────────────────────────┐│
│ Config. │  │ • Nouveau consultant ajouté: P. Martin    ││
│         │  │ • Bilan #45 terminé                       ││
│ [⚙️]     │  │ • Facture #123 générée                    ││
│ Paramètres│ └───────────────────────────────────────────┘│
│         │                                               │
└─────────┴───────────────────────────────────────────────┘
```

#### 2.2 Gestion des utilisateurs

```
┌─────────────────────────────────────────────────────────┐
│ [Logo] Plateforme Bilan de Compétences    [🔔] [👤▼]    │
├─────────┬───────────────────────────────────────────────┤
│         │                                               │
│  Menu   │           Gestion des utilisateurs            │
│         │                                               │
│ [...]   │  [+ Ajouter un utilisateur]  [🔍 Rechercher]  │
│         │                                               │
│         │  Filtres: [Tous ▼] [Actifs ▼] [Rôle ▼]        │
│         │                                               │
│         │  ┌─────────────────────────────────────────┐  │
│         │  │ Nom    | Email       | Rôle    | Actions│  │
│         │  ├─────────────────────────────────────────┤  │
│         │  │ Dupont | j.d@...     | Consult.| [⚙️][🗑️] │  │
│         │  │ Martin | m.m@...     | Bénéf.  | [⚙️][🗑️] │  │
│         │  │ Dubois | p.d@...     | Admin   | [⚙️][🗑️] │  │
│         │  │ ...    | ...         | ...     | ...    │  │
│         │  └─────────────────────────────────────────┘  │
│         │                                               │
│         │  Affichage: 1-10 sur 52  [< 1 2 3 ... >]      │
│         │                                               │
└─────────┴───────────────────────────────────────────────┘
```

### 3. Interfaces pour les consultants

#### 3.1 Liste des bénéficiaires

```
┌─────────────────────────────────────────────────────────┐
│ [Logo] Plateforme Bilan de Compétences    [🔔] [👤▼]    │
├─────────┬───────────────────────────────────────────────┤
│         │                                               │
│  Menu   │           Mes bénéficiaires                   │
│         │                                               │
│ [...]   │  [+ Ajouter un bénéficiaire]  [🔍 Rechercher] │
│         │                                               │
│         │  Filtres: [Tous ▼] [Statut ▼] [Phase ▼]       │
│         │                                               │
│         │  ┌─────────────────────────────────────────┐  │
│         │  │ Nom    | Statut | Phase  | Début  |Actions│
│         │  ├─────────────────────────────────────────┤  │
│         │  │ Dupont | Actif  | Invest.| 12/03  |[👁️][📝]│
│         │  │ Martin | Actif  | Prélim.| 02/04  |[👁️][📝]│
│         │  │ Dubois | Terminé| Conclu.| 15/01  |[👁️][📝]│
│         │  │ ...    | ...    | ...    | ...    | ...  │  │
│         │  └─────────────────────────────────────────┘  │
│         │                                               │
│         │  Affichage: 1-10 sur 25  [< 1 2 3 ... >]      │
│         │                                               │
└─────────┴───────────────────────────────────────────────┘
```

#### 3.2 Fiche bénéficiaire

```
┌─────────────────────────────────────────────────────────┐
│ [Logo] Plateforme Bilan de Compétences    [🔔] [👤▼]    │
├─────────┬───────────────────────────────────────────────┤
│         │                                               │
│  Menu   │  < Retour   Fiche bénéficiaire: Jean Dupont   │
│         │                                               │
│ [...]   │  ┌─────────┐ [📝 Modifier] [📅 Planifier RDV]  │
│         │  │         │                                  │
│         │  │   👤    │ Statut: Actif                    │
│         │  │         │ Phase: Investigation             │
│         │  └─────────┘ Début: 12/03/2025                │
│         │                                               │
│         │  Onglets: [Infos] [Bilans] [Documents] [Notes]│
│         │                                               │
│         │  Informations personnelles                    │
│         │  ┌───────────────────────────────────────────┐│
│         │  │ Email: jean.dupont@email.com              ││
│         │  │ Téléphone: 06 12 34 56 78                 ││
│         │  │ Adresse: 123 rue Example, 75000 Paris     ││
│         │  │ Situation: Salarié                        ││
│         │  │ Entreprise: Société ABC                   ││
│         │  │ Financement: CPF                          ││
│         │  └───────────────────────────────────────────┘│
│         │                                               │
│         │  Prochains rendez-vous                        │
│         │  ┌───────────────────────────────────────────┐│
│         │  │ 18/04/2025 - 14:00 - Phase d'investigation││
│         │  │ 25/04/2025 - 10:00 - Phase d'investigation││
│         │  └───────────────────────────────────────────┘│
│         │                                               │
└─────────┴───────────────────────────────────────────────┘
```

#### 3.3 Planification des rendez-vous

```
┌─────────────────────────────────────────────────────────┐
│ [Logo] Plateforme Bilan de Compétences    [🔔] [👤▼]    │
├─────────┬───────────────────────────────────────────────┤
│         │                                               │
│  Menu   │           Planification des rendez-vous       │
│         │                                               │
│ [...]   │  [+ Nouveau RDV]  [Vue: Jour▼] [< Avril 2025 >]│
│         │                                               │
│         │  ┌───────────────────────────────────────────┐│
│         │  │                                           ││
│         │  │             [Calendrier]                  ││
│         │  │                                           ││
│         │  │                                           ││
│         │  │                                           ││
│         │  └───────────────────────────────────────────┘│
│         │                                               │
│         │  Prochains rendez-vous                        │
│         │  ┌───────────────────────────────────────────┐│
│         │  │ 15/04 - 09:00 - Marie Martin - Phase prél.││
│         │  │ 15/04 - 14:00 - Paul Dubois - Phase invest││
│         │  │ 18/04 - 14:00 - Jean Dupont - Phase invest││
│         │  └───────────────────────────────────────────┘│
│         │                                               │
└─────────┴───────────────────────────────────────────────┘
```

#### 3.4 Interface d'évaluation

```
┌─────────────────────────────────────────────────────────┐
│ [Logo] Plateforme Bilan de Compétences    [🔔] [👤▼]    │
├─────────┬───────────────────────────────────────────────┤
│         │                                               │
│  Menu   │  < Retour   Outils d'évaluation               │
│         │                                               │
│ [...]   │  Bénéficiaire: Jean Dupont                    │
│         │                                               │
│         │  ┌───────────────────────────────────────────┐│
│         │  │ ✓ Questionnaire d'auto-évaluation         ││
│         │  │ ✓ Test de personnalité                    ││
│         │  │ ► Grille d'analyse des compétences        ││
│         │  │ ○ Outil de projection professionnelle     ││
│         │  └───────────────────────────────────────────┘│
│         │                                               │
│         │  Grille d'analyse des compétences             │
│         │  ┌───────────────────────────────────────────┐│
│         │  │                                           ││
│         │  │ [Formulaire de la grille d'analyse]       ││
│         │  │                                           ││
│         │  │                                           ││
│         │  │                                           ││
│         │  │                                           ││
│         │  │                                           ││
│         │  │ [Enregistrer] [Enregistrer et continuer]  ││
│         │  └───────────────────────────────────────────┘│
│         │                                               │
└─────────┴───────────────────────────────────────────────┘
```

### 4. Interfaces pour les bénéficiaires

#### 4.1 Tableau de bord bénéficiaire

```
┌─────────────────────────────────────────────────────────┐
│ [Logo] Plateforme Bilan de Compétences    [🔔] [👤▼]    │
├─────────┬───────────────────────────────────────────────┤
│         │                                               │
│  Menu   │           Mon bilan de compétences            │
│         │                                               │
│ [📊]    │  ┌─────────────────────────────────────────┐  │
│ Tableau │  │ Progression du bilan                    │  │
│ de bord │  │                                         │  │
│         │  │ [Barre de progression: 45%]             │  │
│ [📅]    │  │                                         │  │
│ Rendez- │  │ Phase actuelle: Investigation           │  │
│ vous    │  └─────────────────────────────────────────┘  │
│         │                                               │
│ [📝]    │  Prochain rendez-vous                         │
│ Mes     │  ┌─────────────────────────────────────────┐  │
│ tests   │  │ 18/04/2025 - 14:00                      │  │
│         │  │ Phase d'investigation                   │  │
│ [📁]    │  │ Avec: Sophie Martin (Consultante)       │  │
│ Documents│  │ [Confirmer] [Modifier] [Visioconférence]│  │
│         │  └─────────────────────────────────────────┘  │
│ [💬]    │                                               │
│ Messages│  Tests à compléter                            │
│         │  ┌─────────────────────────────────────────┐  │
│ [⚙️]     │  │ • Test de personnalité [Commencer]      │  │
│ Paramètres│ │ • Questionnaire d'intérêts [Commencer]  │  │
│         │  └─────────────────────────────────────────┘  │
│         │                                               │
└─────────┴───────────────────────────────────────────────┘
```

#### 4.2 Interface de test en ligne

```
┌─────────────────────────────────────────────────────────┐
│ [Logo] Plateforme Bilan de Compétences    [🔔] [👤▼]    │
├─────────┬───────────────────────────────────────────────┤
│         │                                               │
│  Menu   │  < Retour   Test de personnalité              │
│         │                                               │
│ [...]   │  Progression: [Barre: 40%] Question 8/20      │
│         │                                               │
│         │  ┌───────────────────────────────────────────┐│
│         │  │                                           ││
│         │  │ Question 8:                               ││
│         │  │ Face à un problème complexe, vous préférez:││
│         │  │                                           ││
│         │  │ ○ A. Analyser méthodiquement toutes les   ││
│         │  │      options avant de prendre une décision││
│         │  │                                           ││
│         │  │ ○ B. Vous fier à votre intuition et       ││
│         │  │      trouver une solution créative        ││
│         │  │                                           ││
│         │  │                                           ││
│         │  │ [Question précédente]    [Question suivante]││
│         │  └───────────────────────────────────────────┘│
│         │                                               │
│         │  Vous pouvez interrompre le test et le        │
│         │  reprendre plus tard. Vos réponses sont       │
│         │  automatiquement enregistrées.                │
│         │                                               │
└─────────┴───────────────────────────────────────────────┘
```

#### 4.3 Visualisation des résultats

```
┌─────────────────────────────────────────────────────────┐
│ [Logo] Plateforme Bilan de Compétences    [🔔] [👤▼]    │
├─────────┬───────────────────────────────────────────────┤
│         │                                               │
│  Menu   │  < Retour   Résultats du test de personnalité │
│         │                                               │
│ [...]   │  ┌───────────────────────────────────────────┐│
│         │  │                                           ││
│         │  │ [Graphique radar des traits de personnalité]││
│         │  │                                           ││
│         │  └───────────────────────────────────────────┘│
│         │                                               │
│         │  Vos traits dominants                         │
│         │  ┌───────────────────────────────────────────┐│
│         │  │ • Analytique (85%)                        ││
│         │  │ • Organisé (78%)                          ││
│         │  │ • Collaboratif (72%)                      ││
│         │  └───────────────────────────────────────────┘│
│         │                                               │
│         │  Interprétation des résultats                 │
│         │  ┌───────────────────────────────────────────┐│
│         │  │ Votre profil indique une préférence pour  ││
│         │  │ les environnements structurés où vous     ││
│         │  │ pouvez analyser des informations et       ││
│         │  │ travailler en équipe...                   ││
│         │  └───────────────────────────────────────────┘│
│         │                                               │
│         │  [Télécharger en PDF] [Partager avec consultant]│
│         │                                               │
└─────────┴───────────────────────────────────────────────┘
```

### 5. Interfaces de communication

#### 5.1 Messagerie interne

```
┌─────────────────────────────────────────────────────────┐
│ [Logo] Plateforme Bilan de Compétences    [🔔] [👤▼]    │
├─────────┬───────────────────────────────────────────────┤
│         │                                               │
│  Menu   │           Messagerie                          │
│         │                                               │
│ [...]   │  [+ Nouveau message]  [🔍 Rechercher]          │
│         │                                               │
│         │  ┌─────────┬───────────────────────────────┐  │
│         │  │ Contacts│ Sophie Martin                 │  │
│         │  │         │ Consultante                   │  │
│         │  │ ● Sophie│                               │  │
│         │  │  Martin │ Bonjour Jean,                 │  │
│         │  │         │                               │  │
│         │  │ ○ Admin │ Suite à notre dernier rendez- │  │
│         │  │  Support│ vous, je vous envoie comme    │  │
│         │  │         │ convenu les ressources sur    │  │
│         │  │         │ les métiers du marketing      │  │
│         │  │         │ digital.                      │  │
│         │  │         │                               │  │
│         │  │         │ Vous trouverez en pièce jointe│  │
│         │  │         │ un document récapitulatif.    │  │
│         │  │         │                               │  │
│         │  │         │ [📎 marketing_digital.pdf]    │  │
│         │  │         │                               │  │
│         │  │         │ 15/04/2025 - 10:23            │  │
│         │  └─────────┴───────────────────────────────┘  │
│         │                                               │
│         │  ┌───────────────────────────────────────────┐│
│         │  │ Répondre...                         [📎]  ││
│         │  └───────────────────────────────────────────┘│
│         │                                               │
└─────────┴───────────────────────────────────────────────┘
```

### 6. Interfaces de génération de documents

#### 6.1 Génération de document de synthèse

```
┌─────────────────────────────────────────────────────────┐
│ [Logo] Plateforme Bilan de Compétences    [🔔] [👤▼]    │
├─────────┬───────────────────────────────────────────────┤
│         │                                               │
│  Menu   │  < Retour   Génération de document de synthèse│
│         │                                               │
│ [...]   │  Bénéficiaire: Jean Dupont                    │
│         │                                               │
│         │  ┌───────────────────────────────────────────┐│
│         │  │ Sections du document                      ││
│         │  │                                           ││
│         │  │ ✓ Informations personnelles              ││
│         │  │ ✓ Circonstances du bilan                 ││
│         │  │ ✓ Compétences identifiées                ││
│         │  │ ✓ Projet professionnel                   ││
│         │  │ ✓ Plan d'action                          ││
│         │  │ ○ Préconisations du consultant           ││
│         │  │ ○ Conclusions du bénéficiaire            ││
│         │  └───────────────────────────────────────────┘│
│         │                                               │
│         │  Préconisations du consultant                 │
│         │  ┌───────────────────────────────────────────┐│
│         │  │                                           ││
│         │  │ [Éditeur de texte riche]                 ││
│         │  │                                           ││
│         │  │                                           ││
│         │  └───────────────────────────────────────────┘│
│         │                                               │
│         │  [Enregistrer brouillon] [Aperçu] [Générer PDF]│
│         │                                               │
└─────────┴───────────────────────────────────────────────┘
```

## Flux utilisateur principaux

### 1. Flux d'inscription et première connexion (bénéficiaire)

1. Page d'accueil publique
2. Formulaire d'inscription
3. Confirmation par email
4. Première connexion
5. Complétion du profil
6. Questionnaire initial
7. Tableau de bord bénéficiaire

### 2. Flux de réalisation d'un bilan (consultant)

1. Création d'un nouveau bénéficiaire
2. Planification du premier rendez-vous
3. Phase préliminaire (entretiens et documents)
4. Assignation des tests et questionnaires
5. Phase d'investigation (entretiens et analyse)
6. Élaboration du projet professionnel
7. Phase de conclusions
8. Génération du document de synthèse
9. Planification du suivi à 6 mois

### 3. Flux de réalisation des tests (bénéficiaire)

1. Connexion au tableau de bord
2. Accès à la section "Mes tests"
3. Sélection du test à réaliser
4. Lecture des instructions
5. Réalisation du test
6. Soumission des réponses
7. Visualisation des résultats
8. Partage avec le consultant

## Considérations d'accessibilité

- Contraste suffisant entre texte et fond
- Taille de texte ajustable
- Navigation au clavier possible
- Textes alternatifs pour les images
- Structure sémantique pour les lecteurs d'écran
- Messages d'erreur clairs et explicites
- Temps suffisant pour compléter les formulaires

## Prochaines étapes

1. Validation des maquettes avec les parties prenantes
2. Création de prototypes interactifs
3. Tests utilisateurs
4. Ajustements basés sur les retours
5. Développement frontend
6. Tests d'accessibilité
7. Intégration avec le backend
