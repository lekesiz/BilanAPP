# Guide d'utilisation de la plateforme de gestion des bilans de compétences

## Introduction

Bienvenue sur la plateforme de gestion des bilans de compétences. Cette application a été conçue pour vous permettre de réaliser et gérer des bilans de compétences dans le respect total des exigences Qualiopi et de la législation en vigueur.

Ce guide vous aidera à prendre en main la plateforme et à utiliser toutes ses fonctionnalités.

## Table des matières

1. [Connexion à la plateforme](#connexion-à-la-plateforme)
2. [Tableau de bord](#tableau-de-bord)
3. [Gestion des bénéficiaires](#gestion-des-bénéficiaires)
4. [Réalisation des bilans de compétences](#réalisation-des-bilans-de-compétences)
5. [Outils d'évaluation](#outils-dévaluation)
6. [Génération de documents](#génération-de-documents)
7. [Intégration avec Google Workspace](#intégration-avec-google-workspace)
8. [Intégration avec Pennylane](#intégration-avec-pennylane)
9. [Paramètres de sécurité et confidentialité](#paramètres-de-sécurité-et-confidentialité)
10. [Support technique](#support-technique)

## Connexion à la plateforme

Pour accéder à la plateforme, rendez-vous sur l'URL fournie par votre administrateur et utilisez vos identifiants de connexion.

Si vous utilisez Google Workspace, vous pouvez également vous connecter avec votre compte Google en cliquant sur le bouton "Se connecter avec Google".

## Tableau de bord

Le tableau de bord est la page d'accueil de la plateforme. Il vous donne une vue d'ensemble de votre activité :

- Bilans en cours
- Rendez-vous à venir
- Tâches à réaliser
- Statistiques d'activité

Vous pouvez personnaliser votre tableau de bord en cliquant sur le bouton "Personnaliser" en haut à droite.

## Gestion des bénéficiaires

### Ajouter un nouveau bénéficiaire

1. Cliquez sur "Bénéficiaires" dans le menu principal
2. Cliquez sur le bouton "Ajouter un bénéficiaire"
3. Remplissez le formulaire avec les informations du bénéficiaire
4. Cliquez sur "Enregistrer"

### Consulter la fiche d'un bénéficiaire

1. Cliquez sur "Bénéficiaires" dans le menu principal
2. Utilisez la barre de recherche pour trouver le bénéficiaire souhaité
3. Cliquez sur le nom du bénéficiaire pour accéder à sa fiche

La fiche bénéficiaire est organisée en onglets :
- Informations générales
- Rendez-vous
- Évaluations
- Documents
- Projet professionnel

### Modifier les informations d'un bénéficiaire

1. Accédez à la fiche du bénéficiaire
2. Cliquez sur le bouton "Modifier" en haut à droite
3. Modifiez les informations souhaitées
4. Cliquez sur "Enregistrer"

## Réalisation des bilans de compétences

### Créer un nouveau bilan

1. Accédez à la fiche du bénéficiaire
2. Cliquez sur l'onglet "Bilans"
3. Cliquez sur "Nouveau bilan"
4. Sélectionnez le type de bilan (standard, approfondi, spécifique)
5. Définissez les dates de début et de fin prévisionnelles
6. Cliquez sur "Créer"

### Planifier les rendez-vous

1. Accédez à la fiche du bénéficiaire
2. Cliquez sur l'onglet "Rendez-vous"
3. Cliquez sur "Nouveau rendez-vous"
4. Sélectionnez la date, l'heure et la durée
5. Choisissez le type de rendez-vous (présentiel ou visioconférence)
6. Ajoutez une description si nécessaire
7. Cliquez sur "Planifier"

Les rendez-vous sont automatiquement synchronisés avec votre Google Calendar.

### Suivre l'avancement du bilan

1. Accédez à la fiche du bénéficiaire
2. Cliquez sur l'onglet "Bilans"
3. Sélectionnez le bilan en cours
4. Consultez l'avancement des différentes phases
5. Utilisez le bouton "Mettre à jour le statut" pour actualiser l'avancement

## Outils d'évaluation

### Assigner une évaluation à un bénéficiaire

1. Accédez à la fiche du bénéficiaire
2. Cliquez sur l'onglet "Évaluations"
3. Cliquez sur "Assigner une évaluation"
4. Sélectionnez l'évaluation dans la liste
5. Définissez une date limite si nécessaire
6. Cliquez sur "Assigner"

Le bénéficiaire recevra un email avec un lien pour compléter l'évaluation.

### Créer une nouvelle évaluation

1. Cliquez sur "Évaluations" dans le menu principal
2. Cliquez sur "Créer une évaluation"
3. Donnez un titre et une description à l'évaluation
4. Ajoutez des sections et des questions
5. Configurez les paramètres d'analyse des résultats
6. Cliquez sur "Enregistrer"

### Consulter les résultats d'une évaluation

1. Accédez à la fiche du bénéficiaire
2. Cliquez sur l'onglet "Évaluations"
3. Sélectionnez l'évaluation complétée
4. Consultez les résultats détaillés
5. Utilisez les outils d'analyse pour interpréter les résultats

## Génération de documents

### Générer un document

1. Accédez à la fiche du bénéficiaire
2. Cliquez sur l'onglet "Documents"
3. Cliquez sur "Générer un document"
4. Sélectionnez le type de document :
   - Document d'information préalable
   - Convention tripartite
   - Document de synthèse
   - Rapport d'évaluation
   - Facture
5. Complétez les informations requises
6. Cliquez sur "Générer"

### Gérer les documents

Une fois le document généré, vous pouvez :
- Le prévisualiser
- Le télécharger au format PDF
- L'envoyer par email au bénéficiaire
- L'imprimer

Tous les documents sont automatiquement sauvegardés dans Google Drive.

## Intégration avec Google Workspace

La plateforme est intégrée avec Google Workspace pour faciliter votre travail :

### Google Calendar

- Synchronisation automatique des rendez-vous
- Création de liens Google Meet pour les visioconférences
- Notifications et rappels de rendez-vous

### Google Drive

- Stockage sécurisé des documents
- Organisation automatique par dossiers (un dossier par bénéficiaire)
- Partage contrôlé des documents

### Google Meet

- Création automatique de liens de visioconférence
- Intégration directe dans les rendez-vous
- Enregistrement des sessions (avec consentement du bénéficiaire)

## Intégration avec Pennylane

La plateforme est intégrée avec Pennylane pour la gestion financière :

### Facturation

- Création automatique des factures
- Suivi des paiements
- Gestion des avoirs et remboursements

### Suivi financier

- Tableau de bord financier
- Rapports de revenus
- Suivi des financements (CPF, OPCO, etc.)

### Comptabilité

- Synchronisation avec votre comptabilité
- Export des données comptables
- Gestion de la TVA

## Paramètres de sécurité et confidentialité

### Gestion des préférences de confidentialité

1. Cliquez sur votre nom en haut à droite
2. Sélectionnez "Paramètres"
3. Cliquez sur l'onglet "Sécurité et confidentialité"
4. Configurez vos préférences de confidentialité
5. Cliquez sur "Enregistrer"

### Sécurité du compte

Dans la section "Sécurité du compte", vous pouvez :
- Changer votre mot de passe
- Activer l'authentification à deux facteurs
- Consulter l'historique des connexions

### Gestion des données personnelles

Dans la section "Données personnelles", vous pouvez :
- Exporter vos données (droit à la portabilité)
- Supprimer votre compte (droit à l'oubli)

## Support technique

Si vous rencontrez des difficultés ou avez des questions, plusieurs options s'offrent à vous :

- Consultez la FAQ en cliquant sur "Aide" dans le menu principal
- Contactez le support technique par email à support@votre-domaine.com
- Utilisez le chat en direct disponible en bas à droite de l'écran

---

Ce guide est régulièrement mis à jour pour refléter les dernières fonctionnalités de la plateforme. Dernière mise à jour : Avril 2025.
