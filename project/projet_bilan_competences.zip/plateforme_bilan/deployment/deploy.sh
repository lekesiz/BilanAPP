#!/bin/bash

# Script de déploiement pour la plateforme de gestion des bilans de compétences

# Couleurs pour les messages
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Fonction pour afficher les messages
log() {
  echo -e "${GREEN}[INFO]${NC} $1"
}

warn() {
  echo -e "${YELLOW}[WARN]${NC} $1"
}

error() {
  echo -e "${RED}[ERROR]${NC} $1"
  exit 1
}

# Vérifier si Docker est installé
if ! command -v docker &> /dev/null; then
  error "Docker n'est pas installé. Veuillez l'installer avant de continuer."
fi

# Vérifier si Docker Compose est installé
if ! command -v docker-compose &> /dev/null; then
  error "Docker Compose n'est pas installé. Veuillez l'installer avant de continuer."
fi

# Créer le fichier .env s'il n'existe pas
if [ ! -f .env ]; then
  log "Création du fichier .env..."
  cat > .env << EOF
# Variables d'environnement pour le déploiement
DB_PASSWORD=changeme
JWT_SECRET=changeme
ENCRYPTION_KEY=changeme
GOOGLE_CLIENT_ID=your-google-client-id
GOOGLE_CLIENT_SECRET=your-google-client-secret
PENNYLANE_API_KEY=your-pennylane-api-key
EOF
  warn "Un fichier .env par défaut a été créé. Veuillez le modifier avec vos propres valeurs avant de continuer."
  exit 0
fi

# Créer les répertoires nécessaires
log "Création des répertoires pour Nginx..."
mkdir -p nginx/conf.d
mkdir -p nginx/ssl
mkdir -p nginx/logs

# Copier les fichiers de configuration Nginx
log "Copie des fichiers de configuration Nginx..."
cp nginx/frontend.conf nginx/conf.d/
cp nginx/backend.conf nginx/conf.d/

# Construire et démarrer les conteneurs
log "Construction et démarrage des conteneurs Docker..."
docker-compose build || error "Échec de la construction des conteneurs Docker"
docker-compose up -d || error "Échec du démarrage des conteneurs Docker"

# Vérifier que tous les conteneurs sont en cours d'exécution
log "Vérification de l'état des conteneurs..."
if [ "$(docker-compose ps --services --filter "status=running" | wc -l)" -ne "$(docker-compose ps --services | wc -l)" ]; then
  warn "Certains conteneurs ne sont pas en cours d'exécution. Vérifiez les journaux avec 'docker-compose logs'."
else
  log "Tous les conteneurs sont en cours d'exécution."
fi

# Afficher les URL d'accès
log "Déploiement terminé avec succès!"
log "Frontend accessible à l'adresse: http://localhost:3000"
log "Backend accessible à l'adresse: http://localhost:5000"
log "Pour arrêter les conteneurs, exécutez: docker-compose down"
