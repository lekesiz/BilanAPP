#!/bin/bash

# Script de test pour la plateforme de gestion des bilans de compétences

# Couleurs pour les messages
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Fonction pour afficher les messages
log() {
  echo -e "${GREEN}[INFO]${NC} $1"
}

warn() {
  echo -e "${YELLOW}[WARN]${NC} $1"
}

error() {
  echo -e "${RED}[ERROR]${NC} $1"
  exit 1
}

# Vérifier si les conteneurs sont en cours d'exécution
log "Vérification de l'état des conteneurs..."
if [ "$(docker-compose ps --services --filter "status=running" | wc -l)" -ne "$(docker-compose ps --services | wc -l)" ]; then
  error "Tous les conteneurs ne sont pas en cours d'exécution. Veuillez démarrer les conteneurs avec './deploy.sh'."
fi

# Test du backend
log "Test du backend..."
BACKEND_STATUS=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:5000/api/health)
if [ "$BACKEND_STATUS" -eq 200 ]; then
  log "Backend OK (HTTP 200)"
else
  error "Backend KO (HTTP $BACKEND_STATUS)"
fi

# Test du frontend
log "Test du frontend..."
FRONTEND_STATUS=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:3000)
if [ "$FRONTEND_STATUS" -eq 200 ]; then
  log "Frontend OK (HTTP 200)"
else
  error "Frontend KO (HTTP $FRONTEND_STATUS)"
fi

# Test de la base de données
log "Test de la connexion à la base de données..."
DB_TEST=$(docker-compose exec -T database pg_isready -h localhost -p 5432)
if [[ $DB_TEST == *"accepting connections"* ]]; then
  log "Base de données OK"
else
  error "Base de données KO"
fi

# Test de Redis
log "Test de la connexion à Redis..."
REDIS_TEST=$(docker-compose exec -T redis redis-cli ping)
if [ "$REDIS_TEST" == "PONG" ]; then
  log "Redis OK"
else
  error "Redis KO"
fi

# Test des fonctionnalités principales
log "Test des fonctionnalités principales..."

# Test de l'authentification
log "Test de l'authentification..."
AUTH_TEST=$(curl -s -X POST -H "Content-Type: application/json" -d '{"email":"test@example.com","password":"password123"}' http://localhost:5000/api/auth/login)
if [[ $AUTH_TEST == *"token"* ]]; then
  log "Authentification OK"
else
  warn "Authentification KO - Vérifiez les identifiants de test"
fi

# Test de la création d'un bénéficiaire
log "Test de la création d'un bénéficiaire..."
TOKEN=$(echo $AUTH_TEST | grep -o '"token":"[^"]*' | sed 's/"token":"//')
BENEFICIAIRE_TEST=$(curl -s -X POST -H "Content-Type: application/json" -H "Authorization: Bearer $TOKEN" -d '{"nom":"Dupont","prenom":"Jean","email":"jean.dupont@example.com"}' http://localhost:5000/api/beneficiaires)
if [[ $BENEFICIAIRE_TEST == *"id"* ]]; then
  log "Création de bénéficiaire OK"
else
  warn "Création de bénéficiaire KO"
fi

# Test de la génération de document
log "Test de la génération de document..."
DOCUMENT_TEST=$(curl -s -X POST -H "Content-Type: application/json" -H "Authorization: Bearer $TOKEN" -d '{"type":"information","beneficiaireId":"1"}' http://localhost:5000/api/documents/generate)
if [[ $DOCUMENT_TEST == *"success"* ]]; then
  log "Génération de document OK"
else
  warn "Génération de document KO"
fi

# Test de performance
log "Test de performance..."
PERF_TEST=$(ab -n 100 -c 10 http://localhost:3000/ 2>&1)
if [[ $PERF_TEST == *"Failed requests:     0"* ]]; then
  log "Test de performance OK"
else
  warn "Test de performance KO - Vérifiez les performances"
fi

# Test de sécurité
log "Test de sécurité basique..."
SECURITY_TEST=$(curl -s -I http://localhost:3000 | grep -E 'X-Content-Type-Options|X-Frame-Options|X-XSS-Protection|Content-Security-Policy')
if [ -n "$SECURITY_TEST" ]; then
  log "En-têtes de sécurité OK"
else
  warn "En-têtes de sécurité KO - Vérifiez la configuration de sécurité"
fi

# Résumé des tests
log "Tests terminés!"
log "Résumé des tests:"
log "- Backend: OK"
log "- Frontend: OK"
log "- Base de données: OK"
log "- Redis: OK"
log "- Fonctionnalités principales: Vérifiez les avertissements éventuels"

log "Pour des tests plus approfondis, utilisez des outils comme Jest, Cypress ou Postman."
