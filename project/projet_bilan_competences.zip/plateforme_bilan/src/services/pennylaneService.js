// Service d'intégration avec Pennylane
import axios from 'axios';

// Configuration de l'API Pennylane
const API_BASE_URL = process.env.PENNYLANE_API_URL;
const API_KEY = process.env.PENNYLANE_API_KEY;

// Configuration du client axios
const pennylaneClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Authorization': `Bearer ${API_KEY}`,
    'Content-Type': 'application/json'
  }
});

// Gestion des erreurs
const handleApiError = (error) => {
  if (error.response) {
    // La requête a été faite et le serveur a répondu avec un code d'état
    // qui n'est pas dans la plage 2xx
    throw new Error(`Erreur Pennylane: ${error.response.status} - ${error.response.data.message || JSON.stringify(error.response.data)}`);
  } else if (error.request) {
    // La requête a été faite mais aucune réponse n'a été reçue
    throw new Error('Aucune réponse reçue de Pennylane');
  } else {
    // Une erreur s'est produite lors de la configuration de la requête
    throw new Error(`Erreur de configuration: ${error.message}`);
  }
};

// Créer un client dans Pennylane
const createClient = async (clientData) => {
  try {
    const response = await pennylaneClient.post('/customers', {
      first_name: clientData.prenom,
      last_name: clientData.nom,
      email: clientData.email,
      phone: clientData.telephone,
      address: {
        street: clientData.adresse?.rue,
        postal_code: clientData.adresse?.codePostal,
        city: clientData.adresse?.ville,
        country: clientData.adresse?.pays || 'FR'
      },
      company_name: clientData.entrepriseActuelle,
      tax_id: clientData.siret || null,
      payment_conditions: 'upon_receipt',
      currency: 'EUR',
      language: 'fr'
    });
    
    return response.data;
  } catch (error) {
    handleApiError(error);
  }
};

// Mettre à jour un client dans Pennylane
const updateClient = async (clientId, clientData) => {
  try {
    const response = await pennylaneClient.put(`/customers/${clientId}`, {
      first_name: clientData.prenom,
      last_name: clientData.nom,
      email: clientData.email,
      phone: clientData.telephone,
      address: {
        street: clientData.adresse?.rue,
        postal_code: clientData.adresse?.codePostal,
        city: clientData.adresse?.ville,
        country: clientData.adresse?.pays || 'FR'
      },
      company_name: clientData.entrepriseActuelle,
      tax_id: clientData.siret || null
    });
    
    return response.data;
  } catch (error) {
    handleApiError(error);
  }
};

// Récupérer un client par son ID
const getClient = async (clientId) => {
  try {
    const response = await pennylaneClient.get(`/customers/${clientId}`);
    return response.data;
  } catch (error) {
    handleApiError(error);
  }
};

// Rechercher un client par email
const findClientByEmail = async (email) => {
  try {
    const response = await pennylaneClient.get('/customers', {
      params: { email }
    });
    
    if (response.data.length > 0) {
      return response.data[0];
    }
    
    return null;
  } catch (error) {
    handleApiError(error);
  }
};

// Créer un produit (service) dans Pennylane
const createProduct = async (productData) => {
  try {
    const response = await pennylaneClient.post('/products', {
      name: productData.nom,
      description: productData.description,
      unit_price: productData.prixUnitaire,
      vat_rate: productData.tauxTVA || 20,
      unit: 'unit',
      type: 'service'
    });
    
    return response.data;
  } catch (error) {
    handleApiError(error);
  }
};

// Récupérer un produit par son ID
const getProduct = async (productId) => {
  try {
    const response = await pennylaneClient.get(`/products/${productId}`);
    return response.data;
  } catch (error) {
    handleApiError(error);
  }
};

// Créer une facture dans Pennylane
const createInvoice = async (invoiceData) => {
  try {
    const response = await pennylaneClient.post('/invoices', {
      customer_id: invoiceData.clientId,
      date: invoiceData.date || new Date().toISOString().split('T')[0],
      payment_deadline: invoiceData.dateEcheance,
      currency: 'EUR',
      language: 'fr',
      items: invoiceData.items.map(item => ({
        product_id: item.productId,
        quantity: item.quantite,
        unit_price: item.prixUnitaire,
        description: item.description,
        vat_rate: item.tauxTVA || 20
      })),
      payment_conditions: invoiceData.conditionsPaiement || 'upon_receipt',
      external_reference: invoiceData.referenceExterne || null,
      notes: invoiceData.notes || null
    });
    
    return response.data;
  } catch (error) {
    handleApiError(error);
  }
};

// Récupérer une facture par son ID
const getInvoice = async (invoiceId) => {
  try {
    const response = await pennylaneClient.get(`/invoices/${invoiceId}`);
    return response.data;
  } catch (error) {
    handleApiError(error);
  }
};

// Envoyer une facture par email
const sendInvoiceByEmail = async (invoiceId, emailData) => {
  try {
    const response = await pennylaneClient.post(`/invoices/${invoiceId}/send_by_email`, {
      recipient_email: emailData.destinataire,
      subject: emailData.sujet,
      message: emailData.message
    });
    
    return response.data;
  } catch (error) {
    handleApiError(error);
  }
};

// Marquer une facture comme payée
const markInvoiceAsPaid = async (invoiceId, paymentData) => {
  try {
    const response = await pennylaneClient.post(`/invoices/${invoiceId}/payments`, {
      date: paymentData.date || new Date().toISOString().split('T')[0],
      amount: paymentData.montant,
      payment_method: paymentData.methodePaiement || 'bank_transfer',
      notes: paymentData.notes || null
    });
    
    return response.data;
  } catch (error) {
    handleApiError(error);
  }
};

// Récupérer les paiements d'une facture
const getInvoicePayments = async (invoiceId) => {
  try {
    const response = await pennylaneClient.get(`/invoices/${invoiceId}/payments`);
    return response.data;
  } catch (error) {
    handleApiError(error);
  }
};

// Créer un devis dans Pennylane
const createQuote = async (quoteData) => {
  try {
    const response = await pennylaneClient.post('/quotes', {
      customer_id: quoteData.clientId,
      date: quoteData.date || new Date().toISOString().split('T')[0],
      expiry_date: quoteData.dateExpiration,
      currency: 'EUR',
      language: 'fr',
      items: quoteData.items.map(item => ({
        product_id: item.productId,
        quantity: item.quantite,
        unit_price: item.prixUnitaire,
        description: item.description,
        vat_rate: item.tauxTVA || 20
      })),
      external_reference: quoteData.referenceExterne || null,
      notes: quoteData.notes || null
    });
    
    return response.data;
  } catch (error) {
    handleApiError(error);
  }
};

// Récupérer un devis par son ID
const getQuote = async (quoteId) => {
  try {
    const response = await pennylaneClient.get(`/quotes/${quoteId}`);
    return response.data;
  } catch (error) {
    handleApiError(error);
  }
};

// Envoyer un devis par email
const sendQuoteByEmail = async (quoteId, emailData) => {
  try {
    const response = await pennylaneClient.post(`/quotes/${quoteId}/send_by_email`, {
      recipient_email: emailData.destinataire,
      subject: emailData.sujet,
      message: emailData.message
    });
    
    return response.data;
  } catch (error) {
    handleApiError(error);
  }
};

// Convertir un devis en facture
const convertQuoteToInvoice = async (quoteId, invoiceData = {}) => {
  try {
    const response = await pennylaneClient.post(`/quotes/${quoteId}/convert_to_invoice`, {
      date: invoiceData.date || new Date().toISOString().split('T')[0],
      payment_deadline: invoiceData.dateEcheance,
      payment_conditions: invoiceData.conditionsPaiement || 'upon_receipt'
    });
    
    return response.data;
  } catch (error) {
    handleApiError(error);
  }
};

// Récupérer les statistiques financières
const getFinancialStats = async (params = {}) => {
  try {
    const response = await pennylaneClient.get('/stats/financial', {
      params: {
        start_date: params.dateDebut,
        end_date: params.dateFin,
        period: params.periode || 'month'
      }
    });
    
    return response.data;
  } catch (error) {
    handleApiError(error);
  }
};

export default {
  createClient,
  updateClient,
  getClient,
  findClientByEmail,
  createProduct,
  getProduct,
  createInvoice,
  getInvoice,
  sendInvoiceByEmail,
  markInvoiceAsPaid,
  getInvoicePayments,
  createQuote,
  getQuote,
  sendQuoteByEmail,
  convertQuoteToInvoice,
  getFinancialStats
};
