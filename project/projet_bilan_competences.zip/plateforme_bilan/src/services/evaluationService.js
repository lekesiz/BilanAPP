// Service pour la gestion des évaluations
import axios from 'axios';

const API_URL = '/api/evaluations';

// Récupérer toutes les évaluations
const getAllEvaluations = async (params = {}) => {
  try {
    const response = await axios.get(API_URL, { params });
    return response.data;
  } catch (error) {
    throw new Error(error.response?.data?.message || 'Erreur lors de la récupération des évaluations');
  }
};

// Récupérer une évaluation par son ID
const getEvaluationById = async (id) => {
  try {
    const response = await axios.get(`${API_URL}/${id}`);
    return response.data;
  } catch (error) {
    throw new Error(error.response?.data?.message || 'Erreur lors de la récupération de l\'évaluation');
  }
};

// Créer une nouvelle évaluation
const createEvaluation = async (evaluationData) => {
  try {
    const response = await axios.post(API_URL, evaluationData);
    return response.data;
  } catch (error) {
    throw new Error(error.response?.data?.message || 'Erreur lors de la création de l\'évaluation');
  }
};

// Mettre à jour une évaluation
const updateEvaluation = async (id, evaluationData) => {
  try {
    const response = await axios.put(`${API_URL}/${id}`, evaluationData);
    return response.data;
  } catch (error) {
    throw new Error(error.response?.data?.message || 'Erreur lors de la mise à jour de l\'évaluation');
  }
};

// Supprimer une évaluation
const deleteEvaluation = async (id) => {
  try {
    const response = await axios.delete(`${API_URL}/${id}`);
    return response.data;
  } catch (error) {
    throw new Error(error.response?.data?.message || 'Erreur lors de la suppression de l\'évaluation');
  }
};

// Assigner une évaluation à un bénéficiaire
const assignEvaluationToBeneficiaire = async (beneficiaireId, evaluationId) => {
  try {
    const response = await axios.post(`/api/beneficiaires/${beneficiaireId}/evaluations`, {
      evaluationId
    });
    return response.data;
  } catch (error) {
    throw new Error(error.response?.data?.message || 'Erreur lors de l\'assignation de l\'évaluation');
  }
};

// Soumettre les réponses d'une évaluation
const submitEvaluationResponses = async (beneficiaireId, evaluationId, responses) => {
  try {
    const response = await axios.post(`/api/beneficiaires/${beneficiaireId}/evaluations/${evaluationId}/responses`, {
      responses
    });
    return response.data;
  } catch (error) {
    throw new Error(error.response?.data?.message || 'Erreur lors de la soumission des réponses');
  }
};

// Récupérer les résultats d'une évaluation
const getEvaluationResults = async (beneficiaireId, evaluationId) => {
  try {
    const response = await axios.get(`/api/beneficiaires/${beneficiaireId}/evaluations/${evaluationId}/results`);
    return response.data;
  } catch (error) {
    throw new Error(error.response?.data?.message || 'Erreur lors de la récupération des résultats');
  }
};

// Récupérer les évaluations assignées à un bénéficiaire
const getBeneficiaireEvaluations = async (beneficiaireId) => {
  try {
    const response = await axios.get(`/api/beneficiaires/${beneficiaireId}/evaluations`);
    return response.data;
  } catch (error) {
    throw new Error(error.response?.data?.message || 'Erreur lors de la récupération des évaluations du bénéficiaire');
  }
};

export default {
  getAllEvaluations,
  getEvaluationById,
  createEvaluation,
  updateEvaluation,
  deleteEvaluation,
  assignEvaluationToBeneficiaire,
  submitEvaluationResponses,
  getEvaluationResults,
  getBeneficiaireEvaluations
};
