// Service de génération de documents pour les bilans de compétences
import axios from 'axios';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import { saveAs } from 'file-saver';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';

// Configuration des styles de document
const documentStyles = {
  fontFamily: 'Helvetica',
  titleFontSize: 18,
  subtitleFontSize: 14,
  normalFontSize: 12,
  smallFontSize: 10,
  primaryColor: '#2c3e50',
  secondaryColor: '#3498db',
  accentColor: '#e74c3c',
  backgroundColor: '#f9f9f9',
  padding: 15
};

// Fonction utilitaire pour formater les dates
const formatDate = (dateString) => {
  if (!dateString) return '';
  const date = new Date(dateString);
  return format(date, 'dd MMMM yyyy', { locale: fr });
};

// Fonction utilitaire pour formater les nombres
const formatNumber = (number) => {
  return new Intl.NumberFormat('fr-FR').format(number);
};

// Fonction utilitaire pour formater les montants
const formatAmount = (amount) => {
  return new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(amount);
};

// Fonction pour générer un document d'information préalable
const generateInformationPrealable = async (beneficiaire, consultant) => {
  try {
    const doc = new jsPDF();
    
    // En-tête
    doc.setFontSize(documentStyles.titleFontSize);
    doc.setTextColor(documentStyles.primaryColor);
    doc.text('DOCUMENT D\'INFORMATION PRÉALABLE', doc.internal.pageSize.width / 2, 20, { align: 'center' });
    doc.setFontSize(documentStyles.subtitleFontSize);
    doc.text('Bilan de compétences', doc.internal.pageSize.width / 2, 30, { align: 'center' });
    
    // Informations du bénéficiaire
    doc.setFontSize(documentStyles.subtitleFontSize);
    doc.setTextColor(documentStyles.secondaryColor);
    doc.text('Informations du bénéficiaire', 20, 50);
    
    doc.setFontSize(documentStyles.normalFontSize);
    doc.setTextColor(documentStyles.primaryColor);
    doc.text(`Nom : ${beneficiaire.nom}`, 20, 60);
    doc.text(`Prénom : ${beneficiaire.prenom}`, 20, 70);
    doc.text(`Email : ${beneficiaire.email}`, 20, 80);
    doc.text(`Téléphone : ${beneficiaire.telephone || 'Non renseigné'}`, 20, 90);
    
    // Informations du consultant
    doc.setFontSize(documentStyles.subtitleFontSize);
    doc.setTextColor(documentStyles.secondaryColor);
    doc.text('Consultant référent', 20, 110);
    
    doc.setFontSize(documentStyles.normalFontSize);
    doc.setTextColor(documentStyles.primaryColor);
    doc.text(`Nom : ${consultant.nom}`, 20, 120);
    doc.text(`Prénom : ${consultant.prenom}`, 20, 130);
    doc.text(`Email : ${consultant.email}`, 20, 140);
    doc.text(`Téléphone : ${consultant.telephone || 'Non renseigné'}`, 20, 150);
    
    // Cadre légal
    doc.setFontSize(documentStyles.subtitleFontSize);
    doc.setTextColor(documentStyles.secondaryColor);
    doc.text('Cadre légal du bilan de compétences', 20, 170);
    
    const cadreLegal = [
      'Le bilan de compétences est défini par les articles L6313-1, L6313-4 et R6313-4 à R6313-8 du Code du travail.',
      'Il permet d\'analyser vos compétences professionnelles et personnelles, vos aptitudes et motivations afin de définir un projet professionnel et, le cas échéant, un projet de formation.',
      'Le bilan de compétences est une démarche individuelle et volontaire. Son contenu et son déroulement sont strictement confidentiels.'
    ];
    
    doc.setFontSize(documentStyles.normalFontSize);
    doc.setTextColor(documentStyles.primaryColor);
    let y = 180;
    cadreLegal.forEach(paragraph => {
      const lines = doc.splitTextToSize(paragraph, doc.internal.pageSize.width - 40);
      doc.text(lines, 20, y);
      y += 10 * lines.length;
    });
    
    // Nouvelle page
    doc.addPage();
    
    // Déroulement du bilan
    doc.setFontSize(documentStyles.subtitleFontSize);
    doc.setTextColor(documentStyles.secondaryColor);
    doc.text('Déroulement du bilan de compétences', 20, 20);
    
    doc.setFontSize(documentStyles.normalFontSize);
    doc.setTextColor(documentStyles.primaryColor);
    doc.text('Le bilan de compétences se déroule en trois phases :', 20, 30);
    
    const phases = [
      {
        title: 'Phase préliminaire',
        content: 'Analyse de votre demande et de vos besoins, information sur les conditions de déroulement du bilan et les méthodes utilisées.'
      },
      {
        title: 'Phase d\'investigation',
        content: 'Analyse de vos motivations, intérêts, compétences et aptitudes professionnelles et personnelles. Détermination de vos possibilités d\'évolution professionnelle.'
      },
      {
        title: 'Phase de conclusion',
        content: 'Résultats détaillés de la phase d\'investigation, recensement des facteurs favorisant ou non la réalisation de votre projet professionnel, élaboration d\'un plan d\'action.'
      }
    ];
    
    let yPhase = 40;
    phases.forEach(phase => {
      doc.setFontSize(documentStyles.smallFontSize);
      doc.setTextColor(documentStyles.accentColor);
      doc.text(phase.title, 20, yPhase);
      
      doc.setFontSize(documentStyles.normalFontSize);
      doc.setTextColor(documentStyles.primaryColor);
      const lines = doc.splitTextToSize(phase.content, doc.internal.pageSize.width - 40);
      doc.text(lines, 30, yPhase + 10);
      yPhase += 10 + (10 * lines.length);
    });
    
    // Durée et calendrier
    doc.setFontSize(documentStyles.subtitleFontSize);
    doc.setTextColor(documentStyles.secondaryColor);
    doc.text('Durée et calendrier', 20, yPhase + 10);
    
    doc.setFontSize(documentStyles.normalFontSize);
    doc.setTextColor(documentStyles.primaryColor);
    doc.text('La durée totale du bilan de compétences est de 24 heures maximum, réparties sur 8 à 12 semaines.', 20, yPhase + 20);
    doc.text('Elle comprend des entretiens individuels, des tests et des travaux personnels guidés.', 20, yPhase + 30);
    
    // Engagements déontologiques
    doc.setFontSize(documentStyles.subtitleFontSize);
    doc.setTextColor(documentStyles.secondaryColor);
    doc.text('Engagements déontologiques', 20, yPhase + 50);
    
    const engagements = [
      'Respect de la confidentialité : toutes les informations recueillies lors du bilan sont strictement confidentielles.',
      'Consentement éclairé : vous êtes libre d\'interrompre le bilan à tout moment.',
      'Neutralité et objectivité : le consultant s\'engage à une totale neutralité et objectivité.',
      'Respect du RGPD : vos données personnelles sont traitées conformément au Règlement Général sur la Protection des Données.'
    ];
    
    doc.setFontSize(documentStyles.normalFontSize);
    doc.setTextColor(documentStyles.primaryColor);
    let yEngagement = yPhase + 60;
    engagements.forEach(engagement => {
      const lines = doc.splitTextToSize(engagement, doc.internal.pageSize.width - 40);
      doc.text(lines, 20, yEngagement);
      yEngagement += 10 * lines.length;
    });
    
    // Pied de page
    const today = new Date();
    doc.setFontSize(documentStyles.smallFontSize);
    doc.setTextColor(documentStyles.primaryColor);
    doc.text(`Document généré le ${formatDate(today)}`, doc.internal.pageSize.width / 2, doc.internal.pageSize.height - 10, { align: 'center' });
    
    // Retourner le document
    return doc.output('blob');
  } catch (error) {
    console.error('Erreur lors de la génération du document d\'information préalable:', error);
    throw new Error('Erreur lors de la génération du document');
  }
};

// Fonction pour générer une convention tripartite
const generateConventionTripartite = async (beneficiaire, consultant, employeur, financement) => {
  try {
    const doc = new jsPDF();
    
    // En-tête
    doc.setFontSize(documentStyles.titleFontSize);
    doc.setTextColor(documentStyles.primaryColor);
    doc.text('CONVENTION TRIPARTITE', doc.internal.pageSize.width / 2, 20, { align: 'center' });
    doc.setFontSize(documentStyles.subtitleFontSize);
    doc.text('Bilan de compétences', doc.internal.pageSize.width / 2, 30, { align: 'center' });
    
    // Parties concernées
    doc.setFontSize(documentStyles.subtitleFontSize);
    doc.setTextColor(documentStyles.secondaryColor);
    doc.text('Entre les soussignés :', 20, 50);
    
    // Organisme prestataire
    doc.setFontSize(documentStyles.normalFontSize);
    doc.setTextColor(documentStyles.primaryColor);
    doc.text('L\'organisme prestataire de bilan de compétences :', 20, 60);
    doc.setFontSize(documentStyles.smallFontSize);
    doc.text('Nom de l\'organisme : [Nom de votre organisme]', 30, 70);
    doc.text('Adresse : [Adresse de votre organisme]', 30, 80);
    doc.text('SIRET : [Numéro SIRET]', 30, 90);
    doc.text('Représenté par : [Nom du représentant]', 30, 100);
    doc.text(`Consultant référent : ${consultant.prenom} ${consultant.nom}`, 30, 110);
    
    // Bénéficiaire
    doc.setFontSize(documentStyles.normalFontSize);
    doc.text('Le bénéficiaire :', 20, 130);
    doc.setFontSize(documentStyles.smallFontSize);
    doc.text(`Nom et prénom : ${beneficiaire.prenom} ${beneficiaire.nom}`, 30, 140);
    doc.text(`Adresse : ${beneficiaire.adresse || '[Adresse du bénéficiaire]'}`, 30, 150);
    doc.text(`Email : ${beneficiaire.email}`, 30, 160);
    doc.text(`Téléphone : ${beneficiaire.telephone || 'Non renseigné'}`, 30, 170);
    
    // Employeur (si applicable)
    if (employeur) {
      doc.setFontSize(documentStyles.normalFontSize);
      doc.text('L\'employeur :', 20, 190);
      doc.setFontSize(documentStyles.smallFontSize);
      doc.text(`Raison sociale : ${employeur.raisonSociale}`, 30, 200);
      doc.text(`Adresse : ${employeur.adresse || '[Adresse de l\'employeur]'}`, 30, 210);
      doc.text(`SIRET : ${employeur.siret || '[SIRET de l\'employeur]'}`, 30, 220);
      doc.text(`Représenté par : ${employeur.representant || '[Nom du représentant]'}`, 30, 230);
    }
    
    // Nouvelle page
    doc.addPage();
    
    // Objet de la convention
    doc.setFontSize(documentStyles.subtitleFontSize);
    doc.setTextColor(documentStyles.secondaryColor);
    doc.text('Article 1 : Objet de la convention', 20, 20);
    
    doc.setFontSize(documentStyles.normalFontSize);
    doc.setTextColor(documentStyles.primaryColor);
    const objetText = 'La présente convention a pour objet de définir les conditions de réalisation du bilan de compétences pour le bénéficiaire, conformément aux dispositions des articles L6313-1, L6313-4 et R6313-4 à R6313-8 du Code du travail.';
    const objetLines = doc.splitTextToSize(objetText, doc.internal.pageSize.width - 40);
    doc.text(objetLines, 20, 30);
    
    // Nature et contenu du bilan
    doc.setFontSize(documentStyles.subtitleFontSize);
    doc.setTextColor(documentStyles.secondaryColor);
    doc.text('Article 2 : Nature et contenu du bilan', 20, 50);
    
    doc.setFontSize(documentStyles.normalFontSize);
    doc.setTextColor(documentStyles.primaryColor);
    const natureText = 'Le bilan de compétences comprend les trois phases suivantes :';
    doc.text(natureText, 20, 60);
    
    const phases = [
      {
        title: 'Phase préliminaire',
        content: 'Analyse de la demande et des besoins du bénéficiaire, information sur les conditions de déroulement du bilan et les méthodes utilisées.'
      },
      {
        title: 'Phase d\'investigation',
        content: 'Analyse des motivations, intérêts, compétences et aptitudes professionnelles et personnelles du bénéficiaire. Détermination de ses possibilités d\'évolution professionnelle.'
      },
      {
        title: 'Phase de conclusion',
        content: 'Présentation des résultats détaillés de la phase d\'investigation, recensement des facteurs favorisant ou non la réalisation du projet professionnel, élaboration d\'un plan d\'action.'
      }
    ];
    
    let yPhase = 70;
    phases.forEach(phase => {
      doc.setFontSize(documentStyles.smallFontSize);
      doc.setTextColor(documentStyles.accentColor);
      doc.text(phase.title, 20, yPhase);
      
      doc.setFontSize(documentStyles.normalFontSize);
      doc.setTextColor(documentStyles.primaryColor);
      const lines = doc.splitTextToSize(phase.content, doc.internal.pageSize.width - 40);
      doc.text(lines, 30, yPhase + 10);
      yPhase += 10 + (10 * lines.length);
    });
    
    // Durée et calendrier
    doc.setFontSize(documentStyles.subtitleFontSize);
    doc.setTextColor(documentStyles.secondaryColor);
    doc.text('Article 3 : Durée et calendrier', 20, yPhase + 10);
    
    doc.setFontSize(documentStyles.normalFontSize);
    doc.setTextColor(documentStyles.primaryColor);
    doc.text('La durée totale du bilan de compétences est de 24 heures maximum, réparties comme suit :', 20, yPhase + 20);
    doc.text('- Phase préliminaire : 2 heures', 30, yPhase + 30);
    doc.text('- Phase d\'investigation : 18 heures', 30, yPhase + 40);
    doc.text('- Phase de conclusion : 4 heures', 30, yPhase + 50);
    
    doc.text('Le bilan se déroulera du [Date de début] au [Date de fin], selon le calendrier joint en annexe.', 20, yPhase + 60);
    
    // Coût et financement
    doc.setFontSize(documentStyles.subtitleFontSize);
    doc.setTextColor(documentStyles.secondaryColor);
    doc.text('Article 4 : Coût et financement', 20, yPhase + 80);
    
    doc.setFontSize(documentStyles.normalFontSize);
    doc.setTextColor(documentStyles.primaryColor);
    doc.text(`Le coût total du bilan de compétences s'élève à ${formatAmount(financement?.montantTotal || 1500)} TTC.`, 20, yPhase + 90);
    
    if (financement) {
      doc.text(`Le financement est assuré par : ${financement.source}`, 20, yPhase + 100);
      if (financement.source === 'CPF') {
        doc.text(`Numéro de dossier CPF : ${financement.numeroDossier || '[Numéro de dossier]'}`, 30, yPhase + 110);
      } else if (financement.source === 'Employeur') {
        doc.text(`Dans le cadre du plan de développement des compétences`, 30, yPhase + 110);
      } else if (financement.source === 'OPCO') {
        doc.text(`OPCO : ${financement.opco || '[Nom de l\'OPCO]'}`, 30, yPhase + 110);
        doc.text(`Numéro de dossier : ${financement.numeroDossier || '[Numéro de dossier]'}`, 30, yPhase + 120);
      }
    }
    
    // Nouvelle page
    doc.addPage();
    
    // Obligations des parties
    doc.setFontSize(documentStyles.subtitleFontSize);
    doc.setTextColor(documentStyles.secondaryColor);
    doc.text('Article 5 : Obligations des parties', 20, 20);
    
    // Obligations de l'organisme
    doc.setFontSize(documentStyles.normalFontSize);
    doc.setTextColor(documentStyles.primaryColor);
    doc.text('L\'organisme prestataire s\'engage à :', 20, 30);
    
    const obligationsOrganisme = [
      'Réaliser le bilan de compétences conformément aux dispositions légales et réglementaires',
      'Respecter la confidentialité des informations recueillies',
      'Remettre au bénéficiaire un document de synthèse à l\'issue du bilan',
      'Détruire les documents élaborés pour le bilan après la remise du document de synthèse, sauf accord écrit du bénéficiaire'
    ];
    
    let yObligation = 40;
    obligationsOrganisme.forEach((obligation, index) => {
      doc.text(`${index + 1}. ${obligation}`, 30, yObligation);
      yObligation += 10;
    });
    
    // Obligations du bénéficiaire
    doc.text('Le bénéficiaire s\'engage à :', 20, yObligation + 10);
    
    const obligationsBeneficiaire = [
      'Suivre activement les différentes phases du bilan',
      'Fournir toute information utile à la réalisation du bilan',
      'Respecter le calendrier établi',
      'Réaliser les travaux personnels demandés entre les séances'
    ];
    
    let yObligationBenef = yObligation + 20;
    obligationsBeneficiaire.forEach((obligation, index) => {
      doc.text(`${index + 1}. ${obligation}`, 30, yObligationBenef);
      yObligationBenef += 10;
    });
    
    // Obligations de l'employeur (si applicable)
    if (employeur) {
      doc.text('L\'employeur s\'engage à :', 20, yObligationBenef + 10);
      
      const obligationsEmployeur = [
        'Permettre au bénéficiaire de suivre le bilan selon le calendrier établi',
        'Respecter la confidentialité du bilan'
      ];
      
      let yObligationEmp = yObligationBenef + 20;
      obligationsEmployeur.forEach((obligation, index) => {
        doc.text(`${index + 1}. ${obligation}`, 30, yObligationEmp);
        yObligationEmp += 10;
      });
    }
    
    // Confidentialité
    doc.setFontSize(documentStyles.subtitleFontSize);
    doc.setTextColor(documentStyles.secondaryColor);
    doc.text('Article 6 : Confidentialité', 20, yObligationBenef + 40);
    
    doc.setFontSize(documentStyles.normalFontSize);
    doc.setTextColor(documentStyles.primaryColor);
    const confidentialiteText = 'Toutes les informations recueillies lors du bilan de compétences sont strictement confidentielles. Les résultats du bilan sont la propriété exclusive du bénéficiaire et ne peuvent être communiqués à un tiers sans son accord écrit.';
    const confidentialiteLines = doc.splitTextToSize(confidentialiteText, doc.internal.pageSize.width - 40);
    doc.text(confidentialiteLines, 20, yObligationBenef + 50);
    
    // Signatures
    doc.setFontSize(documentStyles.subtitleFontSize);
    doc.setTextColor(documentStyles.secondaryColor);
    doc.text('Fait à [Lieu], le [Date]', 20, yObligationBenef + 80);
    
    doc.setFontSize(documentStyles.normalFontSize);
    doc.setTextColor(documentStyles.primaryColor);
    doc.text('Pour l\'organisme prestataire', 20, yObligationBenef + 100);
    doc.text('Le bénéficiaire', doc.internal.pageSize.width / 2, yObligationBenef + 100);
    
    if (employeur) {
      doc.text('L\'employeur', doc.internal.pageSize.width - 50, yObligationBenef + 100);
    }
    
    // Pied de page
    const today = new Date();
    doc.setFontSize(documentStyles.smallFontSize);
    doc.setTextColor(documentStyles.primaryColor);
    doc.text(`Document généré le ${formatDate(today)}`, doc.internal.pageSize.width / 2, doc.internal.pageSize.height - 10, { align: 'center' });
    
    // Retourner le document
    return doc.output('blob');
  } catch (error) {
    console.error('Erreur lors de la génération de la convention tripartite:', error);
    throw new Error('Erreur lors de la génération du document');
  }
};

// Fonction pour générer un document de synthèse
const generateDocumentSynthese = async (beneficiaire, consultant, bilan) => {
  try {
    const doc = new jsPDF();
    
    // En-tête
    doc.setFontSize(documentStyles.titleFontSize);
    doc.setTextColor(documentStyles.primaryColor);
    doc.text('DOCUMENT DE SYNTHÈSE', doc.internal.pageSize.width / 2, 20, { align: 'center' });
    doc.setFontSize(documentStyles.subtitleFontSize);
    doc.text('Bilan de compétences', doc.internal.pageSize.width / 2, 30, { align: 'center' });
    
    // Informations générales
    doc.setFontSize(documentStyles.subtitleFontSize);
    doc.setTextColor(documentStyles.secondaryColor);
    doc.text('Informations générales', 20, 50);
    
    doc.setFontSize(documentStyles.normalFontSize);
    doc.setTextColor(documentStyles.primaryColor);
    doc.text(`Bénéficiaire : ${beneficiaire.prenom} ${beneficiaire.nom}`, 20, 60);
    doc.text(`Consultant référent : ${consultant.prenom} ${consultant.nom}`, 20, 70);
    doc.text(`Période du bilan : du ${formatDate(bilan.dateDebut)} au ${formatDate(bilan.dateFin)}`, 20, 80);
    doc.text(`Durée totale : ${bilan.dureeHeures || 24} heures`, 20, 90);
    
    // Circonstances du bilan
    doc.setFontSize(documentStyles.subtitleFontSize);
    doc.setTextColor(documentStyles.secondaryColor);
    doc.text('Circonstances du bilan', 20, 110);
    
    doc.setFontSize(documentStyles.normalFontSize);
    doc.setTextColor(documentStyles.primaryColor);
    const circonstancesText = bilan.circonstances || 'Le bénéficiaire a souhaité réaliser ce bilan de compétences dans le cadre d\'une réflexion sur son évolution professionnelle.';
    const circonstancesLines = doc.splitTextToSize(circonstancesText, doc.internal.pageSize.width - 40);
    doc.text(circonstancesLines, 20, 120);
    
    // Compétences et aptitudes identifiées
    doc.setFontSize(documentStyles.subtitleFontSize);
    doc.setTextColor(documentStyles.secondaryColor);
    doc.text('Compétences et aptitudes identifiées', 20, 140 + (circonstancesLines.length - 1) * 10);
    
    // Compétences techniques
    doc.setFontSize(documentStyles.smallFontSize);
    doc.setTextColor(documentStyles.accentColor);
    doc.text('Compétences techniques', 20, 150 + (circonstancesLines.length - 1) * 10);
    
    doc.setFontSize(documentStyles.normalFontSize);
    doc.setTextColor(documentStyles.primaryColor);
    let yCompetences = 160 + (circonstancesLines.length - 1) * 10;
    
    if (bilan.competencesTechniques && bilan.competencesTechniques.length > 0) {
      bilan.competencesTechniques.forEach((competence, index) => {
        doc.text(`- ${competence}`, 30, yCompetences);
        yCompetences += 10;
      });
    } else {
      doc.text('Aucune compétence technique spécifique n\'a été identifiée.', 30, yCompetences);
      yCompetences += 10;
    }
    
    // Compétences transversales
    doc.setFontSize(documentStyles.smallFontSize);
    doc.setTextColor(documentStyles.accentColor);
    doc.text('Compétences transversales', 20, yCompetences + 10);
    
    doc.setFontSize(documentStyles.normalFontSize);
    doc.setTextColor(documentStyles.primaryColor);
    yCompetences += 20;
    
    if (bilan.competencesTransversales && bilan.competencesTransversales.length > 0) {
      bilan.competencesTransversales.forEach((competence, index) => {
        doc.text(`- ${competence}`, 30, yCompetences);
        yCompetences += 10;
      });
    } else {
      doc.text('Aucune compétence transversale spécifique n\'a été identifiée.', 30, yCompetences);
      yCompetences += 10;
    }
    
    // Aptitudes personnelles
    doc.setFontSize(documentStyles.smallFontSize);
    doc.setTextColor(documentStyles.accentColor);
    doc.text('Aptitudes personnelles', 20, yCompetences + 10);
    
    doc.setFontSize(documentStyles.normalFontSize);
    doc.setTextColor(documentStyles.primaryColor);
    yCompetences += 20;
    
    if (bilan.aptitudesPersonnelles && bilan.aptitudesPersonnelles.length > 0) {
      bilan.aptitudesPersonnelles.forEach((aptitude, index) => {
        doc.text(`- ${aptitude}`, 30, yCompetences);
        yCompetences += 10;
      });
    } else {
      doc.text('Aucune aptitude personnelle spécifique n\'a été identifiée.', 30, yCompetences);
      yCompetences += 10;
    }
    
    // Nouvelle page
    doc.addPage();
    
    // Résultats des évaluations
    doc.setFontSize(documentStyles.subtitleFontSize);
    doc.setTextColor(documentStyles.secondaryColor);
    doc.text('Résultats des évaluations', 20, 20);
    
    if (bilan.resultatsEvaluations && bilan.resultatsEvaluations.length > 0) {
      let yResultats = 30;
      bilan.resultatsEvaluations.forEach((evaluation, index) => {
        doc.setFontSize(documentStyles.smallFontSize);
        doc.setTextColor(documentStyles.accentColor);
        doc.text(evaluation.titre, 20, yResultats);
        
        doc.setFontSize(documentStyles.normalFontSize);
        doc.setTextColor(documentStyles.primaryColor);
        const resultatsLines = doc.splitTextToSize(evaluation.resultats, doc.internal.pageSize.width - 40);
        doc.text(resultatsLines, 30, yResultats + 10);
        yResultats += 20 + (resultatsLines.length - 1) * 10;
      });
    } else {
      doc.setFontSize(documentStyles.normalFontSize);
      doc.setTextColor(documentStyles.primaryColor);
      doc.text('Aucun résultat d\'évaluation spécifique n\'est disponible.', 20, 30);
    }
    
    // Projet professionnel
    doc.setFontSize(documentStyles.subtitleFontSize);
    doc.setTextColor(documentStyles.secondaryColor);
    doc.text('Projet professionnel', 20, 100);
    
    if (bilan.projetProfessionnel) {
      // Objectifs
      doc.setFontSize(documentStyles.smallFontSize);
      doc.setTextColor(documentStyles.accentColor);
      doc.text('Objectifs', 20, 110);
      
      doc.setFontSize(documentStyles.normalFontSize);
      doc.setTextColor(documentStyles.primaryColor);
      const objectifsLines = doc.splitTextToSize(bilan.projetProfessionnel.objectifs || 'Non défini', doc.internal.pageSize.width - 40);
      doc.text(objectifsLines, 30, 120);
      
      // Pistes professionnelles
      doc.setFontSize(documentStyles.smallFontSize);
      doc.setTextColor(documentStyles.accentColor);
      doc.text('Pistes professionnelles', 20, 130 + (objectifsLines.length - 1) * 10);
      
      doc.setFontSize(documentStyles.normalFontSize);
      doc.setTextColor(documentStyles.primaryColor);
      let yPistes = 140 + (objectifsLines.length - 1) * 10;
      
      if (bilan.projetProfessionnel.pistes && bilan.projetProfessionnel.pistes.length > 0) {
        bilan.projetProfessionnel.pistes.forEach((piste, index) => {
          doc.text(`- ${piste}`, 30, yPistes);
          yPistes += 10;
        });
      } else {
        doc.text('Aucune piste professionnelle spécifique n\'a été identifiée.', 30, yPistes);
        yPistes += 10;
      }
      
      // Facteurs favorables
      doc.setFontSize(documentStyles.smallFontSize);
      doc.setTextColor(documentStyles.accentColor);
      doc.text('Facteurs favorables', 20, yPistes + 10);
      
      doc.setFontSize(documentStyles.normalFontSize);
      doc.setTextColor(documentStyles.primaryColor);
      let yFacteurs = yPistes + 20;
      
      if (bilan.projetProfessionnel.facteursFavorables && bilan.projetProfessionnel.facteursFavorables.length > 0) {
        bilan.projetProfessionnel.facteursFavorables.forEach((facteur, index) => {
          doc.text(`- ${facteur}`, 30, yFacteurs);
          yFacteurs += 10;
        });
      } else {
        doc.text('Aucun facteur favorable spécifique n\'a été identifié.', 30, yFacteurs);
        yFacteurs += 10;
      }
      
      // Points de vigilance
      doc.setFontSize(documentStyles.smallFontSize);
      doc.setTextColor(documentStyles.accentColor);
      doc.text('Points de vigilance', 20, yFacteurs + 10);
      
      doc.setFontSize(documentStyles.normalFontSize);
      doc.setTextColor(documentStyles.primaryColor);
      let yVigilance = yFacteurs + 20;
      
      if (bilan.projetProfessionnel.pointsVigilance && bilan.projetProfessionnel.pointsVigilance.length > 0) {
        bilan.projetProfessionnel.pointsVigilance.forEach((point, index) => {
          doc.text(`- ${point}`, 30, yVigilance);
          yVigilance += 10;
        });
      } else {
        doc.text('Aucun point de vigilance spécifique n\'a été identifié.', 30, yVigilance);
        yVigilance += 10;
      }
    } else {
      doc.setFontSize(documentStyles.normalFontSize);
      doc.setTextColor(documentStyles.primaryColor);
      doc.text('Aucun projet professionnel n\'a été défini.', 20, 110);
    }
    
    // Nouvelle page
    doc.addPage();
    
    // Plan d'action
    doc.setFontSize(documentStyles.subtitleFontSize);
    doc.setTextColor(documentStyles.secondaryColor);
    doc.text('Plan d\'action', 20, 20);
    
    if (bilan.planAction && bilan.planAction.etapes && bilan.planAction.etapes.length > 0) {
      let yPlan = 30;
      bilan.planAction.etapes.forEach((etape, index) => {
        doc.setFontSize(documentStyles.smallFontSize);
        doc.setTextColor(documentStyles.accentColor);
        doc.text(`Étape ${index + 1} : ${etape.titre}`, 20, yPlan);
        
        doc.setFontSize(documentStyles.normalFontSize);
        doc.setTextColor(documentStyles.primaryColor);
        const descriptionLines = doc.splitTextToSize(etape.description, doc.internal.pageSize.width - 40);
        doc.text(descriptionLines, 30, yPlan + 10);
        
        doc.text(`Échéance : ${formatDate(etape.echeance) || 'Non définie'}`, 30, yPlan + 20 + (descriptionLines.length - 1) * 10);
        
        yPlan += 30 + (descriptionLines.length - 1) * 10;
      });
    } else {
      doc.setFontSize(documentStyles.normalFontSize);
      doc.setTextColor(documentStyles.primaryColor);
      doc.text('Aucun plan d\'action spécifique n\'a été défini.', 20, 30);
    }
    
    // Besoins en formation
    doc.setFontSize(documentStyles.subtitleFontSize);
    doc.setTextColor(documentStyles.secondaryColor);
    doc.text('Besoins en formation', 20, 120);
    
    if (bilan.besoinsFormation && bilan.besoinsFormation.length > 0) {
      let yFormation = 130;
      bilan.besoinsFormation.forEach((formation, index) => {
        doc.setFontSize(documentStyles.normalFontSize);
        doc.setTextColor(documentStyles.primaryColor);
        doc.text(`- ${formation.intitule}`, 30, yFormation);
        
        if (formation.organisme) {
          doc.setFontSize(documentStyles.smallFontSize);
          doc.text(`  Organisme : ${formation.organisme}`, 40, yFormation + 10);
        }
        
        if (formation.duree) {
          doc.setFontSize(documentStyles.smallFontSize);
          doc.text(`  Durée : ${formation.duree}`, 40, yFormation + 20);
        }
        
        yFormation += 30;
      });
    } else {
      doc.setFontSize(documentStyles.normalFontSize);
      doc.setTextColor(documentStyles.primaryColor);
      doc.text('Aucun besoin en formation spécifique n\'a été identifié.', 20, 130);
    }
    
    // Conclusion
    doc.setFontSize(documentStyles.subtitleFontSize);
    doc.setTextColor(documentStyles.secondaryColor);
    doc.text('Conclusion', 20, 180);
    
    doc.setFontSize(documentStyles.normalFontSize);
    doc.setTextColor(documentStyles.primaryColor);
    const conclusionText = bilan.conclusion || 'Ce bilan de compétences a permis au bénéficiaire d\'identifier ses compétences, aptitudes et motivations, et de définir un projet professionnel réaliste et réalisable.';
    const conclusionLines = doc.splitTextToSize(conclusionText, doc.internal.pageSize.width - 40);
    doc.text(conclusionLines, 20, 190);
    
    // Signatures
    doc.setFontSize(documentStyles.subtitleFontSize);
    doc.setTextColor(documentStyles.secondaryColor);
    doc.text('Fait à [Lieu], le [Date]', 20, 220);
    
    doc.setFontSize(documentStyles.normalFontSize);
    doc.setTextColor(documentStyles.primaryColor);
    doc.text('Le consultant', 20, 240);
    doc.text('Le bénéficiaire', doc.internal.pageSize.width - 50, 240);
    
    // Pied de page
    const today = new Date();
    doc.setFontSize(documentStyles.smallFontSize);
    doc.setTextColor(documentStyles.primaryColor);
    doc.text(`Document généré le ${formatDate(today)}`, doc.internal.pageSize.width / 2, doc.internal.pageSize.height - 10, { align: 'center' });
    
    // Retourner le document
    return doc.output('blob');
  } catch (error) {
    console.error('Erreur lors de la génération du document de synthèse:', error);
    throw new Error('Erreur lors de la génération du document');
  }
};

// Fonction pour générer un rapport d'évaluation
const generateRapportEvaluation = async (beneficiaire, evaluation, resultats) => {
  try {
    const doc = new jsPDF();
    
    // En-tête
    doc.setFontSize(documentStyles.titleFontSize);
    doc.setTextColor(documentStyles.primaryColor);
    doc.text('RAPPORT D\'ÉVALUATION', doc.internal.pageSize.width / 2, 20, { align: 'center' });
    doc.setFontSize(documentStyles.subtitleFontSize);
    doc.text(evaluation.titre, doc.internal.pageSize.width / 2, 30, { align: 'center' });
    
    // Informations générales
    doc.setFontSize(documentStyles.subtitleFontSize);
    doc.setTextColor(documentStyles.secondaryColor);
    doc.text('Informations générales', 20, 50);
    
    doc.setFontSize(documentStyles.normalFontSize);
    doc.setTextColor(documentStyles.primaryColor);
    doc.text(`Bénéficiaire : ${beneficiaire.prenom} ${beneficiaire.nom}`, 20, 60);
    doc.text(`Type d'évaluation : ${evaluation.type}`, 20, 70);
    doc.text(`Date de passation : ${formatDate(resultats.dateCompletion)}`, 20, 80);
    doc.text(`Durée : ${resultats.timeElapsed ? Math.floor(resultats.timeElapsed / 60) : '?'} minutes`, 20, 90);
    
    // Description de l'évaluation
    doc.setFontSize(documentStyles.subtitleFontSize);
    doc.setTextColor(documentStyles.secondaryColor);
    doc.text('Description de l\'évaluation', 20, 110);
    
    doc.setFontSize(documentStyles.normalFontSize);
    doc.setTextColor(documentStyles.primaryColor);
    const descriptionLines = doc.splitTextToSize(evaluation.description, doc.internal.pageSize.width - 40);
    doc.text(descriptionLines, 20, 120);
    
    // Résultats par section
    doc.setFontSize(documentStyles.subtitleFontSize);
    doc.setTextColor(documentStyles.secondaryColor);
    doc.text('Résultats par section', 20, 140 + (descriptionLines.length - 1) * 10);
    
    let ySection = 150 + (descriptionLines.length - 1) * 10;
    let currentPage = 1;
    
    evaluation.sections.forEach((section, sectionIndex) => {
      // Vérifier s'il reste assez d'espace sur la page
      if (ySection > doc.internal.pageSize.height - 40) {
        doc.addPage();
        currentPage++;
        ySection = 20;
      }
      
      doc.setFontSize(documentStyles.smallFontSize);
      doc.setTextColor(documentStyles.accentColor);
      doc.text(`Section ${sectionIndex + 1} : ${section.titre}`, 20, ySection);
      ySection += 10;
      
      // Questions QCM
      if (section.questionsQCM && section.questionsQCM.length > 0) {
        section.questionsQCM.forEach((question, questionIndex) => {
          // Vérifier s'il reste assez d'espace sur la page
          if (ySection > doc.internal.pageSize.height - 60) {
            doc.addPage();
            currentPage++;
            ySection = 20;
          }
          
          const responseKey = `qcm_${sectionIndex}_${questionIndex}`;
          const reponse = resultats.responses[responseKey];
          
          doc.setFontSize(documentStyles.normalFontSize);
          doc.setTextColor(documentStyles.primaryColor);
          const questionLines = doc.splitTextToSize(`Q${questionIndex + 1} : ${question.texte}`, doc.internal.pageSize.width - 40);
          doc.text(questionLines, 30, ySection);
          ySection += 10 + (questionLines.length - 1) * 10;
          
          if (reponse !== null && reponse !== undefined) {
            const optionSelectionnee = question.options.find(option => option.valeur === parseInt(reponse));
            if (optionSelectionnee) {
              doc.setFontSize(documentStyles.smallFontSize);
              doc.setTextColor(documentStyles.secondaryColor);
              doc.text(`Réponse : ${optionSelectionnee.texte} (${optionSelectionnee.valeur})`, 40, ySection);
            } else {
              doc.setFontSize(documentStyles.smallFontSize);
              doc.setTextColor(documentStyles.secondaryColor);
              doc.text(`Réponse : Valeur ${reponse}`, 40, ySection);
            }
          } else {
            doc.setFontSize(documentStyles.smallFontSize);
            doc.setTextColor(documentStyles.secondaryColor);
            doc.text('Réponse : Non répondu', 40, ySection);
          }
          
          ySection += 15;
        });
      }
      
      // Questions à échelle
      if (section.questionsEchelle && section.questionsEchelle.length > 0) {
        section.questionsEchelle.forEach((question, questionIndex) => {
          // Vérifier s'il reste assez d'espace sur la page
          if (ySection > doc.internal.pageSize.height - 60) {
            doc.addPage();
            currentPage++;
            ySection = 20;
          }
          
          const responseKey = `echelle_${sectionIndex}_${questionIndex}`;
          const reponse = resultats.responses[responseKey];
          
          doc.setFontSize(documentStyles.normalFontSize);
          doc.setTextColor(documentStyles.primaryColor);
          const questionLines = doc.splitTextToSize(`Q${questionIndex + 1} : ${question.texte}`, doc.internal.pageSize.width - 40);
          doc.text(questionLines, 30, ySection);
          ySection += 10 + (questionLines.length - 1) * 10;
          
          if (reponse !== null && reponse !== undefined) {
            doc.setFontSize(documentStyles.smallFontSize);
            doc.setTextColor(documentStyles.secondaryColor);
            doc.text(`Réponse : ${reponse} (sur une échelle de ${question.min} à ${question.max})`, 40, ySection);
          } else {
            doc.setFontSize(documentStyles.smallFontSize);
            doc.setTextColor(documentStyles.secondaryColor);
            doc.text('Réponse : Non répondu', 40, ySection);
          }
          
          ySection += 15;
        });
      }
      
      // Questions ouvertes
      if (section.questionsOuvertes && section.questionsOuvertes.length > 0) {
        section.questionsOuvertes.forEach((question, questionIndex) => {
          // Vérifier s'il reste assez d'espace sur la page
          if (ySection > doc.internal.pageSize.height - 80) {
            doc.addPage();
            currentPage++;
            ySection = 20;
          }
          
          const responseKey = `ouverte_${sectionIndex}_${questionIndex}`;
          const reponse = resultats.responses[responseKey];
          
          doc.setFontSize(documentStyles.normalFontSize);
          doc.setTextColor(documentStyles.primaryColor);
          const questionLines = doc.splitTextToSize(`Q${questionIndex + 1} : ${question.texte}`, doc.internal.pageSize.width - 40);
          doc.text(questionLines, 30, ySection);
          ySection += 10 + (questionLines.length - 1) * 10;
          
          if (reponse) {
            doc.setFontSize(documentStyles.smallFontSize);
            doc.setTextColor(documentStyles.secondaryColor);
            const reponseLines = doc.splitTextToSize(`Réponse : ${reponse}`, doc.internal.pageSize.width - 60);
            doc.text(reponseLines, 40, ySection);
            ySection += 10 + (reponseLines.length - 1) * 10;
          } else {
            doc.setFontSize(documentStyles.smallFontSize);
            doc.setTextColor(documentStyles.secondaryColor);
            doc.text('Réponse : Non répondu', 40, ySection);
            ySection += 10;
          }
          
          ySection += 5;
        });
      }
      
      ySection += 10;
    });
    
    // Ajouter une nouvelle page pour l'analyse
    doc.addPage();
    
    // Analyse des résultats
    doc.setFontSize(documentStyles.subtitleFontSize);
    doc.setTextColor(documentStyles.secondaryColor);
    doc.text('Analyse des résultats', 20, 20);
    
    if (resultats.analyse) {
      // Scores globaux
      if (resultats.analyse.scoresGlobaux) {
        doc.setFontSize(documentStyles.smallFontSize);
        doc.setTextColor(documentStyles.accentColor);
        doc.text('Scores globaux', 20, 30);
        
        doc.setFontSize(documentStyles.normalFontSize);
        doc.setTextColor(documentStyles.primaryColor);
        let yScores = 40;
        
        Object.entries(resultats.analyse.scoresGlobaux).forEach(([categorie, score]) => {
          doc.text(`${categorie} : ${score}/100`, 30, yScores);
          yScores += 10;
        });
      }
      
      // Points forts
      if (resultats.analyse.pointsForts && resultats.analyse.pointsForts.length > 0) {
        doc.setFontSize(documentStyles.smallFontSize);
        doc.setTextColor(documentStyles.accentColor);
        doc.text('Points forts', 20, 80);
        
        doc.setFontSize(documentStyles.normalFontSize);
        doc.setTextColor(documentStyles.primaryColor);
        let yForts = 90;
        
        resultats.analyse.pointsForts.forEach((point, index) => {
          doc.text(`- ${point}`, 30, yForts);
          yForts += 10;
        });
      }
      
      // Axes d'amélioration
      if (resultats.analyse.axesAmelioration && resultats.analyse.axesAmelioration.length > 0) {
        doc.setFontSize(documentStyles.smallFontSize);
        doc.setTextColor(documentStyles.accentColor);
        doc.text('Axes d\'amélioration', 20, 130);
        
        doc.setFontSize(documentStyles.normalFontSize);
        doc.setTextColor(documentStyles.primaryColor);
        let yAxes = 140;
        
        resultats.analyse.axesAmelioration.forEach((axe, index) => {
          doc.text(`- ${axe}`, 30, yAxes);
          yAxes += 10;
        });
      }
      
      // Commentaires
      if (resultats.analyse.commentaires) {
        doc.setFontSize(documentStyles.smallFontSize);
        doc.setTextColor(documentStyles.accentColor);
        doc.text('Commentaires', 20, 180);
        
        doc.setFontSize(documentStyles.normalFontSize);
        doc.setTextColor(documentStyles.primaryColor);
        const commentairesLines = doc.splitTextToSize(resultats.analyse.commentaires, doc.internal.pageSize.width - 40);
        doc.text(commentairesLines, 20, 190);
      }
    } else {
      doc.setFontSize(documentStyles.normalFontSize);
      doc.setTextColor(documentStyles.primaryColor);
      doc.text('Aucune analyse des résultats n\'est disponible.', 20, 30);
    }
    
    // Pied de page sur toutes les pages
    const totalPages = doc.internal.getNumberOfPages();
    for (let i = 1; i <= totalPages; i++) {
      doc.setPage(i);
      
      const today = new Date();
      doc.setFontSize(documentStyles.smallFontSize);
      doc.setTextColor(documentStyles.primaryColor);
      doc.text(`Document généré le ${formatDate(today)} - Page ${i}/${totalPages}`, doc.internal.pageSize.width / 2, doc.internal.pageSize.height - 10, { align: 'center' });
    }
    
    // Retourner le document
    return doc.output('blob');
  } catch (error) {
    console.error('Erreur lors de la génération du rapport d\'évaluation:', error);
    throw new Error('Erreur lors de la génération du document');
  }
};

// Fonction pour générer une facture
const generateFacture = async (beneficiaire, consultant, facture) => {
  try {
    const doc = new jsPDF();
    
    // En-tête
    doc.setFontSize(documentStyles.titleFontSize);
    doc.setTextColor(documentStyles.primaryColor);
    doc.text('FACTURE', doc.internal.pageSize.width / 2, 20, { align: 'center' });
    
    // Informations de l'organisme
    doc.setFontSize(documentStyles.normalFontSize);
    doc.setTextColor(documentStyles.primaryColor);
    doc.text('[Nom de votre organisme]', 20, 40);
    doc.text('[Adresse de votre organisme]', 20, 50);
    doc.text('[Code postal] [Ville]', 20, 60);
    doc.text('SIRET : [Numéro SIRET]', 20, 70);
    doc.text('Tél : [Numéro de téléphone]', 20, 80);
    doc.text('Email : [Email de contact]', 20, 90);
    
    // Informations de facturation
    doc.setFontSize(documentStyles.subtitleFontSize);
    doc.setTextColor(documentStyles.secondaryColor);
    doc.text('Facture n° ' + facture.numero, doc.internal.pageSize.width - 60, 40);
    doc.setFontSize(documentStyles.normalFontSize);
    doc.text('Date : ' + formatDate(facture.date), doc.internal.pageSize.width - 60, 50);
    
    // Informations du client
    doc.setFontSize(documentStyles.subtitleFontSize);
    doc.setTextColor(documentStyles.secondaryColor);
    doc.text('Facturer à :', 20, 120);
    
    doc.setFontSize(documentStyles.normalFontSize);
    doc.setTextColor(documentStyles.primaryColor);
    
    if (facture.client.type === 'entreprise') {
      doc.text(facture.client.raisonSociale, 20, 130);
      doc.text(facture.client.adresse || '[Adresse de l\'entreprise]', 20, 140);
      doc.text(facture.client.codePostal + ' ' + facture.client.ville, 20, 150);
      doc.text('SIRET : ' + (facture.client.siret || '[SIRET de l\'entreprise]'), 20, 160);
    } else {
      doc.text(`${beneficiaire.prenom} ${beneficiaire.nom}`, 20, 130);
      doc.text(beneficiaire.adresse || '[Adresse du bénéficiaire]', 20, 140);
      doc.text(beneficiaire.codePostal + ' ' + beneficiaire.ville, 20, 150);
    }
    
    // Détails de la facture
    doc.setFontSize(documentStyles.subtitleFontSize);
    doc.setTextColor(documentStyles.secondaryColor);
    doc.text('Détails de la prestation', 20, 180);
    
    // Tableau des prestations
    const headers = [['Description', 'Quantité', 'Prix unitaire HT', 'TVA', 'Total HT']];
    const data = facture.lignes.map(ligne => [
      ligne.description,
      ligne.quantite.toString(),
      formatAmount(ligne.prixUnitaire),
      ligne.tauxTVA + '%',
      formatAmount(ligne.prixUnitaire * ligne.quantite)
    ]);
    
    autoTable(doc, {
      head: headers,
      body: data,
      startY: 190,
      theme: 'grid',
      headStyles: {
        fillColor: documentStyles.secondaryColor,
        textColor: '#ffffff',
        fontStyle: 'bold'
      },
      styles: {
        font: documentStyles.fontFamily,
        fontSize: documentStyles.smallFontSize
      }
    });
    
    // Calculs des totaux
    const totalHT = facture.lignes.reduce((total, ligne) => total + (ligne.prixUnitaire * ligne.quantite), 0);
    const totalTVA = facture.lignes.reduce((total, ligne) => total + (ligne.prixUnitaire * ligne.quantite * ligne.tauxTVA / 100), 0);
    const totalTTC = totalHT + totalTVA;
    
    // Tableau des totaux
    const finalY = doc.lastAutoTable.finalY + 10;
    
    autoTable(doc, {
      body: [
        ['Total HT', formatAmount(totalHT)],
        ['TVA', formatAmount(totalTVA)],
        ['Total TTC', formatAmount(totalTTC)]
      ],
      startY: finalY,
      theme: 'grid',
      styles: {
        font: documentStyles.fontFamily,
        fontSize: documentStyles.smallFontSize
      },
      columnStyles: {
        0: { fontStyle: 'bold', cellWidth: 150 },
        1: { halign: 'right', cellWidth: 40 }
      },
      margin: { left: doc.internal.pageSize.width - 190 }
    });
    
    // Informations de paiement
    const paymentY = doc.lastAutoTable.finalY + 20;
    
    doc.setFontSize(documentStyles.subtitleFontSize);
    doc.setTextColor(documentStyles.secondaryColor);
    doc.text('Informations de paiement', 20, paymentY);
    
    doc.setFontSize(documentStyles.normalFontSize);
    doc.setTextColor(documentStyles.primaryColor);
    doc.text('Mode de paiement : ' + (facture.modePaiement || 'Virement bancaire'), 20, paymentY + 10);
    doc.text('Date d\'échéance : ' + formatDate(facture.dateEcheance), 20, paymentY + 20);
    
    // Coordonnées bancaires
    doc.text('Coordonnées bancaires :', 20, paymentY + 40);
    doc.text('IBAN : [IBAN de votre organisme]', 20, paymentY + 50);
    doc.text('BIC : [BIC de votre organisme]', 20, paymentY + 60);
    doc.text('Banque : [Nom de votre banque]', 20, paymentY + 70);
    
    // Mentions légales
    const legalY = paymentY + 90;
    
    doc.setFontSize(documentStyles.smallFontSize);
    doc.setTextColor(documentStyles.primaryColor);
    const mentionsLegales = 'En cas de retard de paiement, seront exigibles, conformément à l\'article L 441-6 du Code de Commerce, une indemnité calculée sur la base de trois fois le taux d\'intérêt légal en vigueur ainsi qu\'une indemnité forfaitaire pour frais de recouvrement de 40 euros.';
    const mentionsLines = doc.splitTextToSize(mentionsLegales, doc.internal.pageSize.width - 40);
    doc.text(mentionsLines, 20, legalY);
    
    // Pied de page
    const today = new Date();
    doc.setFontSize(documentStyles.smallFontSize);
    doc.setTextColor(documentStyles.primaryColor);
    doc.text(`Document généré le ${formatDate(today)}`, doc.internal.pageSize.width / 2, doc.internal.pageSize.height - 10, { align: 'center' });
    
    // Retourner le document
    return doc.output('blob');
  } catch (error) {
    console.error('Erreur lors de la génération de la facture:', error);
    throw new Error('Erreur lors de la génération du document');
  }
};

// Fonction pour télécharger un document
const downloadDocument = (blob, fileName) => {
  saveAs(blob, fileName);
};

// Fonction pour envoyer un document par email
const sendDocumentByEmail = async (documentBlob, fileName, emailData) => {
  try {
    // Convertir le blob en base64
    const reader = new FileReader();
    reader.readAsDataURL(documentBlob);
    
    return new Promise((resolve, reject) => {
      reader.onloadend = async () => {
        try {
          const base64data = reader.result.split(',')[1];
          
          // Envoyer l'email avec le document en pièce jointe
          const response = await axios.post('/api/emails/send', {
            to: emailData.to,
            subject: emailData.subject,
            message: emailData.message,
            attachments: [
              {
                filename: fileName,
                content: base64data,
                encoding: 'base64'
              }
            ]
          });
          
          resolve(response.data);
        } catch (error) {
          reject(error);
        }
      };
      
      reader.onerror = () => {
        reject(new Error('Erreur lors de la lecture du document'));
      };
    });
  } catch (error) {
    console.error('Erreur lors de l\'envoi du document par email:', error);
    throw new Error('Erreur lors de l\'envoi du document');
  }
};

export default {
  generateInformationPrealable,
  generateConventionTripartite,
  generateDocumentSynthese,
  generateRapportEvaluation,
  generateFacture,
  downloadDocument,
  sendDocumentByEmail
};
