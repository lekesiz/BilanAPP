// Service de sécurité pour la plateforme de bilans de compétences
import axios from 'axios';
import CryptoJS from 'crypto-js';
import { v4 as uuidv4 } from 'uuid';

// Clé de chiffrement pour le stockage local (sera remplacée par une clé d'environnement en production)
const ENCRYPTION_KEY = process.env.REACT_APP_ENCRYPTION_KEY || 'temporary-encryption-key-for-development';

/**
 * Chiffre des données sensibles
 * @param {any} data - Données à chiffrer
 * @returns {string} - Données chiffrées
 */
const encryptData = (data) => {
  try {
    const dataString = typeof data === 'object' ? JSON.stringify(data) : String(data);
    return CryptoJS.AES.encrypt(dataString, ENCRYPTION_KEY).toString();
  } catch (error) {
    console.error('Erreur lors du chiffrement des données:', error);
    throw new Error('Erreur lors du chiffrement des données');
  }
};

/**
 * Déchiffre des données sensibles
 * @param {string} encryptedData - Données chiffrées
 * @returns {any} - Données déchiffrées
 */
const decryptData = (encryptedData) => {
  try {
    const bytes = CryptoJS.AES.decrypt(encryptedData, ENCRYPTION_KEY);
    const decryptedString = bytes.toString(CryptoJS.enc.Utf8);
    
    try {
      // Tenter de parser en JSON si possible
      return JSON.parse(decryptedString);
    } catch {
      // Sinon retourner la chaîne déchiffrée
      return decryptedString;
    }
  } catch (error) {
    console.error('Erreur lors du déchiffrement des données:', error);
    throw new Error('Erreur lors du déchiffrement des données');
  }
};

/**
 * Anonymise les données personnelles d'un bénéficiaire
 * @param {Object} beneficiaire - Données du bénéficiaire
 * @returns {Object} - Données anonymisées
 */
const anonymizeBeneficiaireData = (beneficiaire) => {
  if (!beneficiaire) return null;
  
  // Générer un identifiant anonyme unique
  const anonymousId = uuidv4();
  
  // Créer une version anonymisée du bénéficiaire
  const anonymizedBeneficiaire = {
    id: anonymousId,
    // Conserver uniquement les données non-identifiantes
    dateCreation: beneficiaire.dateCreation,
    dateDerniereMaj: beneficiaire.dateDerniereMaj,
    statut: beneficiaire.statut,
    // Anonymiser les données sensibles
    secteurActivite: beneficiaire.secteurActivite || 'Non spécifié',
    niveauEtudes: beneficiaire.niveauEtudes || 'Non spécifié',
    trancheAge: beneficiaire.trancheAge || 'Non spécifié',
    // Supprimer complètement les données personnelles
    nom: null,
    prenom: null,
    email: null,
    telephone: null,
    adresse: null,
    codePostal: null,
    ville: null,
    dateNaissance: null,
    numeroSecuriteSociale: null
  };
  
  return anonymizedBeneficiaire;
};

/**
 * Journalise les accès aux données sensibles
 * @param {string} userId - ID de l'utilisateur accédant aux données
 * @param {string} action - Action effectuée (lecture, modification, suppression)
 * @param {string} resourceType - Type de ressource (bénéficiaire, évaluation, document)
 * @param {string} resourceId - ID de la ressource
 * @returns {Promise<void>}
 */
const logDataAccess = async (userId, action, resourceType, resourceId) => {
  try {
    const logEntry = {
      userId,
      action,
      resourceType,
      resourceId,
      timestamp: new Date().toISOString(),
      ipAddress: window.sessionStorage.getItem('user_ip') || 'unknown'
    };
    
    // Envoyer le journal au serveur
    await axios.post('/api/security/logs', logEntry);
    
    // Stocker également en local pour la résilience
    const localLogs = JSON.parse(localStorage.getItem('data_access_logs') || '[]');
    localLogs.push(logEntry);
    localStorage.setItem('data_access_logs', JSON.stringify(localLogs));
  } catch (error) {
    console.error('Erreur lors de la journalisation de l\'accès aux données:', error);
    // Continuer malgré l'erreur pour ne pas bloquer l'application
  }
};

/**
 * Vérifie les autorisations d'accès aux données
 * @param {string} userId - ID de l'utilisateur
 * @param {string} action - Action demandée (read, write, delete)
 * @param {string} resourceType - Type de ressource
 * @param {string} resourceId - ID de la ressource
 * @returns {Promise<boolean>} - Autorisation accordée ou non
 */
const checkPermission = async (userId, action, resourceType, resourceId) => {
  try {
    const response = await axios.post('/api/security/check-permission', {
      userId,
      action,
      resourceType,
      resourceId
    });
    
    return response.data.granted === true;
  } catch (error) {
    console.error('Erreur lors de la vérification des autorisations:', error);
    return false; // Par défaut, refuser l'accès en cas d'erreur
  }
};

/**
 * Détecte et bloque les tentatives d'accès suspects
 * @param {string} userId - ID de l'utilisateur
 * @param {string} action - Action tentée
 * @returns {Promise<boolean>} - true si l'accès est autorisé, false sinon
 */
const detectSuspiciousActivity = async (userId, action) => {
  try {
    // Récupérer l'historique récent des actions de l'utilisateur
    const localLogs = JSON.parse(localStorage.getItem('data_access_logs') || '[]');
    const userLogs = localLogs.filter(log => log.userId === userId);
    
    // Vérifier le nombre d'actions dans les 5 dernières minutes
    const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000).toISOString();
    const recentLogs = userLogs.filter(log => log.timestamp > fiveMinutesAgo);
    
    // Si plus de 50 actions en 5 minutes, considérer comme suspect
    if (recentLogs.length > 50) {
      // Signaler l'activité suspecte
      await axios.post('/api/security/suspicious-activity', {
        userId,
        action,
        recentActivityCount: recentLogs.length,
        timestamp: new Date().toISOString()
      });
      
      return false; // Bloquer l'accès
    }
    
    return true; // Autoriser l'accès
  } catch (error) {
    console.error('Erreur lors de la détection d\'activité suspecte:', error);
    return true; // En cas d'erreur, autoriser l'accès pour éviter de bloquer l'application
  }
};

/**
 * Gère le consentement RGPD des utilisateurs
 * @param {string} userId - ID de l'utilisateur
 * @param {Object} consentData - Données de consentement
 * @returns {Promise<void>}
 */
const manageUserConsent = async (userId, consentData) => {
  try {
    // Enregistrer le consentement sur le serveur
    await axios.post('/api/security/user-consent', {
      userId,
      consentData,
      timestamp: new Date().toISOString()
    });
    
    // Stocker également en local
    localStorage.setItem(`user_consent_${userId}`, JSON.stringify({
      ...consentData,
      timestamp: new Date().toISOString()
    }));
  } catch (error) {
    console.error('Erreur lors de l\'enregistrement du consentement utilisateur:', error);
    throw new Error('Erreur lors de l\'enregistrement du consentement');
  }
};

/**
 * Vérifie si l'utilisateur a donné son consentement
 * @param {string} userId - ID de l'utilisateur
 * @returns {Promise<Object>} - Données de consentement
 */
const checkUserConsent = async (userId) => {
  try {
    // Vérifier d'abord en local
    const localConsent = localStorage.getItem(`user_consent_${userId}`);
    if (localConsent) {
      return JSON.parse(localConsent);
    }
    
    // Sinon, vérifier sur le serveur
    const response = await axios.get(`/api/security/user-consent/${userId}`);
    
    if (response.data && response.data.consentData) {
      // Mettre à jour le stockage local
      localStorage.setItem(`user_consent_${userId}`, JSON.stringify(response.data));
      return response.data;
    }
    
    return null; // Aucun consentement trouvé
  } catch (error) {
    console.error('Erreur lors de la vérification du consentement utilisateur:', error);
    return null;
  }
};

/**
 * Supprime les données d'un utilisateur (droit à l'oubli)
 * @param {string} userId - ID de l'utilisateur
 * @returns {Promise<boolean>} - Succès ou échec
 */
const deleteUserData = async (userId) => {
  try {
    // Supprimer les données sur le serveur
    await axios.delete(`/api/security/user-data/${userId}`);
    
    // Supprimer les données locales
    const keysToRemove = [];
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key.includes(userId)) {
        keysToRemove.push(key);
      }
    }
    
    keysToRemove.forEach(key => localStorage.removeItem(key));
    
    return true;
  } catch (error) {
    console.error('Erreur lors de la suppression des données utilisateur:', error);
    return false;
  }
};

/**
 * Exporte les données d'un utilisateur (droit à la portabilité)
 * @param {string} userId - ID de l'utilisateur
 * @returns {Promise<Object>} - Données exportées
 */
const exportUserData = async (userId) => {
  try {
    // Récupérer les données du serveur
    const response = await axios.get(`/api/security/export-user-data/${userId}`);
    
    if (response.data) {
      // Formater les données pour l'export
      const exportData = {
        userData: response.data,
        exportDate: new Date().toISOString(),
        exportFormat: 'JSON'
      };
      
      return exportData;
    }
    
    throw new Error('Aucune donnée trouvée pour cet utilisateur');
  } catch (error) {
    console.error('Erreur lors de l\'exportation des données utilisateur:', error);
    throw new Error('Erreur lors de l\'exportation des données');
  }
};

/**
 * Vérifie la force d'un mot de passe
 * @param {string} password - Mot de passe à vérifier
 * @returns {Object} - Résultat de l'analyse avec score et suggestions
 */
const checkPasswordStrength = (password) => {
  if (!password) {
    return {
      score: 0,
      isStrong: false,
      suggestions: ['Veuillez entrer un mot de passe']
    };
  }
  
  let score = 0;
  const suggestions = [];
  
  // Longueur minimale
  if (password.length < 8) {
    suggestions.push('Le mot de passe doit contenir au moins 8 caractères');
  } else {
    score += 1;
  }
  
  // Présence de lettres minuscules
  if (!/[a-z]/.test(password)) {
    suggestions.push('Ajoutez des lettres minuscules');
  } else {
    score += 1;
  }
  
  // Présence de lettres majuscules
  if (!/[A-Z]/.test(password)) {
    suggestions.push('Ajoutez des lettres majuscules');
  } else {
    score += 1;
  }
  
  // Présence de chiffres
  if (!/[0-9]/.test(password)) {
    suggestions.push('Ajoutez des chiffres');
  } else {
    score += 1;
  }
  
  // Présence de caractères spéciaux
  if (!/[^A-Za-z0-9]/.test(password)) {
    suggestions.push('Ajoutez des caractères spéciaux');
  } else {
    score += 1;
  }
  
  // Vérifier si le mot de passe est courant
  const commonPasswords = ['Password123', 'Azerty123', '12345678', 'Qwerty123'];
  if (commonPasswords.includes(password)) {
    score = 0;
    suggestions.push('Ce mot de passe est trop courant, choisissez-en un plus unique');
  }
  
  return {
    score,
    isStrong: score >= 4,
    suggestions: suggestions.length > 0 ? suggestions : ['Mot de passe fort']
  };
};

/**
 * Génère un jeton d'authentification sécurisé
 * @returns {string} - Jeton généré
 */
const generateSecureToken = () => {
  const randomBytes = CryptoJS.lib.WordArray.random(32);
  return randomBytes.toString(CryptoJS.enc.Hex);
};

/**
 * Nettoie les données sensibles de la session
 */
const clearSensitiveData = () => {
  // Supprimer les données sensibles du stockage local
  const keysToRemove = [
    'user_token',
    'user_data',
    'current_beneficiaire',
    'current_evaluation'
  ];
  
  keysToRemove.forEach(key => {
    localStorage.removeItem(key);
    sessionStorage.removeItem(key);
  });
  
  // Effacer également les cookies sensibles
  document.cookie.split(';').forEach(cookie => {
    const [name] = cookie.split('=');
    if (keysToRemove.some(key => name.trim().includes(key))) {
      document.cookie = `${name}=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;`;
    }
  });
};

/**
 * Vérifie si une session est active et valide
 * @returns {boolean} - Session valide ou non
 */
const isSessionValid = () => {
  const sessionToken = localStorage.getItem('session_token');
  if (!sessionToken) return false;
  
  try {
    const sessionData = JSON.parse(atob(sessionToken.split('.')[1]));
    const expirationTime = sessionData.exp * 1000; // Convertir en millisecondes
    
    return Date.now() < expirationTime;
  } catch (error) {
    console.error('Erreur lors de la vérification de la session:', error);
    return false;
  }
};

/**
 * Applique une politique de sécurité pour les requêtes API
 * @param {Object} axiosInstance - Instance Axios à configurer
 * @returns {Object} - Instance Axios configurée
 */
const configureSecureApiRequests = (axiosInstance) => {
  // Intercepteur pour les requêtes
  axiosInstance.interceptors.request.use(
    config => {
      // Ajouter le jeton d'authentification
      const token = localStorage.getItem('user_token');
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
      }
      
      // Ajouter un en-tête anti-CSRF
      const csrfToken = localStorage.getItem('csrf_token');
      if (csrfToken) {
        config.headers['X-CSRF-Token'] = csrfToken;
      }
      
      // Ajouter un identifiant de requête unique
      config.headers['X-Request-ID'] = uuidv4();
      
      return config;
    },
    error => Promise.reject(error)
  );
  
  // Intercepteur pour les réponses
  axiosInstance.interceptors.response.use(
    response => {
      // Mettre à jour le jeton CSRF si présent dans la réponse
      const newCsrfToken = response.headers['x-csrf-token'];
      if (newCsrfToken) {
        localStorage.setItem('csrf_token', newCsrfToken);
      }
      
      return response;
    },
    error => {
      // Gérer les erreurs d'authentification
      if (error.response && error.response.status === 401) {
        // Effacer les données de session
        clearSensitiveData();
        // Rediriger vers la page de connexion
        window.location.href = '/login';
      }
      
      return Promise.reject(error);
    }
  );
  
  return axiosInstance;
};

export default {
  encryptData,
  decryptData,
  anonymizeBeneficiaireData,
  logDataAccess,
  checkPermission,
  detectSuspiciousActivity,
  manageUserConsent,
  checkUserConsent,
  deleteUserData,
  exportUserData,
  checkPasswordStrength,
  generateSecureToken,
  clearSensitiveData,
  isSessionValid,
  configureSecureApiRequests
};
