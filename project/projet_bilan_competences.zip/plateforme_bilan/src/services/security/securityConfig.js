// Configuration de sécurité pour l'application
import axios from 'axios';
import securityService from './securityService';

// Configurer l'instance Axios globale avec les mesures de sécurité
const configureAppSecurity = () => {
  // Appliquer la politique de sécurité pour les requêtes API
  securityService.configureSecureApiRequests(axios);
  
  // Configurer les en-têtes de sécurité pour l'application
  configureSecurityHeaders();
  
  // Mettre en place la détection d'inactivité
  setupInactivityDetection();
  
  // Configurer la gestion des erreurs de sécurité
  setupSecurityErrorHandling();
  
  // Initialiser la journalisation de sécurité
  initializeSecurityLogging();
  
  console.log('Configuration de sécurité appliquée avec succès');
};

// Configurer les en-têtes de sécurité pour l'application
const configureSecurityHeaders = () => {
  // Ces en-têtes seraient normalement définis côté serveur
  // Mais nous les simulons ici pour la démonstration
  
  // Content Security Policy pour prévenir les attaques XSS
  const csp = [
    "default-src 'self'",
    "script-src 'self' https://apis.google.com",
    "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
    "font-src 'self' https://fonts.gstatic.com",
    "img-src 'self' data: https://secure.gravatar.com",
    "connect-src 'self' https://api.pennylane.com https://www.googleapis.com",
    "frame-src 'self' https://accounts.google.com"
  ].join('; ');
  
  // Simuler l'application des en-têtes (normalement fait côté serveur)
  console.log('En-têtes de sécurité qui seraient appliqués:');
  console.log('Content-Security-Policy:', csp);
  console.log('X-Content-Type-Options: nosniff');
  console.log('X-Frame-Options: DENY');
  console.log('X-XSS-Protection: 1; mode=block');
  console.log('Strict-Transport-Security: max-age=31536000; includeSubDomains');
  console.log('Referrer-Policy: strict-origin-when-cross-origin');
};

// Mettre en place la détection d'inactivité
const setupInactivityDetection = () => {
  let inactivityTimer;
  const inactivityTimeout = 30 * 60 * 1000; // 30 minutes
  
  const resetInactivityTimer = () => {
    clearTimeout(inactivityTimer);
    inactivityTimer = setTimeout(() => {
      // Déconnecter l'utilisateur après la période d'inactivité
      console.log('Inactivité détectée, déconnexion...');
      securityService.clearSensitiveData();
      window.location.href = '/login?reason=inactivity';
    }, inactivityTimeout);
  };
  
  // Réinitialiser le minuteur à chaque activité de l'utilisateur
  const activityEvents = ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart'];
  activityEvents.forEach(event => {
    document.addEventListener(event, resetInactivityTimer, true);
  });
  
  // Initialiser le minuteur
  resetInactivityTimer();
};

// Configurer la gestion des erreurs de sécurité
const setupSecurityErrorHandling = () => {
  // Intercepter les erreurs non gérées
  window.addEventListener('error', (event) => {
    // Journaliser l'erreur de manière sécurisée (sans informations sensibles)
    const sanitizedError = {
      message: event.message,
      source: event.filename,
      lineNumber: event.lineno,
      timestamp: new Date().toISOString()
    };
    
    console.error('Erreur de sécurité détectée:', sanitizedError);
    
    // Envoyer l'erreur au serveur pour analyse
    // axios.post('/api/security/error-log', sanitizedError);
    
    // Stocker localement pour la résilience
    const errorLogs = JSON.parse(localStorage.getItem('security_error_logs') || '[]');
    errorLogs.push(sanitizedError);
    localStorage.setItem('security_error_logs', JSON.stringify(errorLogs));
  });
  
  // Intercepter les rejets de promesse non gérés
  window.addEventListener('unhandledrejection', (event) => {
    // Journaliser l'erreur de manière sécurisée
    const sanitizedError = {
      message: event.reason ? (event.reason.message || 'Rejet de promesse non géré') : 'Rejet de promesse non géré',
      timestamp: new Date().toISOString()
    };
    
    console.error('Rejet de promesse non géré:', sanitizedError);
    
    // Envoyer l'erreur au serveur pour analyse
    // axios.post('/api/security/error-log', sanitizedError);
    
    // Stocker localement pour la résilience
    const errorLogs = JSON.parse(localStorage.getItem('security_error_logs') || '[]');
    errorLogs.push(sanitizedError);
    localStorage.setItem('security_error_logs', JSON.stringify(errorLogs));
  });
};

// Initialiser la journalisation de sécurité
const initializeSecurityLogging = () => {
  // Stocker l'adresse IP de l'utilisateur (normalement fournie par le serveur)
  fetch('https://api.ipify.org?format=json')
    .then(response => response.json())
    .then(data => {
      window.sessionStorage.setItem('user_ip', data.ip);
    })
    .catch(error => {
      console.error('Erreur lors de la récupération de l\'adresse IP:', error);
      window.sessionStorage.setItem('user_ip', 'unknown');
    });
  
  // Journaliser les événements de connexion/déconnexion
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') {
      // L'utilisateur est revenu sur la page
      console.log('Utilisateur actif sur la page:', new Date().toISOString());
    } else {
      // L'utilisateur a quitté la page
      console.log('Utilisateur inactif sur la page:', new Date().toISOString());
    }
  });
};

export default {
  configureAppSecurity
};
