// Service d'intégration avec Google Workspace
import { google } from 'googleapis';
import { OAuth2Client } from 'google-auth-library';

// Configuration des identifiants OAuth
const CLIENT_ID = process.env.GOOGLE_CLIENT_ID;
const CLIENT_SECRET = process.env.GOOGLE_CLIENT_SECRET;
const REDIRECT_URI = process.env.GOOGLE_REDIRECT_URI;

// Scopes requis pour les différentes API Google
const SCOPES = [
  'https://www.googleapis.com/auth/userinfo.email',
  'https://www.googleapis.com/auth/userinfo.profile',
  'https://www.googleapis.com/auth/calendar',
  'https://www.googleapis.com/auth/drive.file',
  'https://www.googleapis.com/auth/drive.appdata'
];

// Création du client OAuth2
const createOAuth2Client = (tokens = null) => {
  const oAuth2Client = new OAuth2Client(CLIENT_ID, CLIENT_SECRET, REDIRECT_URI);
  
  if (tokens) {
    oAuth2Client.setCredentials(tokens);
  }
  
  return oAuth2Client;
};

// Générer l'URL d'authentification
const generateAuthUrl = () => {
  const oAuth2Client = createOAuth2Client();
  
  return oAuth2Client.generateAuthUrl({
    access_type: 'offline',
    scope: SCOPES,
    prompt: 'consent'
  });
};

// Échanger le code d'autorisation contre des tokens
const getTokens = async (code) => {
  const oAuth2Client = createOAuth2Client();
  const { tokens } = await oAuth2Client.getToken(code);
  return tokens;
};

// Obtenir les informations de l'utilisateur Google
const getUserInfo = async (tokens) => {
  const oAuth2Client = createOAuth2Client(tokens);
  const oauth2 = google.oauth2({ version: 'v2', auth: oAuth2Client });
  const { data } = await oauth2.userinfo.get();
  return data;
};

// Créer un événement dans Google Calendar
const createCalendarEvent = async (tokens, event) => {
  const oAuth2Client = createOAuth2Client(tokens);
  const calendar = google.calendar({ version: 'v3', auth: oAuth2Client });
  
  const calendarEvent = {
    summary: event.title,
    description: event.description,
    start: {
      dateTime: event.startDateTime,
      timeZone: 'Europe/Paris'
    },
    end: {
      dateTime: event.endDateTime,
      timeZone: 'Europe/Paris'
    },
    attendees: event.attendees.map(email => ({ email })),
    reminders: {
      useDefault: false,
      overrides: [
        { method: 'email', minutes: 24 * 60 },
        { method: 'popup', minutes: 30 }
      ]
    }
  };
  
  // Si un lien de visioconférence est demandé
  if (event.addConference) {
    calendarEvent.conferenceData = {
      createRequest: {
        requestId: `${Date.now()}-${Math.random().toString(36).substring(2, 11)}`,
        conferenceSolutionKey: { type: 'hangoutsMeet' }
      }
    };
  }
  
  const response = await calendar.events.insert({
    calendarId: 'primary',
    resource: calendarEvent,
    conferenceDataVersion: event.addConference ? 1 : 0,
    sendUpdates: 'all'
  });
  
  return response.data;
};

// Mettre à jour un événement dans Google Calendar
const updateCalendarEvent = async (tokens, eventId, event) => {
  const oAuth2Client = createOAuth2Client(tokens);
  const calendar = google.calendar({ version: 'v3', auth: oAuth2Client });
  
  const calendarEvent = {
    summary: event.title,
    description: event.description,
    start: {
      dateTime: event.startDateTime,
      timeZone: 'Europe/Paris'
    },
    end: {
      dateTime: event.endDateTime,
      timeZone: 'Europe/Paris'
    },
    attendees: event.attendees.map(email => ({ email }))
  };
  
  const response = await calendar.events.update({
    calendarId: 'primary',
    eventId: eventId,
    resource: calendarEvent,
    sendUpdates: 'all'
  });
  
  return response.data;
};

// Supprimer un événement dans Google Calendar
const deleteCalendarEvent = async (tokens, eventId) => {
  const oAuth2Client = createOAuth2Client(tokens);
  const calendar = google.calendar({ version: 'v3', auth: oAuth2Client });
  
  await calendar.events.delete({
    calendarId: 'primary',
    eventId: eventId,
    sendUpdates: 'all'
  });
  
  return { success: true };
};

// Obtenir les événements du calendrier
const getCalendarEvents = async (tokens, timeMin, timeMax) => {
  const oAuth2Client = createOAuth2Client(tokens);
  const calendar = google.calendar({ version: 'v3', auth: oAuth2Client });
  
  const response = await calendar.events.list({
    calendarId: 'primary',
    timeMin: timeMin || new Date().toISOString(),
    timeMax: timeMax,
    singleEvents: true,
    orderBy: 'startTime'
  });
  
  return response.data.items;
};

// Créer un fichier dans Google Drive
const createDriveFile = async (tokens, file, folderId = null) => {
  const oAuth2Client = createOAuth2Client(tokens);
  const drive = google.drive({ version: 'v3', auth: oAuth2Client });
  
  const fileMetadata = {
    name: file.name,
    mimeType: file.mimeType
  };
  
  // Si un dossier parent est spécifié
  if (folderId) {
    fileMetadata.parents = [folderId];
  }
  
  const media = {
    mimeType: file.mimeType,
    body: file.content
  };
  
  const response = await drive.files.create({
    resource: fileMetadata,
    media: media,
    fields: 'id, name, webViewLink'
  });
  
  return response.data;
};

// Créer un dossier dans Google Drive
const createDriveFolder = async (tokens, folderName, parentFolderId = null) => {
  const oAuth2Client = createOAuth2Client(tokens);
  const drive = google.drive({ version: 'v3', auth: oAuth2Client });
  
  const folderMetadata = {
    name: folderName,
    mimeType: 'application/vnd.google-apps.folder'
  };
  
  // Si un dossier parent est spécifié
  if (parentFolderId) {
    folderMetadata.parents = [parentFolderId];
  }
  
  const response = await drive.files.create({
    resource: folderMetadata,
    fields: 'id, name, webViewLink'
  });
  
  return response.data;
};

// Partager un fichier ou dossier Drive
const shareDriveFile = async (tokens, fileId, email, role = 'reader') => {
  const oAuth2Client = createOAuth2Client(tokens);
  const drive = google.drive({ version: 'v3', auth: oAuth2Client });
  
  const permission = {
    type: 'user',
    role: role,
    emailAddress: email
  };
  
  const response = await drive.permissions.create({
    fileId: fileId,
    resource: permission,
    sendNotificationEmail: true
  });
  
  return response.data;
};

// Obtenir un lien de visioconférence Google Meet
const createMeetLink = async (tokens, meetingDetails) => {
  // Utiliser l'API Calendar pour créer un événement avec une conférence
  const event = {
    title: meetingDetails.title,
    description: meetingDetails.description,
    startDateTime: meetingDetails.startDateTime,
    endDateTime: meetingDetails.endDateTime,
    attendees: meetingDetails.attendees,
    addConference: true
  };
  
  const calendarEvent = await createCalendarEvent(tokens, event);
  
  // Extraire le lien Meet de l'événement créé
  const meetLink = calendarEvent.conferenceData?.entryPoints?.find(
    ep => ep.entryPointType === 'video'
  )?.uri;
  
  return {
    eventId: calendarEvent.id,
    meetLink: meetLink,
    calendarEvent: calendarEvent
  };
};

export default {
  generateAuthUrl,
  getTokens,
  getUserInfo,
  createCalendarEvent,
  updateCalendarEvent,
  deleteCalendarEvent,
  getCalendarEvents,
  createDriveFile,
  createDriveFolder,
  shareDriveFile,
  createMeetLink
};
