import React, { useState, useEffect } from 'react';
import { 
  Container, 
  Typography, 
  Box, 
  Grid, 
  Paper, 
  Button, 
  TextField, 
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Divider,
  Card,
  CardContent,
  CardHeader,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Alert,
  Snackbar,
  IconButton,
  Tooltip,
  CircularProgress
} from '@mui/material';
import { 
  Description as DescriptionIcon,
  Download as DownloadIcon,
  Email as EmailIcon,
  Print as PrintIcon,
  PictureAsPdf as PdfIcon,
  Assignment as AssignmentIcon,
  Receipt as ReceiptIcon,
  Assessment as AssessmentIcon,
  Handshake as HandshakeIcon
} from '@mui/icons-material';
import { useParams } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import documentService from '../../services/documents/documentService';
import beneficiaireService from '../../services/beneficiaireService';
import evaluationService from '../../services/evaluationService';
import Loader from '../common/Loader';
import ErrorAlert from '../common/ErrorAlert';

const DocumentGenerator = () => {
  const { beneficiaireId } = useParams();
  const { user } = useAuth();
  
  // États
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState(null);
  const [beneficiaire, setBeneficiaire] = useState(null);
  const [consultant, setConsultant] = useState(null);
  const [bilan, setBilan] = useState(null);
  const [evaluations, setEvaluations] = useState([]);
  const [selectedEvaluation, setSelectedEvaluation] = useState('');
  const [evaluationResultats, setEvaluationResultats] = useState(null);
  const [employeur, setEmployeur] = useState(null);
  const [financement, setFinancement] = useState(null);
  const [facture, setFacture] = useState(null);
  const [showEmailDialog, setShowEmailDialog] = useState(false);
  const [emailData, setEmailData] = useState({
    to: '',
    subject: '',
    message: ''
  });
  const [currentDocument, setCurrentDocument] = useState({
    type: '',
    blob: null,
    fileName: ''
  });
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success'
  });

  // Charger les données du bénéficiaire
  useEffect(() => {
    const loadBeneficiaireData = async () => {
      try {
        setLoading(true);
        setError(null);
        
        // Charger les données du bénéficiaire
        const beneficiaireData = await beneficiaireService.getBeneficiaireById(beneficiaireId);
        setBeneficiaire(beneficiaireData);
        
        // Charger les données du consultant (utilisateur actuel)
        setConsultant(user);
        
        // Charger les données du bilan
        if (beneficiaireData.bilan) {
          setBilan(beneficiaireData.bilan);
        }
        
        // Charger les données de l'employeur si disponible
        if (beneficiaireData.employeur) {
          setEmployeur(beneficiaireData.employeur);
        }
        
        // Charger les données de financement si disponible
        if (beneficiaireData.financement) {
          setFinancement(beneficiaireData.financement);
        }
        
        // Charger les données de facturation si disponible
        if (beneficiaireData.factures && beneficiaireData.factures.length > 0) {
          setFacture(beneficiaireData.factures[0]);
        }
        
        // Charger les évaluations du bénéficiaire
        const evaluationsData = await evaluationService.getBeneficiaireEvaluations(beneficiaireId);
        setEvaluations(evaluationsData);
        
        setLoading(false);
      } catch (err) {
        setError(err.message || 'Une erreur est survenue lors du chargement des données');
        setLoading(false);
      }
    };

    loadBeneficiaireData();
  }, [beneficiaireId, user]);

  // Charger les résultats d'une évaluation
  const loadEvaluationResults = async (evaluationId) => {
    try {
      setLoading(true);
      setError(null);
      
      const resultats = await evaluationService.getEvaluationResults(beneficiaireId, evaluationId);
      setEvaluationResultats(resultats);
      
      setLoading(false);
    } catch (err) {
      setError(err.message || 'Une erreur est survenue lors du chargement des résultats d\'évaluation');
      setLoading(false);
    }
  };

  // Gestionnaires d'événements
  const handleEvaluationChange = (e) => {
    const evaluationId = e.target.value;
    setSelectedEvaluation(evaluationId);
    
    if (evaluationId) {
      loadEvaluationResults(evaluationId);
    } else {
      setEvaluationResultats(null);
    }
  };

  const handleGenerateDocument = async (documentType) => {
    try {
      setGenerating(true);
      setError(null);
      
      let documentBlob;
      let fileName;
      
      switch (documentType) {
        case 'information':
          documentBlob = await documentService.generateInformationPrealable(beneficiaire, consultant);
          fileName = `Information_Prealable_${beneficiaire.nom}_${beneficiaire.prenom}.pdf`;
          break;
        case 'convention':
          documentBlob = await documentService.generateConventionTripartite(beneficiaire, consultant, employeur, financement);
          fileName = `Convention_Tripartite_${beneficiaire.nom}_${beneficiaire.prenom}.pdf`;
          break;
        case 'synthese':
          documentBlob = await documentService.generateDocumentSynthese(beneficiaire, consultant, bilan);
          fileName = `Document_Synthese_${beneficiaire.nom}_${beneficiaire.prenom}.pdf`;
          break;
        case 'evaluation':
          if (!selectedEvaluation || !evaluationResultats) {
            throw new Error('Veuillez sélectionner une évaluation');
          }
          
          const evaluation = evaluations.find(e => e.id === selectedEvaluation);
          documentBlob = await documentService.generateRapportEvaluation(beneficiaire, evaluation, evaluationResultats);
          fileName = `Rapport_Evaluation_${evaluation.titre}_${beneficiaire.nom}_${beneficiaire.prenom}.pdf`;
          break;
        case 'facture':
          if (!facture) {
            throw new Error('Aucune facture disponible pour ce bénéficiaire');
          }
          
          documentBlob = await documentService.generateFacture(beneficiaire, consultant, facture);
          fileName = `Facture_${facture.numero}_${beneficiaire.nom}_${beneficiaire.prenom}.pdf`;
          break;
        default:
          throw new Error('Type de document non reconnu');
      }
      
      setCurrentDocument({
        type: documentType,
        blob: documentBlob,
        fileName: fileName
      });
      
      setGenerating(false);
      setSnackbar({
        open: true,
        message: 'Document généré avec succès',
        severity: 'success'
      });
    } catch (err) {
      setError(err.message || 'Une erreur est survenue lors de la génération du document');
      setGenerating(false);
    }
  };

  const handleDownloadDocument = () => {
    if (currentDocument.blob && currentDocument.fileName) {
      documentService.downloadDocument(currentDocument.blob, currentDocument.fileName);
      
      setSnackbar({
        open: true,
        message: 'Document téléchargé avec succès',
        severity: 'success'
      });
    }
  };

  const handleOpenEmailDialog = () => {
    if (currentDocument.blob && currentDocument.fileName) {
      setEmailData({
        to: beneficiaire.email || '',
        subject: `Votre document : ${currentDocument.fileName}`,
        message: `Bonjour ${beneficiaire.prenom},\n\nVeuillez trouver ci-joint le document ${currentDocument.fileName} relatif à votre bilan de compétences.\n\nCordialement,\n${consultant.prenom} ${consultant.nom}`
      });
      
      setShowEmailDialog(true);
    }
  };

  const handleCloseEmailDialog = () => {
    setShowEmailDialog(false);
  };

  const handleEmailChange = (e) => {
    const { name, value } = e.target;
    setEmailData({
      ...emailData,
      [name]: value
    });
  };

  const handleSendEmail = async () => {
    try {
      setGenerating(true);
      
      await documentService.sendDocumentByEmail(
        currentDocument.blob,
        currentDocument.fileName,
        {
          to: emailData.to,
          subject: emailData.subject,
          message: emailData.message
        }
      );
      
      setShowEmailDialog(false);
      setGenerating(false);
      setSnackbar({
        open: true,
        message: 'Document envoyé par email avec succès',
        severity: 'success'
      });
    } catch (err) {
      setError(err.message || 'Une erreur est survenue lors de l\'envoi du document par email');
      setGenerating(false);
    }
  };

  if (loading) return <Loader />;
  if (!beneficiaire) return <Typography>Bénéficiaire non trouvé</Typography>;

  return (
    <Container maxWidth="lg">
      <Box sx={{ my: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          Générateur de documents
        </Typography>
        <Typography variant="subtitle1" color="textSecondary" paragraph>
          Générez les documents nécessaires pour le bilan de compétences de {beneficiaire.prenom} {beneficiaire.nom}
        </Typography>
        
        {error && <ErrorAlert message={error} sx={{ mb: 3 }} />}
        
        <Grid container spacing={3}>
          <Grid item xs={12} md={4}>
            <Paper sx={{ p: 3, height: '100%' }}>
              <Typography variant="h6" gutterBottom>
                Types de documents
              </Typography>
              <List>
                <ListItem 
                  button 
                  onClick={() => handleGenerateDocument('information')}
                  disabled={generating}
                >
                  <ListItemIcon>
                    <DescriptionIcon color="primary" />
                  </ListItemIcon>
                  <ListItemText 
                    primary="Document d'information préalable" 
                    secondary="Informations sur le cadre légal et le déroulement du bilan" 
                  />
                </ListItem>
                <ListItem 
                  button 
                  onClick={() => handleGenerateDocument('convention')}
                  disabled={generating}
                >
                  <ListItemIcon>
                    <HandshakeIcon color="primary" />
                  </ListItemIcon>
                  <ListItemText 
                    primary="Convention tripartite" 
                    secondary="Convention entre le bénéficiaire, l'organisme et l'employeur" 
                  />
                </ListItem>
                <ListItem 
                  button 
                  onClick={() => handleGenerateDocument('synthese')}
                  disabled={generating || !bilan}
                >
                  <ListItemIcon>
                    <AssignmentIcon color="primary" />
                  </ListItemIcon>
                  <ListItemText 
                    primary="Document de synthèse" 
                    secondary="Synthèse des résultats du bilan de compétences" 
                  />
                  {!bilan && (
                    <Chip 
                      label="Bilan requis" 
                      size="small" 
                      color="warning" 
                      sx={{ ml: 1 }} 
                    />
                  )}
                </ListItem>
                <ListItem 
                  button 
                  onClick={() => handleGenerateDocument('evaluation')}
                  disabled={generating || !selectedEvaluation || !evaluationResultats}
                >
                  <ListItemIcon>
                    <AssessmentIcon color="primary" />
                  </ListItemIcon>
                  <ListItemText 
                    primary="Rapport d'évaluation" 
                    secondary="Résultats détaillés d'une évaluation spécifique" 
                  />
                  {(!selectedEvaluation || !evaluationResultats) && (
                    <Chip 
                      label="Évaluation requise" 
                      size="small" 
                      color="warning" 
                      sx={{ ml: 1 }} 
                    />
                  )}
                </ListItem>
                <ListItem 
                  button 
                  onClick={() => handleGenerateDocument('facture')}
                  disabled={generating || !facture}
                >
                  <ListItemIcon>
                    <ReceiptIcon color="primary" />
                  </ListItemIcon>
                  <ListItemText 
                    primary="Facture" 
                    secondary="Facture pour le bilan de compétences" 
                  />
                  {!facture && (
                    <Chip 
                      label="Facture requise" 
                      size="small" 
                      color="warning" 
                      sx={{ ml: 1 }} 
                    />
                  )}
                </ListItem>
              </List>
              
              {evaluations.length > 0 && (
                <Box sx={{ mt: 3 }}>
                  <FormControl fullWidth>
                    <InputLabel>Sélectionner une évaluation</InputLabel>
                    <Select
                      value={selectedEvaluation}
                      onChange={handleEvaluationChange}
                      label="Sélectionner une évaluation"
                    >
                      <MenuItem value="">
                        <em>Aucune</em>
                      </MenuItem>
                      {evaluations.map((evaluation) => (
                        <MenuItem key={evaluation.id} value={evaluation.id}>
                          {evaluation.titre}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                </Box>
              )}
            </Paper>
          </Grid>
          
          <Grid item xs={12} md={8}>
            <Paper sx={{ p: 3, height: '100%' }}>
              {generating ? (
                <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '100%', minHeight: 300 }}>
                  <CircularProgress size={60} />
                  <Typography variant="h6" sx={{ mt: 2 }}>
                    Génération du document en cours...
                  </Typography>
                </Box>
              ) : currentDocument.blob ? (
                <Box>
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
                    <PdfIcon fontSize="large" color="primary" sx={{ mr: 2 }} />
                    <Typography variant="h6">
                      {currentDocument.fileName}
                    </Typography>
                  </Box>
                  
                  <Box sx={{ display: 'flex', justifyContent: 'center', mb: 3 }}>
                    <iframe
                      src={URL.createObjectURL(currentDocument.blob)}
                      width="100%"
                      height="500px"
                      title="Aperçu du document"
                      style={{ border: '1px solid #e0e0e0' }}
                    />
                  </Box>
                  
                  <Box sx={{ display: 'flex', justifyContent: 'center' }}>
                    <Button
                      variant="contained"
                      color="primary"
                      startIcon={<DownloadIcon />}
                      onClick={handleDownloadDocument}
                      sx={{ mr: 2 }}
                    >
                      Télécharger
                    </Button>
                    <Button
                      variant="outlined"
                      color="primary"
                      startIcon={<EmailIcon />}
                      onClick={handleOpenEmailDialog}
                      sx={{ mr: 2 }}
                    >
                      Envoyer par email
                    </Button>
                    <Button
                      variant="outlined"
                      color="primary"
                      startIcon={<PrintIcon />}
                      onClick={() => {
                        const printWindow = window.open(URL.createObjectURL(currentDocument.blob), '_blank');
                        printWindow.print();
                      }}
                    >
                      Imprimer
                    </Button>
                  </Box>
                </Box>
              ) : (
                <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '100%', minHeight: 300 }}>
                  <DescriptionIcon fontSize="large" color="action" sx={{ mb: 2, fontSize: 80, opacity: 0.3 }} />
                  <Typography variant="h6" color="textSecondary">
                    Sélectionnez un type de document à générer
                  </Typography>
                </Box>
              )}
            </Paper>
          </Grid>
        </Grid>
      </Box>
      
      {/* Dialogue pour l'envoi par email */}
      <Dialog open={showEmailDialog} onClose={handleCloseEmailDialog} maxWidth="md" fullWidth>
        <DialogTitle>Envoyer le document par email</DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Destinataire"
                name="to"
                type="email"
                value={emailData.to}
                onChange={handleEmailChange}
                required
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Sujet"
                name="subject"
                value={emailData.subject}
                onChange={handleEmailChange}
                required
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Message"
                name="message"
                value={emailData.message}
                onChange={handleEmailChange}
                multiline
                rows={6}
                required
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseEmailDialog}>Annuler</Button>
          <Button 
            onClick={handleSendEmail} 
            variant="contained" 
            color="primary"
            disabled={!emailData.to || !emailData.subject || !emailData.message}
          >
            Envoyer
          </Button>
        </DialogActions>
      </Dialog>
      
      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
      >
        <Alert 
          onClose={() => setSnackbar({ ...snackbar, open: false })} 
          severity={snackbar.severity}
          sx={{ width: '100%' }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Container>
  );
};

export default DocumentGenerator;
