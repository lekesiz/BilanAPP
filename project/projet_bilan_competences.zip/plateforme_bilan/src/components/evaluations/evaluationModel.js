// Modèle de données pour les évaluations
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// Schéma pour les questions à choix multiples
const QCMQuestionSchema = new Schema({
  texte: {
    type: String,
    required: [true, 'Le texte de la question est requis']
  },
  options: [{
    texte: {
      type: String,
      required: [true, 'Le texte de l\'option est requis']
    },
    valeur: {
      type: Number,
      required: [true, 'La valeur de l\'option est requise']
    }
  }]
});

// Schéma pour les questions à échelle
const EchelleQuestionSchema = new Schema({
  texte: {
    type: String,
    required: [true, 'Le texte de la question est requis']
  },
  min: {
    type: Number,
    default: 1
  },
  max: {
    type: Number,
    default: 5
  },
  minLabel: {
    type: String,
    default: 'Pas du tout d\'accord'
  },
  maxLabel: {
    type: String,
    default: 'Tout à fait d\'accord'
  }
});

// Schéma pour les questions ouvertes
const QuestionOuverteSchema = new Schema({
  texte: {
    type: String,
    required: [true, 'Le texte de la question est requis']
  },
  indice: {
    type: String
  }
});

// Schéma pour les sections d'évaluation
const SectionEvaluationSchema = new Schema({
  titre: {
    type: String,
    required: [true, 'Le titre de la section est requis']
  },
  description: {
    type: String
  },
  questionsQCM: [QCMQuestionSchema],
  questionsEchelle: [EchelleQuestionSchema],
  questionsOuvertes: [QuestionOuverteSchema]
});

// Schéma principal pour les évaluations
const EvaluationSchema = new Schema({
  titre: {
    type: String,
    required: [true, 'Le titre de l\'évaluation est requis'],
    unique: true
  },
  description: {
    type: String,
    required: [true, 'La description de l\'évaluation est requise']
  },
  type: {
    type: String,
    enum: ['Auto-évaluation', 'Test personnalité', 'Grille compétences', 'Projection professionnelle'],
    required: [true, 'Le type d\'évaluation est requis']
  },
  instructions: {
    type: String
  },
  dureeEstimee: {
    type: Number, // en minutes
    default: 30
  },
  sections: [SectionEvaluationSchema],
  actif: {
    type: Boolean,
    default: true
  },
  
  // Métadonnées
  dateCreation: {
    type: Date,
    default: Date.now
  },
  derniereModification: {
    type: Date,
    default: Date.now
  },
  creePar: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  modifiePar: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Middleware pre-save pour mettre à jour la date de dernière modification
EvaluationSchema.pre('save', function(next) {
  this.derniereModification = Date.now();
  next();
});

// Virtuel pour le nombre total de questions
EvaluationSchema.virtual('nombreTotalQuestions').get(function() {
  let total = 0;
  this.sections.forEach(section => {
    total += section.questionsQCM.length + section.questionsEchelle.length + section.questionsOuvertes.length;
  });
  return total;
});

module.exports = mongoose.model('Evaluation', EvaluationSchema);
