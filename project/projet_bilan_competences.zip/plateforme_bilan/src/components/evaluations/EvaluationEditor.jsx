import React, { useState, useEffect } from 'react';
import { 
  Container, 
  Typography, 
  Box, 
  Grid, 
  Paper, 
  Button, 
  TextField, 
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Divider,
  Card,
  CardContent,
  CardHeader,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Alert,
  Snackbar,
  IconButton,
  Tooltip,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  FormControlLabel,
  Switch,
  Tabs,
  Tab
} from '@mui/material';
import { 
  Assignment as AssignmentIcon,
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Save as SaveIcon,
  ExpandMore as ExpandMoreIcon,
  AddCircle as AddCircleIcon,
  RemoveCircle as RemoveCircleIcon,
  DragIndicator as DragIndicatorIcon
} from '@mui/icons-material';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import evaluationService from '../../services/evaluationService';
import Loader from '../common/Loader';
import ErrorAlert from '../common/ErrorAlert';
import { DragDropContext, Droppable, Draggable } from 'react-beautiful-dnd';

// Composant TabPanel pour gérer les onglets
function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`evaluation-editor-tabpanel-${index}`}
      aria-labelledby={`evaluation-editor-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          {children}
        </Box>
      )}
    </div>
  );
}

const EvaluationEditor = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const isNewEvaluation = !id;
  
  // États
  const [loading, setLoading] = useState(!isNewEvaluation);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);
  const [tabValue, setTabValue] = useState(0);
  const [evaluation, setEvaluation] = useState({
    titre: '',
    description: '',
    type: '',
    instructions: '',
    dureeEstimee: 30,
    sections: [],
    actif: true
  });
  const [currentSectionIndex, setCurrentSectionIndex] = useState(0);
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success'
  });

  // Charger l'évaluation existante
  useEffect(() => {
    if (!isNewEvaluation) {
      const loadEvaluation = async () => {
        try {
          setLoading(true);
          const data = await evaluationService.getEvaluationById(id);
          setEvaluation(data);
          setLoading(false);
        } catch (err) {
          setError(err.message || 'Une erreur est survenue lors du chargement de l\'évaluation');
          setLoading(false);
        }
      };

      loadEvaluation();
    }
  }, [id, isNewEvaluation]);

  // Gestionnaires d'événements
  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setEvaluation({
      ...evaluation,
      [name]: value
    });
  };

  const handleSwitchChange = (e) => {
    const { name, checked } = e.target;
    setEvaluation({
      ...evaluation,
      [name]: checked
    });
  };

  const handleAddSection = () => {
    const newSections = [...evaluation.sections];
    newSections.push({
      titre: `Section ${newSections.length + 1}`,
      description: '',
      questionsQCM: [],
      questionsEchelle: [],
      questionsOuvertes: []
    });
    
    setEvaluation({
      ...evaluation,
      sections: newSections
    });
    
    setCurrentSectionIndex(newSections.length - 1);
  };

  const handleRemoveSection = (index) => {
    const newSections = [...evaluation.sections];
    newSections.splice(index, 1);
    
    setEvaluation({
      ...evaluation,
      sections: newSections
    });
    
    if (currentSectionIndex >= newSections.length) {
      setCurrentSectionIndex(Math.max(0, newSections.length - 1));
    }
  };

  const handleSectionChange = (index, field, value) => {
    const newSections = [...evaluation.sections];
    newSections[index] = {
      ...newSections[index],
      [field]: value
    };
    
    setEvaluation({
      ...evaluation,
      sections: newSections
    });
  };

  const handleAddQuestion = (sectionIndex, questionType) => {
    const newSections = [...evaluation.sections];
    const section = newSections[sectionIndex];
    
    switch (questionType) {
      case 'qcm':
        section.questionsQCM.push({
          texte: '',
          options: [
            { texte: 'Option 1', valeur: 1 },
            { texte: 'Option 2', valeur: 2 }
          ]
        });
        break;
      case 'echelle':
        section.questionsEchelle.push({
          texte: '',
          min: 1,
          max: 5,
          minLabel: 'Pas du tout d\'accord',
          maxLabel: 'Tout à fait d\'accord'
        });
        break;
      case 'ouverte':
        section.questionsOuvertes.push({
          texte: '',
          indice: ''
        });
        break;
      default:
        break;
    }
    
    setEvaluation({
      ...evaluation,
      sections: newSections
    });
  };

  const handleRemoveQuestion = (sectionIndex, questionType, questionIndex) => {
    const newSections = [...evaluation.sections];
    const section = newSections[sectionIndex];
    
    switch (questionType) {
      case 'qcm':
        section.questionsQCM.splice(questionIndex, 1);
        break;
      case 'echelle':
        section.questionsEchelle.splice(questionIndex, 1);
        break;
      case 'ouverte':
        section.questionsOuvertes.splice(questionIndex, 1);
        break;
      default:
        break;
    }
    
    setEvaluation({
      ...evaluation,
      sections: newSections
    });
  };

  const handleQuestionChange = (sectionIndex, questionType, questionIndex, field, value) => {
    const newSections = [...evaluation.sections];
    const section = newSections[sectionIndex];
    
    switch (questionType) {
      case 'qcm':
        section.questionsQCM[questionIndex] = {
          ...section.questionsQCM[questionIndex],
          [field]: value
        };
        break;
      case 'echelle':
        section.questionsEchelle[questionIndex] = {
          ...section.questionsEchelle[questionIndex],
          [field]: value
        };
        break;
      case 'ouverte':
        section.questionsOuvertes[questionIndex] = {
          ...section.questionsOuvertes[questionIndex],
          [field]: value
        };
        break;
      default:
        break;
    }
    
    setEvaluation({
      ...evaluation,
      sections: newSections
    });
  };

  const handleAddOption = (sectionIndex, questionIndex) => {
    const newSections = [...evaluation.sections];
    const question = newSections[sectionIndex].questionsQCM[questionIndex];
    
    question.options.push({
      texte: `Option ${question.options.length + 1}`,
      valeur: question.options.length + 1
    });
    
    setEvaluation({
      ...evaluation,
      sections: newSections
    });
  };

  const handleRemoveOption = (sectionIndex, questionIndex, optionIndex) => {
    const newSections = [...evaluation.sections];
    const question = newSections[sectionIndex].questionsQCM[questionIndex];
    
    question.options.splice(optionIndex, 1);
    
    setEvaluation({
      ...evaluation,
      sections: newSections
    });
  };

  const handleOptionChange = (sectionIndex, questionIndex, optionIndex, field, value) => {
    const newSections = [...evaluation.sections];
    const option = newSections[sectionIndex].questionsQCM[questionIndex].options[optionIndex];
    
    option[field] = field === 'valeur' ? parseInt(value) : value;
    
    setEvaluation({
      ...evaluation,
      sections: newSections
    });
  };

  const handleDragEnd = (result) => {
    if (!result.destination) return;
    
    const { source, destination, type } = result;
    
    // Si on déplace une section
    if (type === 'section') {
      const newSections = [...evaluation.sections];
      const [removed] = newSections.splice(source.index, 1);
      newSections.splice(destination.index, 0, removed);
      
      setEvaluation({
        ...evaluation,
        sections: newSections
      });
      
      if (currentSectionIndex === source.index) {
        setCurrentSectionIndex(destination.index);
      } else if (
        currentSectionIndex > source.index && 
        currentSectionIndex <= destination.index
      ) {
        setCurrentSectionIndex(currentSectionIndex - 1);
      } else if (
        currentSectionIndex < source.index && 
        currentSectionIndex >= destination.index
      ) {
        setCurrentSectionIndex(currentSectionIndex + 1);
      }
      
      return;
    }
    
    // Si on déplace une question
    const sectionIndex = parseInt(result.type.split('-')[1]);
    const questionType = result.type.split('-')[2];
    
    const newSections = [...evaluation.sections];
    let questions;
    
    switch (questionType) {
      case 'qcm':
        questions = [...newSections[sectionIndex].questionsQCM];
        const [removedQCM] = questions.splice(source.index, 1);
        questions.splice(destination.index, 0, removedQCM);
        newSections[sectionIndex].questionsQCM = questions;
        break;
      case 'echelle':
        questions = [...newSections[sectionIndex].questionsEchelle];
        const [removedEchelle] = questions.splice(source.index, 1);
        questions.splice(destination.index, 0, removedEchelle);
        newSections[sectionIndex].questionsEchelle = questions;
        break;
      case 'ouverte':
        questions = [...newSections[sectionIndex].questionsOuvertes];
        const [removedOuverte] = questions.splice(source.index, 1);
        questions.splice(destination.index, 0, removedOuverte);
        newSections[sectionIndex].questionsOuvertes = questions;
        break;
      default:
        break;
    }
    
    setEvaluation({
      ...evaluation,
      sections: newSections
    });
  };

  const validateEvaluation = () => {
    // Vérifier les champs obligatoires
    if (!evaluation.titre) {
      setError('Le titre de l\'évaluation est obligatoire');
      return false;
    }
    
    if (!evaluation.description) {
      setError('La description de l\'évaluation est obligatoire');
      return false;
    }
    
    if (!evaluation.type) {
      setError('Le type d\'évaluation est obligatoire');
      return false;
    }
    
    if (evaluation.sections.length === 0) {
      setError('L\'évaluation doit contenir au moins une section');
      return false;
    }
    
    // Vérifier chaque section
    for (let i = 0; i < evaluation.sections.length; i++) {
      const section = evaluation.sections[i];
      
      if (!section.titre) {
        setError(`Le titre de la section ${i + 1} est obligatoire`);
        return false;
      }
      
      const totalQuestions = 
        section.questionsQCM.length + 
        section.questionsEchelle.length + 
        section.questionsOuvertes.length;
      
      if (totalQuestions === 0) {
        setError(`La section ${i + 1} doit contenir au moins une question`);
        return false;
      }
      
      // Vérifier les questions QCM
      for (let j = 0; j < section.questionsQCM.length; j++) {
        const question = section.questionsQCM[j];
        
        if (!question.texte) {
          setError(`Le texte de la question QCM ${j + 1} dans la section ${i + 1} est obligatoire`);
          return false;
        }
        
        if (question.options.length < 2) {
          setError(`La question QCM ${j + 1} dans la section ${i + 1} doit avoir au moins 2 options`);
          return false;
        }
        
        for (let k = 0; k < question.options.length; k++) {
          if (!question.options[k].texte) {
            setError(`Le texte de l'option ${k + 1} de la question QCM ${j + 1} dans la section ${i + 1} est obligatoire`);
            return false;
          }
        }
      }
      
      // Vérifier les questions à échelle
      for (let j = 0; j < section.questionsEchelle.length; j++) {
        const question = section.questionsEchelle[j];
        
        if (!question.texte) {
          setError(`Le texte de la question à échelle ${j + 1} dans la section ${i + 1} est obligatoire`);
          return false;
        }
        
        if (question.min >= question.max) {
          setError(`La valeur minimale doit être inférieure à la valeur maximale pour la question à échelle ${j + 1} dans la section ${i + 1}`);
          return false;
        }
      }
      
      // Vérifier les questions ouvertes
      for (let j = 0; j < section.questionsOuvertes.length; j++) {
        const question = section.questionsOuvertes[j];
        
        if (!question.texte) {
          setError(`Le texte de la question ouverte ${j + 1} dans la section ${i + 1} est obligatoire`);
          return false;
        }
      }
    }
    
    return true;
  };

  const handleSave = async () => {
    if (!validateEvaluation()) {
      return;
    }
    
    try {
      setSaving(true);
      setError(null);
      
      let savedEvaluation;
      
      if (isNewEvaluation) {
        savedEvaluation = await evaluationService.createEvaluation({
          ...evaluation,
          creePar: user.id
        });
      } else {
        savedEvaluation = await evaluationService.updateEvaluation(id, {
          ...evaluation,
          modifiePar: user.id
        });
      }
      
      setSaving(false);
      setSnackbar({
        open: true,
        message: `Évaluation ${isNewEvaluation ? 'créée' : 'mise à jour'} avec succès`,
        severity: 'success'
      });
      
      // Rediriger après un court délai
      setTimeout(() => {
        navigate('/evaluations');
      }, 2000);
    } catch (err) {
      setError(err.message || `Une erreur est survenue lors de la ${isNewEvaluation ? 'création' : 'mise à jour'} de l'évaluation`);
      setSaving(false);
    }
  };

  if (loading) return <Loader />;

  return (
    <Container maxWidth="lg">
      <Box sx={{ my: 4 }}>
        <Paper sx={{ p: 3, mb: 3 }}>
          <Typography variant="h4" component="h1" gutterBottom>
            {isNewEvaluation ? 'Créer une nouvelle évaluation' : 'Modifier l\'évaluation'}
          </Typography>
          
          {error && <ErrorAlert message={error} sx={{ mb: 3 }} />}
          
          <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 3 }}>
            <Tabs value={tabValue} onChange={handleTabChange} aria-label="evaluation editor tabs">
              <Tab label="Informations générales" id="evaluation-editor-tab-0" aria-controls="evaluation-editor-tabpanel-0" />
              <Tab label="Contenu" id="evaluation-editor-tab-1" aria-controls="evaluation-editor-tabpanel-1" />
            </Tabs>
          </Box>
          
          <TabPanel value={tabValue} index={0}>
            <Grid container spacing={3}>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Titre de l'évaluation"
                  name="titre"
                  value={evaluation.titre}
                  onChange={handleChange}
                  required
                  error={!evaluation.titre}
                  helperText={!evaluation.titre ? 'Le titre est obligatoire' : ''}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Description"
                  name="description"
                  value={evaluation.description}
                  onChange={handleChange}
                  multiline
                  rows={3}
                  required
                  error={!evaluation.description}
                  helperText={!evaluation.description ? 'La description est obligatoire' : ''}
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <FormControl fullWidth required error={!evaluation.type}>
                  <InputLabel>Type d'évaluation</InputLabel>
                  <Select
                    name="type"
                    value={evaluation.type}
                    onChange={handleChange}
                    label="Type d'évaluation"
                  >
                    <MenuItem value="Auto-évaluation">Auto-évaluation</MenuItem>
                    <MenuItem value="Test personnalité">Test de personnalité</MenuItem>
                    <MenuItem value="Grille compétences">Grille de compétences</MenuItem>
                    <MenuItem value="Projection professionnelle">Projection professionnelle</MenuItem>
                  </Select>
                  {!evaluation.type && (
                    <Typography variant="caption" color="error">
                      Le type d'évaluation est obligatoire
                    </Typography>
                  )}
                </FormControl>
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Durée estimée (minutes)"
                  name="dureeEstimee"
                  type="number"
                  value={evaluation.dureeEstimee}
                  onChange={handleChange}
                  InputProps={{ inputProps: { min: 5 } }}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Instructions pour le bénéficiaire"
                  name="instructions"
                  value={evaluation.instructions}
                  onChange={handleChange}
                  multiline
                  rows={3}
                />
              </Grid>
              <Grid item xs={12}>
                <FormControlLabel
                  control={
                    <Switch
                      checked={evaluation.actif}
                      onChange={handleSwitchChange}
                      name="actif"
                      color="primary"
                    />
                  }
                  label="Évaluation active"
                />
              </Grid>
            </Grid>
          </TabPanel>
          
          <TabPanel value={tabValue} index={1}>
            <Box sx={{ mb: 3 }}>
              <Button
                variant="contained"
                color="primary"
                startIcon={<AddIcon />}
                onClick={handleAddSection}
              >
                Ajouter une section
              </Button>
            </Box>
            
            {evaluation.sections.length === 0 ? (
              <Paper sx={{ p: 3, textAlign: 'center' }}>
                <Typography variant="body1" color="textSecondary">
                  Aucune section n'a été créée. Cliquez sur "Ajouter une section" pour commencer.
                </Typography>
              </Paper>
            ) : (
              <DragDropContext onDragEnd={handleDragEnd}>
                <Grid container spacing={3}>
                  <Grid item xs={12} md={3}>
                    <Paper sx={{ p: 2 }}>
                      <Typography variant="h6" gutterBottom>
                        Sections
                      </Typography>
                      <Droppable droppableId="sections" type="section">
                        {(provided) => (
                          <List
                            ref={provided.innerRef}
                            {...provided.droppableProps}
                          >
                            {evaluation.sections.map((section, index) => (
                              <Draggable
                                key={`section-${index}`}
                                draggableId={`section-${index}`}
                                index={index}
                              >
                                {(provided) => (
                                  <ListItem
                                    ref={provided.innerRef}
                                    {...provided.draggableProps}
                                    button
                                    selected={currentSectionIndex === index}
                                    onClick={() => setCurrentSectionIndex(index)}
                                    sx={{ mb: 1 }}
                                  >
                                    <ListItemIcon {...provided.dragHandleProps}>
                                      <DragIndicatorIcon />
                                    </ListItemIcon>
                                    <ListItemText 
                                      primary={section.titre} 
                                      secondary={`${
                                        section.questionsQCM.length +
                                        section.questionsEchelle.length +
                                        section.questionsOuvertes.length
                                      } question(s)`} 
                                    />
                                    <IconButton
                                      edge="end"
                                      color="error"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        handleRemoveSection(index);
                                      }}
                                    >
                                      <DeleteIcon />
                                    </IconButton>
                                  </ListItem>
                                )}
                              </Draggable>
                            ))}
                            {provided.placeholder}
                          </List>
                        )}
                      </Droppable>
                    </Paper>
                  </Grid>
                  
                  <Grid item xs={12} md={9}>
                    {evaluation.sections.length > 0 && (
                      <Paper sx={{ p: 3 }}>
                        <Typography variant="h5" gutterBottom>
                          Section: {evaluation.sections[currentSectionIndex].titre}
                        </Typography>
                        
                        <Grid container spacing={3} sx={{ mb: 3 }}>
                          <Grid item xs={12}>
                            <TextField
                              fullWidth
                              label="Titre de la section"
                              value={evaluation.sections[currentSectionIndex].titre}
                              onChange={(e) => handleSectionChange(currentSectionIndex, 'titre', e.target.value)}
                              required
                              error={!evaluation.sections[currentSectionIndex].titre}
                              helperText={!evaluation.sections[currentSectionIndex].titre ? 'Le titre est obligatoire' : ''}
                            />
                          </Grid>
                          <Grid item xs={12}>
                            <TextField
                              fullWidth
                              label="Description de la section"
                              value={evaluation.sections[currentSectionIndex].description}
                              onChange={(e) => handleSectionChange(currentSectionIndex, 'description', e.target.value)}
                              multiline
                              rows={2}
                            />
                          </Grid>
                        </Grid>
                        
                        <Divider sx={{ my: 3 }} />
                        
                        <Box sx={{ mb: 3 }}>
                          <Typography variant="h6" gutterBottom>
                            Questions
                          </Typography>
                          <Grid container spacing={2}>
                            <Grid item>
                              <Button
                                variant="outlined"
                                startIcon={<AddIcon />}
                                onClick={() => handleAddQuestion(currentSectionIndex, 'qcm')}
                              >
                                Ajouter QCM
                              </Button>
                            </Grid>
                            <Grid item>
                              <Button
                                variant="outlined"
                                startIcon={<AddIcon />}
                                onClick={() => handleAddQuestion(currentSectionIndex, 'echelle')}
                              >
                                Ajouter Échelle
                              </Button>
                            </Grid>
                            <Grid item>
                              <Button
                                variant="outlined"
                                startIcon={<AddIcon />}
                                onClick={() => handleAddQuestion(currentSectionIndex, 'ouverte')}
                              >
                                Ajouter Question ouverte
                              </Button>
                            </Grid>
                          </Grid>
                        </Box>
                        
                        {/* Questions QCM */}
                        {evaluation.sections[currentSectionIndex].questionsQCM.length > 0 && (
                          <Box sx={{ mb: 4 }}>
                            <Typography variant="subtitle1" gutterBottom>
                              Questions à choix multiples
                            </Typography>
                            <Droppable 
                              droppableId={`questions-qcm-${currentSectionIndex}`} 
                              type={`section-${currentSectionIndex}-qcm`}
                            >
                              {(provided) => (
                                <div
                                  ref={provided.innerRef}
                                  {...provided.droppableProps}
                                >
                                  {evaluation.sections[currentSectionIndex].questionsQCM.map((question, questionIndex) => (
                                    <Draggable
                                      key={`qcm-${questionIndex}`}
                                      draggableId={`qcm-${questionIndex}`}
                                      index={questionIndex}
                                    >
                                      {(provided) => (
                                        <Accordion
                                          ref={provided.innerRef}
                                          {...provided.draggableProps}
                                          sx={{ mb: 2 }}
                                        >
                                          <AccordionSummary
                                            expandIcon={<ExpandMoreIcon />}
                                            aria-controls={`qcm-${questionIndex}-content`}
                                            id={`qcm-${questionIndex}-header`}
                                          >
                                            <Box sx={{ display: 'flex', alignItems: 'center', width: '100%' }}>
                                              <Box {...provided.dragHandleProps} sx={{ mr: 2 }}>
                                                <DragIndicatorIcon />
                                              </Box>
                                              <Typography sx={{ flexGrow: 1 }}>
                                                {question.texte || `Question QCM ${questionIndex + 1}`}
                                              </Typography>
                                              <IconButton
                                                size="small"
                                                color="error"
                                                onClick={(e) => {
                                                  e.stopPropagation();
                                                  handleRemoveQuestion(currentSectionIndex, 'qcm', questionIndex);
                                                }}
                                              >
                                                <DeleteIcon />
                                              </IconButton>
                                            </Box>
                                          </AccordionSummary>
                                          <AccordionDetails>
                                            <Grid container spacing={2}>
                                              <Grid item xs={12}>
                                                <TextField
                                                  fullWidth
                                                  label="Texte de la question"
                                                  value={question.texte}
                                                  onChange={(e) => handleQuestionChange(currentSectionIndex, 'qcm', questionIndex, 'texte', e.target.value)}
                                                  required
                                                  error={!question.texte}
                                                  helperText={!question.texte ? 'Le texte de la question est obligatoire' : ''}
                                                />
                                              </Grid>
                                              <Grid item xs={12}>
                                                <Typography variant="subtitle2" gutterBottom>
                                                  Options
                                                </Typography>
                                                {question.options.map((option, optionIndex) => (
                                                  <Box key={optionIndex} sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                                                    <TextField
                                                      sx={{ flexGrow: 1, mr: 2 }}
                                                      label={`Option ${optionIndex + 1}`}
                                                      value={option.texte}
                                                      onChange={(e) => handleOptionChange(currentSectionIndex, questionIndex, optionIndex, 'texte', e.target.value)}
                                                      required
                                                      error={!option.texte}
                                                      helperText={!option.texte ? 'Le texte de l\'option est obligatoire' : ''}
                                                    />
                                                    <TextField
                                                      sx={{ width: '100px', mr: 2 }}
                                                      label="Valeur"
                                                      type="number"
                                                      value={option.valeur}
                                                      onChange={(e) => handleOptionChange(currentSectionIndex, questionIndex, optionIndex, 'valeur', e.target.value)}
                                                      required
                                                    />
                                                    <IconButton
                                                      color="error"
                                                      onClick={() => handleRemoveOption(currentSectionIndex, questionIndex, optionIndex)}
                                                      disabled={question.options.length <= 2}
                                                    >
                                                      <RemoveCircleIcon />
                                                    </IconButton>
                                                  </Box>
                                                ))}
                                                <Button
                                                  startIcon={<AddCircleIcon />}
                                                  onClick={() => handleAddOption(currentSectionIndex, questionIndex)}
                                                >
                                                  Ajouter une option
                                                </Button>
                                              </Grid>
                                            </Grid>
                                          </AccordionDetails>
                                        </Accordion>
                                      )}
                                    </Draggable>
                                  ))}
                                  {provided.placeholder}
                                </div>
                              )}
                            </Droppable>
                          </Box>
                        )}
                        
                        {/* Questions à échelle */}
                        {evaluation.sections[currentSectionIndex].questionsEchelle.length > 0 && (
                          <Box sx={{ mb: 4 }}>
                            <Typography variant="subtitle1" gutterBottom>
                              Questions à échelle
                            </Typography>
                            <Droppable 
                              droppableId={`questions-echelle-${currentSectionIndex}`} 
                              type={`section-${currentSectionIndex}-echelle`}
                            >
                              {(provided) => (
                                <div
                                  ref={provided.innerRef}
                                  {...provided.droppableProps}
                                >
                                  {evaluation.sections[currentSectionIndex].questionsEchelle.map((question, questionIndex) => (
                                    <Draggable
                                      key={`echelle-${questionIndex}`}
                                      draggableId={`echelle-${questionIndex}`}
                                      index={questionIndex}
                                    >
                                      {(provided) => (
                                        <Accordion
                                          ref={provided.innerRef}
                                          {...provided.draggableProps}
                                          sx={{ mb: 2 }}
                                        >
                                          <AccordionSummary
                                            expandIcon={<ExpandMoreIcon />}
                                            aria-controls={`echelle-${questionIndex}-content`}
                                            id={`echelle-${questionIndex}-header`}
                                          >
                                            <Box sx={{ display: 'flex', alignItems: 'center', width: '100%' }}>
                                              <Box {...provided.dragHandleProps} sx={{ mr: 2 }}>
                                                <DragIndicatorIcon />
                                              </Box>
                                              <Typography sx={{ flexGrow: 1 }}>
                                                {question.texte || `Question à échelle ${questionIndex + 1}`}
                                              </Typography>
                                              <IconButton
                                                size="small"
                                                color="error"
                                                onClick={(e) => {
                                                  e.stopPropagation();
                                                  handleRemoveQuestion(currentSectionIndex, 'echelle', questionIndex);
                                                }}
                                              >
                                                <DeleteIcon />
                                              </IconButton>
                                            </Box>
                                          </AccordionSummary>
                                          <AccordionDetails>
                                            <Grid container spacing={2}>
                                              <Grid item xs={12}>
                                                <TextField
                                                  fullWidth
                                                  label="Texte de la question"
                                                  value={question.texte}
                                                  onChange={(e) => handleQuestionChange(currentSectionIndex, 'echelle', questionIndex, 'texte', e.target.value)}
                                                  required
                                                  error={!question.texte}
                                                  helperText={!question.texte ? 'Le texte de la question est obligatoire' : ''}
                                                />
                                              </Grid>
                                              <Grid item xs={12} md={6}>
                                                <TextField
                                                  fullWidth
                                                  label="Valeur minimale"
                                                  type="number"
                                                  value={question.min}
                                                  onChange={(e) => handleQuestionChange(currentSectionIndex, 'echelle', questionIndex, 'min', parseInt(e.target.value))}
                                                  required
                                                  error={question.min >= question.max}
                                                  helperText={question.min >= question.max ? 'La valeur minimale doit être inférieure à la valeur maximale' : ''}
                                                />
                                              </Grid>
                                              <Grid item xs={12} md={6}>
                                                <TextField
                                                  fullWidth
                                                  label="Valeur maximale"
                                                  type="number"
                                                  value={question.max}
                                                  onChange={(e) => handleQuestionChange(currentSectionIndex, 'echelle', questionIndex, 'max', parseInt(e.target.value))}
                                                  required
                                                  error={question.min >= question.max}
                                                  helperText={question.min >= question.max ? 'La valeur maximale doit être supérieure à la valeur minimale' : ''}
                                                />
                                              </Grid>
                                              <Grid item xs={12} md={6}>
                                                <TextField
                                                  fullWidth
                                                  label="Libellé valeur minimale"
                                                  value={question.minLabel}
                                                  onChange={(e) => handleQuestionChange(currentSectionIndex, 'echelle', questionIndex, 'minLabel', e.target.value)}
                                                />
                                              </Grid>
                                              <Grid item xs={12} md={6}>
                                                <TextField
                                                  fullWidth
                                                  label="Libellé valeur maximale"
                                                  value={question.maxLabel}
                                                  onChange={(e) => handleQuestionChange(currentSectionIndex, 'echelle', questionIndex, 'maxLabel', e.target.value)}
                                                />
                                              </Grid>
                                            </Grid>
                                          </AccordionDetails>
                                        </Accordion>
                                      )}
                                    </Draggable>
                                  ))}
                                  {provided.placeholder}
                                </div>
                              )}
                            </Droppable>
                          </Box>
                        )}
                        
                        {/* Questions ouvertes */}
                        {evaluation.sections[currentSectionIndex].questionsOuvertes.length > 0 && (
                          <Box sx={{ mb: 4 }}>
                            <Typography variant="subtitle1" gutterBottom>
                              Questions ouvertes
                            </Typography>
                            <Droppable 
                              droppableId={`questions-ouverte-${currentSectionIndex}`} 
                              type={`section-${currentSectionIndex}-ouverte`}
                            >
                              {(provided) => (
                                <div
                                  ref={provided.innerRef}
                                  {...provided.droppableProps}
                                >
                                  {evaluation.sections[currentSectionIndex].questionsOuvertes.map((question, questionIndex) => (
                                    <Draggable
                                      key={`ouverte-${questionIndex}`}
                                      draggableId={`ouverte-${questionIndex}`}
                                      index={questionIndex}
                                    >
                                      {(provided) => (
                                        <Accordion
                                          ref={provided.innerRef}
                                          {...provided.draggableProps}
                                          sx={{ mb: 2 }}
                                        >
                                          <AccordionSummary
                                            expandIcon={<ExpandMoreIcon />}
                                            aria-controls={`ouverte-${questionIndex}-content`}
                                            id={`ouverte-${questionIndex}-header`}
                                          >
                                            <Box sx={{ display: 'flex', alignItems: 'center', width: '100%' }}>
                                              <Box {...provided.dragHandleProps} sx={{ mr: 2 }}>
                                                <DragIndicatorIcon />
                                              </Box>
                                              <Typography sx={{ flexGrow: 1 }}>
                                                {question.texte || `Question ouverte ${questionIndex + 1}`}
                                              </Typography>
                                              <IconButton
                                                size="small"
                                                color="error"
                                                onClick={(e) => {
                                                  e.stopPropagation();
                                                  handleRemoveQuestion(currentSectionIndex, 'ouverte', questionIndex);
                                                }}
                                              >
                                                <DeleteIcon />
                                              </IconButton>
                                            </Box>
                                          </AccordionSummary>
                                          <AccordionDetails>
                                            <Grid container spacing={2}>
                                              <Grid item xs={12}>
                                                <TextField
                                                  fullWidth
                                                  label="Texte de la question"
                                                  value={question.texte}
                                                  onChange={(e) => handleQuestionChange(currentSectionIndex, 'ouverte', questionIndex, 'texte', e.target.value)}
                                                  required
                                                  error={!question.texte}
                                                  helperText={!question.texte ? 'Le texte de la question est obligatoire' : ''}
                                                />
                                              </Grid>
                                              <Grid item xs={12}>
                                                <TextField
                                                  fullWidth
                                                  label="Indice ou aide pour le bénéficiaire"
                                                  value={question.indice}
                                                  onChange={(e) => handleQuestionChange(currentSectionIndex, 'ouverte', questionIndex, 'indice', e.target.value)}
                                                  multiline
                                                  rows={2}
                                                />
                                              </Grid>
                                            </Grid>
                                          </AccordionDetails>
                                        </Accordion>
                                      )}
                                    </Draggable>
                                  ))}
                                  {provided.placeholder}
                                </div>
                              )}
                            </Droppable>
                          </Box>
                        )}
                      </Paper>
                    )}
                  </Grid>
                </Grid>
              </DragDropContext>
            )}
          </TabPanel>
          
          <Box sx={{ mt: 3, display: 'flex', justifyContent: 'flex-end' }}>
            <Button
              variant="outlined"
              onClick={() => navigate('/evaluations')}
              sx={{ mr: 2 }}
            >
              Annuler
            </Button>
            <Button
              variant="contained"
              color="primary"
              startIcon={<SaveIcon />}
              onClick={handleSave}
              disabled={saving}
            >
              {saving ? 'Enregistrement...' : 'Enregistrer'}
            </Button>
          </Box>
        </Paper>
      </Box>
      
      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
      >
        <Alert 
          onClose={() => setSnackbar({ ...snackbar, open: false })} 
          severity={snackbar.severity}
          sx={{ width: '100%' }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Container>
  );
};

export default EvaluationEditor;
