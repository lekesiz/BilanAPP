import React, { useState, useEffect } from 'react';
import { 
  Container, 
  Typography, 
  Box, 
  Grid, 
  Paper, 
  Button, 
  TextField, 
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Divider,
  Card,
  CardContent,
  CardHeader,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Alert,
  Snackbar,
  IconButton,
  Tooltip,
  Tabs,
  Tab,
  Stepper,
  Step,
  StepLabel,
  StepContent,
  Radio,
  RadioGroup,
  FormControlLabel,
  FormLabel,
  Slider,
  Rating,
  CircularProgress
} from '@mui/material';
import { 
  Assignment as AssignmentIcon,
  Check as CheckIcon,
  Create as CreateIcon,
  Help as HelpIcon,
  NavigateNext as NavigateNextIcon,
  NavigateBefore as NavigateBeforeIcon,
  Save as SaveIcon,
  Send as SendIcon,
  Timer as TimerIcon
} from '@mui/icons-material';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import evaluationService from '../../services/evaluationService';
import Loader from '../common/Loader';
import ErrorAlert from '../common/ErrorAlert';

// Composant TabPanel pour gérer les onglets
function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`evaluation-tabpanel-${index}`}
      aria-labelledby={`evaluation-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          {children}
        </Box>
      )}
    </div>
  );
}

const EvaluationForm = () => {
  const { beneficiaireId, evaluationId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  
  // États
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);
  const [evaluation, setEvaluation] = useState(null);
  const [activeSection, setActiveSection] = useState(0);
  const [responses, setResponses] = useState({});
  const [progress, setProgress] = useState(0);
  const [timeElapsed, setTimeElapsed] = useState(0);
  const [timer, setTimer] = useState(null);
  const [showConfirmSubmit, setShowConfirmSubmit] = useState(false);
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success'
  });

  // Charger l'évaluation
  useEffect(() => {
    const loadEvaluation = async () => {
      try {
        setLoading(true);
        const data = await evaluationService.getEvaluationById(evaluationId);
        setEvaluation(data);
        
        // Initialiser les réponses
        const initialResponses = {};
        data.sections.forEach((section, sectionIndex) => {
          section.questionsQCM.forEach((question, questionIndex) => {
            initialResponses[`qcm_${sectionIndex}_${questionIndex}`] = null;
          });
          section.questionsEchelle.forEach((question, questionIndex) => {
            initialResponses[`echelle_${sectionIndex}_${questionIndex}`] = null;
          });
          section.questionsOuvertes.forEach((question, questionIndex) => {
            initialResponses[`ouverte_${sectionIndex}_${questionIndex}`] = '';
          });
        });
        
        setResponses(initialResponses);
        setLoading(false);
        
        // Démarrer le timer
        const interval = setInterval(() => {
          setTimeElapsed(prev => prev + 1);
        }, 1000);
        
        setTimer(interval);
        
        return () => clearInterval(interval);
      } catch (err) {
        setError(err.message || 'Une erreur est survenue lors du chargement de l\'évaluation');
        setLoading(false);
      }
    };

    loadEvaluation();
  }, [evaluationId]);

  // Mettre à jour la progression
  useEffect(() => {
    if (evaluation) {
      const totalQuestions = Object.keys(responses).length;
      const answeredQuestions = Object.values(responses).filter(response => 
        response !== null && response !== ''
      ).length;
      
      const calculatedProgress = Math.round((answeredQuestions / totalQuestions) * 100);
      setProgress(calculatedProgress);
    }
  }, [responses, evaluation]);

  // Gestionnaires d'événements
  const handleSectionChange = (newSection) => {
    setActiveSection(newSection);
  };

  const handleNext = () => {
    if (activeSection < evaluation.sections.length - 1) {
      setActiveSection(activeSection + 1);
      window.scrollTo(0, 0);
    }
  };

  const handlePrevious = () => {
    if (activeSection > 0) {
      setActiveSection(activeSection - 1);
      window.scrollTo(0, 0);
    }
  };

  const handleResponseChange = (key, value) => {
    setResponses({
      ...responses,
      [key]: value
    });
  };

  const handleOpenConfirmSubmit = () => {
    setShowConfirmSubmit(true);
  };

  const handleCloseConfirmSubmit = () => {
    setShowConfirmSubmit(false);
  };

  const handleSubmit = async () => {
    try {
      setSubmitting(true);
      
      // Arrêter le timer
      if (timer) {
        clearInterval(timer);
      }
      
      // Préparer les données à soumettre
      const submissionData = {
        evaluationId,
        beneficiaireId,
        responses,
        timeElapsed,
        dateCompletion: new Date().toISOString()
      };
      
      // Soumettre les réponses
      await evaluationService.submitEvaluationResponses(
        beneficiaireId,
        evaluationId,
        submissionData
      );
      
      setShowConfirmSubmit(false);
      setSnackbar({
        open: true,
        message: 'Évaluation soumise avec succès',
        severity: 'success'
      });
      
      // Rediriger après un court délai
      setTimeout(() => {
        navigate(`/beneficiaires/${beneficiaireId}`);
      }, 2000);
    } catch (err) {
      setError(err.message || 'Une erreur est survenue lors de la soumission de l\'évaluation');
      setSubmitting(false);
      setShowConfirmSubmit(false);
    }
  };

  // Formater le temps écoulé
  const formatTime = (seconds) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds < 10 ? '0' : ''}${remainingSeconds}`;
  };

  // Rendu des questions QCM
  const renderQCMQuestion = (question, sectionIndex, questionIndex) => {
    const responseKey = `qcm_${sectionIndex}_${questionIndex}`;
    
    return (
      <Box sx={{ mb: 4 }}>
        <Typography variant="subtitle1" gutterBottom>
          {questionIndex + 1}. {question.texte}
        </Typography>
        <FormControl component="fieldset" fullWidth>
          <RadioGroup
            value={responses[responseKey] || ''}
            onChange={(e) => handleResponseChange(responseKey, parseInt(e.target.value))}
          >
            {question.options.map((option, optionIndex) => (
              <FormControlLabel
                key={optionIndex}
                value={option.valeur.toString()}
                control={<Radio />}
                label={option.texte}
              />
            ))}
          </RadioGroup>
        </FormControl>
      </Box>
    );
  };

  // Rendu des questions à échelle
  const renderEchelleQuestion = (question, sectionIndex, questionIndex) => {
    const responseKey = `echelle_${sectionIndex}_${questionIndex}`;
    
    return (
      <Box sx={{ mb: 4 }}>
        <Typography variant="subtitle1" gutterBottom>
          {questionIndex + 1}. {question.texte}
        </Typography>
        <Box sx={{ px: 2, py: 1 }}>
          <Grid container spacing={2} alignItems="center">
            <Grid item xs={12} sm={8}>
              <Slider
                value={responses[responseKey] || question.min}
                onChange={(e, newValue) => handleResponseChange(responseKey, newValue)}
                min={question.min}
                max={question.max}
                step={1}
                marks
                valueLabelDisplay="auto"
              />
            </Grid>
            <Grid item xs={6} sm={2} sx={{ textAlign: 'center' }}>
              <Typography variant="caption" color="textSecondary">
                {question.minLabel}
              </Typography>
            </Grid>
            <Grid item xs={6} sm={2} sx={{ textAlign: 'center' }}>
              <Typography variant="caption" color="textSecondary">
                {question.maxLabel}
              </Typography>
            </Grid>
          </Grid>
        </Box>
      </Box>
    );
  };

  // Rendu des questions ouvertes
  const renderQuestionOuverte = (question, sectionIndex, questionIndex) => {
    const responseKey = `ouverte_${sectionIndex}_${questionIndex}`;
    
    return (
      <Box sx={{ mb: 4 }}>
        <Typography variant="subtitle1" gutterBottom>
          {questionIndex + 1}. {question.texte}
        </Typography>
        {question.indice && (
          <Typography variant="caption" color="textSecondary" paragraph>
            Indice: {question.indice}
          </Typography>
        )}
        <TextField
          fullWidth
          multiline
          rows={4}
          value={responses[responseKey] || ''}
          onChange={(e) => handleResponseChange(responseKey, e.target.value)}
          placeholder="Votre réponse..."
        />
      </Box>
    );
  };

  if (loading) return <Loader />;
  if (error) return <ErrorAlert message={error} />;
  if (!evaluation) return <Typography>Évaluation non trouvée</Typography>;

  const currentSection = evaluation.sections[activeSection];

  return (
    <Container maxWidth="lg">
      <Box sx={{ my: 4 }}>
        <Paper sx={{ p: 3, mb: 3 }}>
          <Grid container spacing={2} alignItems="center">
            <Grid item xs={12} md={8}>
              <Typography variant="h4" component="h1" gutterBottom>
                {evaluation.titre}
              </Typography>
              <Typography variant="subtitle1" color="textSecondary" paragraph>
                {evaluation.description}
              </Typography>
            </Grid>
            <Grid item xs={12} md={4}>
              <Box sx={{ textAlign: 'right' }}>
                <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end' }}>
                  <TimerIcon color="action" sx={{ mr: 1 }} />
                  <Typography variant="body2" color="textSecondary">
                    Temps écoulé: {formatTime(timeElapsed)}
                  </Typography>
                </Box>
                <Box sx={{ mt: 1, display: 'flex', alignItems: 'center', justifyContent: 'flex-end' }}>
                  <Typography variant="body2" color="textSecondary" sx={{ mr: 1 }}>
                    Progression: {progress}%
                  </Typography>
                  <Box sx={{ position: 'relative', display: 'inline-flex' }}>
                    <CircularProgress
                      variant="determinate"
                      value={progress}
                      size={24}
                      thickness={5}
                      color={progress === 100 ? 'success' : 'primary'}
                    />
                  </Box>
                </Box>
              </Box>
            </Grid>
          </Grid>
        </Paper>

        <Grid container spacing={3}>
          <Grid item xs={12} md={3}>
            <Paper sx={{ p: 2, mb: { xs: 2, md: 0 } }}>
              <Typography variant="h6" gutterBottom>
                Sections
              </Typography>
              <List>
                {evaluation.sections.map((section, index) => (
                  <ListItem
                    key={index}
                    button
                    selected={activeSection === index}
                    onClick={() => handleSectionChange(index)}
                  >
                    <ListItemIcon>
                      {index < activeSection ? (
                        <CheckIcon color="success" />
                      ) : (
                        <AssignmentIcon color={activeSection === index ? 'primary' : 'action'} />
                      )}
                    </ListItemIcon>
                    <ListItemText primary={section.titre} />
                  </ListItem>
                ))}
              </List>
              
              <Box sx={{ mt: 4 }}>
                <Button
                  variant="contained"
                  color="primary"
                  fullWidth
                  onClick={handleOpenConfirmSubmit}
                  disabled={progress < 100}
                  startIcon={<SendIcon />}
                >
                  Soumettre l'évaluation
                </Button>
                {progress < 100 && (
                  <Typography variant="caption" color="error" sx={{ display: 'block', mt: 1, textAlign: 'center' }}>
                    Veuillez répondre à toutes les questions avant de soumettre
                  </Typography>
                )}
              </Box>
            </Paper>
          </Grid>
          
          <Grid item xs={12} md={9}>
            <Paper sx={{ p: 3 }}>
              <Typography variant="h5" gutterBottom>
                {currentSection.titre}
              </Typography>
              {currentSection.description && (
                <Typography variant="body1" paragraph>
                  {currentSection.description}
                </Typography>
              )}
              
              <Divider sx={{ my: 2 }} />
              
              <Box sx={{ mt: 4 }}>
                {/* Questions QCM */}
                {currentSection.questionsQCM.length > 0 && (
                  <Box sx={{ mb: 4 }}>
                    <Typography variant="h6" gutterBottom>
                      Questions à choix multiples
                    </Typography>
                    {currentSection.questionsQCM.map((question, questionIndex) => 
                      renderQCMQuestion(question, activeSection, questionIndex)
                    )}
                  </Box>
                )}
                
                {/* Questions à échelle */}
                {currentSection.questionsEchelle.length > 0 && (
                  <Box sx={{ mb: 4 }}>
                    <Typography variant="h6" gutterBottom>
                      Questions à échelle
                    </Typography>
                    {currentSection.questionsEchelle.map((question, questionIndex) => 
                      renderEchelleQuestion(question, activeSection, questionIndex)
                    )}
                  </Box>
                )}
                
                {/* Questions ouvertes */}
                {currentSection.questionsOuvertes.length > 0 && (
                  <Box sx={{ mb: 4 }}>
                    <Typography variant="h6" gutterBottom>
                      Questions ouvertes
                    </Typography>
                    {currentSection.questionsOuvertes.map((question, questionIndex) => 
                      renderQuestionOuverte(question, activeSection, questionIndex)
                    )}
                  </Box>
                )}
              </Box>
              
              <Divider sx={{ my: 2 }} />
              
              <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 3 }}>
                <Button
                  variant="outlined"
                  onClick={handlePrevious}
                  disabled={activeSection === 0}
                  startIcon={<NavigateBeforeIcon />}
                >
                  Section précédente
                </Button>
                <Button
                  variant="contained"
                  onClick={handleNext}
                  disabled={activeSection === evaluation.sections.length - 1}
                  endIcon={<NavigateNextIcon />}
                >
                  Section suivante
                </Button>
              </Box>
            </Paper>
          </Grid>
        </Grid>
      </Box>
      
      {/* Dialogue de confirmation de soumission */}
      <Dialog open={showConfirmSubmit} onClose={handleCloseConfirmSubmit}>
        <DialogTitle>Confirmer la soumission</DialogTitle>
        <DialogContent>
          <Typography variant="body1" paragraph>
            Êtes-vous sûr de vouloir soumettre cette évaluation ? Une fois soumise, vous ne pourrez plus modifier vos réponses.
          </Typography>
          <Typography variant="body2" color="textSecondary">
            Progression: {progress}% | Temps écoulé: {formatTime(timeElapsed)}
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseConfirmSubmit}>Annuler</Button>
          <Button 
            onClick={handleSubmit} 
            variant="contained" 
            color="primary"
            disabled={submitting}
          >
            {submitting ? 'Soumission en cours...' : 'Confirmer la soumission'}
          </Button>
        </DialogActions>
      </Dialog>
      
      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
      >
        <Alert 
          onClose={() => setSnackbar({ ...snackbar, open: false })} 
          severity={snackbar.severity}
          sx={{ width: '100%' }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Container>
  );
};

export default EvaluationForm;
