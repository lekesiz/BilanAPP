import React, { useState, useEffect } from 'react';
import { 
  Container, 
  Typography, 
  Box, 
  Grid, 
  Paper, 
  Button, 
  TextField, 
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Divider,
  Card,
  CardContent,
  CardHeader,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Alert,
  Snackbar,
  IconButton,
  Tooltip,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TablePagination,
  Tabs,
  Tab
} from '@mui/material';
import { 
  Assignment as AssignmentIcon,
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Visibility as VisibilityIcon,
  Send as SendIcon,
  Assessment as AssessmentIcon,
  FilterList as FilterListIcon
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import evaluationService from '../../services/evaluationService';
import Loader from '../common/Loader';
import ErrorAlert from '../common/ErrorAlert';
import ConfirmDialog from '../common/ConfirmDialog';

// Composant TabPanel pour gérer les onglets
function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`evaluations-tabpanel-${index}`}
      aria-labelledby={`evaluations-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          {children}
        </Box>
      )}
    </div>
  );
}

const EvaluationsList = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  
  // États
  const [evaluations, setEvaluations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [totalCount, setTotalCount] = useState(0);
  const [searchQuery, setSearchQuery] = useState('');
  const [filters, setFilters] = useState({
    type: '',
    actif: true
  });
  const [showFilters, setShowFilters] = useState(false);
  const [tabValue, setTabValue] = useState(0);
  const [confirmDialog, setConfirmDialog] = useState({
    open: false,
    title: '',
    message: '',
    onConfirm: null
  });
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success'
  });

  // Charger les évaluations
  const loadEvaluations = async () => {
    try {
      setLoading(true);
      setError(null);
      
      // Construire les paramètres de requête
      const params = {
        page: page + 1,
        limit: rowsPerPage,
        ...filters
      };
      
      if (searchQuery) {
        params.q = searchQuery;
      }
      
      const response = await evaluationService.getAllEvaluations(params);
      setEvaluations(response.data);
      setTotalCount(response.total);
      setLoading(false);
    } catch (err) {
      setError(err.message || 'Une erreur est survenue lors du chargement des évaluations');
      setLoading(false);
    }
  };

  // Effet pour charger les évaluations
  useEffect(() => {
    loadEvaluations();
  }, [page, rowsPerPage, filters, tabValue]);

  // Gestionnaires d'événements
  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
    setFilters({
      ...filters,
      actif: newValue === 0
    });
    setPage(0);
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleSearch = (e) => {
    e.preventDefault();
    setPage(0);
    loadEvaluations();
  };

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters({
      ...filters,
      [name]: value
    });
    setPage(0);
  };

  const handleAddEvaluation = () => {
    navigate('/evaluations/nouvelle');
  };

  const handleViewEvaluation = (id) => {
    navigate(`/evaluations/${id}`);
  };

  const handleEditEvaluation = (id) => {
    navigate(`/evaluations/${id}/modifier`);
  };

  const handleDeleteEvaluation = (id, titre) => {
    setConfirmDialog({
      open: true,
      title: 'Supprimer l\'évaluation',
      message: `Êtes-vous sûr de vouloir supprimer l'évaluation "${titre}" ? Cette action est irréversible.`,
      onConfirm: async () => {
        try {
          await evaluationService.deleteEvaluation(id);
          loadEvaluations();
          setConfirmDialog({ ...confirmDialog, open: false });
          setSnackbar({
            open: true,
            message: 'Évaluation supprimée avec succès',
            severity: 'success'
          });
        } catch (err) {
          setError(err.message || 'Une erreur est survenue lors de la suppression');
          setConfirmDialog({ ...confirmDialog, open: false });
        }
      }
    });
  };

  const handleToggleEvaluationStatus = async (id, actif, titre) => {
    try {
      await evaluationService.updateEvaluation(id, { actif: !actif });
      loadEvaluations();
      setSnackbar({
        open: true,
        message: `Évaluation "${titre}" ${actif ? 'désactivée' : 'activée'} avec succès`,
        severity: 'success'
      });
    } catch (err) {
      setError(err.message || 'Une erreur est survenue lors de la mise à jour du statut');
    }
  };

  return (
    <Container maxWidth="lg">
      <Box sx={{ my: 4 }}>
        <Grid container spacing={2} alignItems="center" sx={{ mb: 3 }}>
          <Grid item xs={12} md={6}>
            <Typography variant="h4" component="h1" gutterBottom>
              Évaluations
            </Typography>
          </Grid>
          <Grid item xs={12} md={6} sx={{ textAlign: 'right' }}>
            {(user.role === 'admin' || user.role === 'consultant') && (
              <Button
                variant="contained"
                color="primary"
                startIcon={<AddIcon />}
                onClick={handleAddEvaluation}
              >
                Créer une évaluation
              </Button>
            )}
          </Grid>
        </Grid>

        <Paper sx={{ width: '100%', mb: 4 }}>
          <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
            <Tabs value={tabValue} onChange={handleTabChange} aria-label="evaluations tabs">
              <Tab label="Évaluations actives" id="evaluations-tab-0" aria-controls="evaluations-tabpanel-0" />
              <Tab label="Évaluations inactives" id="evaluations-tab-1" aria-controls="evaluations-tabpanel-1" />
            </Tabs>
          </Box>

          <Box sx={{ p: 2 }}>
            <Grid container spacing={2} alignItems="center">
              <Grid item xs={12} md={6}>
                <form onSubmit={handleSearch}>
                  <TextField
                    fullWidth
                    placeholder="Rechercher une évaluation..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    InputProps={{
                      endAdornment: (
                        <IconButton type="submit">
                          <FilterListIcon />
                        </IconButton>
                      )
                    }}
                  />
                </form>
              </Grid>
              <Grid item xs={12} md={6} sx={{ textAlign: 'right' }}>
                <Button
                  startIcon={<FilterListIcon />}
                  onClick={() => setShowFilters(!showFilters)}
                >
                  Filtres
                </Button>
              </Grid>
              {showFilters && (
                <Grid item xs={12}>
                  <Box sx={{ p: 2, border: '1px solid #e0e0e0', borderRadius: 1 }}>
                    <Grid container spacing={2}>
                      <Grid item xs={12} md={6}>
                        <FormControl fullWidth>
                          <InputLabel>Type d'évaluation</InputLabel>
                          <Select
                            name="type"
                            value={filters.type}
                            onChange={handleFilterChange}
                            label="Type d'évaluation"
                          >
                            <MenuItem value="">Tous</MenuItem>
                            <MenuItem value="Auto-évaluation">Auto-évaluation</MenuItem>
                            <MenuItem value="Test personnalité">Test de personnalité</MenuItem>
                            <MenuItem value="Grille compétences">Grille de compétences</MenuItem>
                            <MenuItem value="Projection professionnelle">Projection professionnelle</MenuItem>
                          </Select>
                        </FormControl>
                      </Grid>
                      <Grid item xs={12} md={6} sx={{ display: 'flex', justifyContent: 'flex-end', alignItems: 'center' }}>
                        <Button
                          variant="outlined"
                          onClick={() => {
                            setFilters({
                              type: '',
                              actif: tabValue === 0
                            });
                          }}
                        >
                          Réinitialiser les filtres
                        </Button>
                      </Grid>
                    </Grid>
                  </Box>
                </Grid>
              )}
            </Grid>
          </Box>

          {error && <ErrorAlert message={error} sx={{ mx: 2 }} />}

          <TabPanel value={tabValue} index={0}>
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>Titre</TableCell>
                    <TableCell>Type</TableCell>
                    <TableCell>Description</TableCell>
                    <TableCell>Nombre de questions</TableCell>
                    <TableCell>Durée estimée</TableCell>
                    <TableCell align="right">Actions</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {loading ? (
                    <TableRow>
                      <TableCell colSpan={6} align="center">
                        <Loader size={40} />
                      </TableCell>
                    </TableRow>
                  ) : evaluations.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={6} align="center">
                        Aucune évaluation active trouvée
                      </TableCell>
                    </TableRow>
                  ) : (
                    evaluations.map((evaluation) => (
                      <TableRow key={evaluation.id}>
                        <TableCell>{evaluation.titre}</TableCell>
                        <TableCell>
                          <Chip 
                            label={evaluation.type} 
                            color={
                              evaluation.type === 'Auto-évaluation' ? 'primary' :
                              evaluation.type === 'Test personnalité' ? 'secondary' :
                              evaluation.type === 'Grille compétences' ? 'success' :
                              'warning'
                            } 
                            size="small" 
                          />
                        </TableCell>
                        <TableCell>
                          {evaluation.description.length > 50
                            ? `${evaluation.description.substring(0, 50)}...`
                            : evaluation.description}
                        </TableCell>
                        <TableCell>{evaluation.nombreTotalQuestions}</TableCell>
                        <TableCell>{evaluation.dureeEstimee} min</TableCell>
                        <TableCell align="right">
                          <Tooltip title="Voir les détails">
                            <IconButton
                              color="primary"
                              onClick={() => handleViewEvaluation(evaluation.id)}
                            >
                              <VisibilityIcon />
                            </IconButton>
                          </Tooltip>
                          {(user.role === 'admin' || 
                            (user.role === 'consultant' && 
                             evaluation.creePar === user.id)) && (
                            <>
                              <Tooltip title="Modifier">
                                <IconButton
                                  color="secondary"
                                  onClick={() => handleEditEvaluation(evaluation.id)}
                                >
                                  <EditIcon />
                                </IconButton>
                              </Tooltip>
                              <Tooltip title="Désactiver">
                                <IconButton
                                  color="default"
                                  onClick={() => handleToggleEvaluationStatus(evaluation.id, true, evaluation.titre)}
                                >
                                  <AssignmentIcon />
                                </IconButton>
                              </Tooltip>
                              {user.role === 'admin' && (
                                <Tooltip title="Supprimer">
                                  <IconButton
                                    color="error"
                                    onClick={() => handleDeleteEvaluation(evaluation.id, evaluation.titre)}
                                  >
                                    <DeleteIcon />
                                  </IconButton>
                                </Tooltip>
                              )}
                            </>
                          )}
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </TableContainer>
          </TabPanel>

          <TabPanel value={tabValue} index={1}>
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>Titre</TableCell>
                    <TableCell>Type</TableCell>
                    <TableCell>Description</TableCell>
                    <TableCell>Nombre de questions</TableCell>
                    <TableCell>Durée estimée</TableCell>
                    <TableCell align="right">Actions</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {loading ? (
                    <TableRow>
                      <TableCell colSpan={6} align="center">
                        <Loader size={40} />
                      </TableCell>
                    </TableRow>
                  ) : evaluations.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={6} align="center">
                        Aucune évaluation inactive trouvée
                      </TableCell>
                    </TableRow>
                  ) : (
                    evaluations.map((evaluation) => (
                      <TableRow key={evaluation.id}>
                        <TableCell>{evaluation.titre}</TableCell>
                        <TableCell>
                          <Chip 
                            label={evaluation.type} 
                            color={
                              evaluation.type === 'Auto-évaluation' ? 'primary' :
                              evaluation.type === 'Test personnalité' ? 'secondary' :
                              evaluation.type === 'Grille compétences' ? 'success' :
                              'warning'
                            } 
                            size="small" 
                          />
                        </TableCell>
                        <TableCell>
                          {evaluation.description.length > 50
                            ? `${evaluation.description.substring(0, 50)}...`
                            : evaluation.description}
                        </TableCell>
                        <TableCell>{evaluation.nombreTotalQuestions}</TableCell>
                        <TableCell>{evaluation.dureeEstimee} min</TableCell>
                        <TableCell align="right">
                          <Tooltip title="Voir les détails">
                            <IconButton
                              color="primary"
                              onClick={() => handleViewEvaluation(evaluation.id)}
                            >
                              <VisibilityIcon />
                            </IconButton>
                          </Tooltip>
                          {(user.role === 'admin' || 
                            (user.role === 'consultant' && 
                             evaluation.creePar === user.id)) && (
                            <>
                              <Tooltip title="Modifier">
                                <IconButton
                                  color="secondary"
                                  onClick={() => handleEditEvaluation(evaluation.id)}
                                >
                                  <EditIcon />
                                </IconButton>
                              </Tooltip>
                              <Tooltip title="Activer">
                                <IconButton
                                  color="success"
                                  onClick={() => handleToggleEvaluationStatus(evaluation.id, false, evaluation.titre)}
                                >
                                  <AssignmentIcon />
                                </IconButton>
                              </Tooltip>
                              {user.role === 'admin' && (
                                <Tooltip title="Supprimer">
                                  <IconButton
                                    color="error"
                                    onClick={() => handleDeleteEvaluation(evaluation.id, evaluation.titre)}
                                  >
                                    <DeleteIcon />
                                  </IconButton>
                                </Tooltip>
                              )}
                            </>
                          )}
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </TableContainer>
          </TabPanel>

          <TablePagination
            component="div"
            count={totalCount}
            page={page}
            onPageChange={handleChangePage}
            rowsPerPage={rowsPerPage}
            onRowsPerPageChange={handleChangeRowsPerPage}
            rowsPerPageOptions={[5, 10, 25, 50]}
            labelRowsPerPage="Lignes par page :"
            labelDisplayedRows={({ from, to, count }) => 
              `${from}-${to} sur ${count !== -1 ? count : `plus de ${to}`}`
            }
          />
        </Paper>
      </Box>

      <ConfirmDialog
        open={confirmDialog.open}
        title={confirmDialog.title}
        message={confirmDialog.message}
        onConfirm={confirmDialog.onConfirm}
        onCancel={() => setConfirmDialog({ ...confirmDialog, open: false })}
      />

      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
      >
        <Alert 
          onClose={() => setSnackbar({ ...snackbar, open: false })} 
          severity={snackbar.severity}
          sx={{ width: '100%' }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Container>
  );
};

export default EvaluationsList;
