import React, { useState, useEffect } from 'react';
import {
  Container,
  Typography,
  Box,
  Grid,
  Paper,
  Button,
  TextField,
  FormControl,
  FormControlLabel,
  FormGroup,
  Checkbox,
  Divider,
  Card,
  CardContent,
  CardHeader,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Alert,
  Snackbar,
  IconButton,
  Tooltip,
  CircularProgress,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  LinearProgress
} from '@mui/material';
import {
  Security as SecurityIcon,
  Lock as LockIcon,
  LockOpen as LockOpenIcon,
  Visibility as VisibilityIcon,
  VisibilityOff as VisibilityOffIcon,
  Delete as DeleteIcon,
  GetApp as DownloadIcon,
  ExpandMore as ExpandMoreIcon,
  Check as CheckIcon,
  Error as ErrorIcon,
  Warning as WarningIcon,
  Info as InfoIcon
} from '@mui/icons-material';
import { useAuth } from '../../contexts/AuthContext';
import securityService from '../../services/security/securityService';
import Loader from '../common/Loader';
import ErrorAlert from '../common/ErrorAlert';

const SecuritySettings = () => {
  const { user } = useAuth();
  
  // États
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [userConsent, setUserConsent] = useState(null);
  const [consentForm, setConsentForm] = useState({
    dataProcessing: false,
    dataSharing: false,
    marketing: false,
    cookies: false
  });
  const [passwordForm, setPasswordForm] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });
  const [showPassword, setShowPassword] = useState(false);
  const [passwordStrength, setPasswordStrength] = useState(null);
  const [exportLoading, setExportLoading] = useState(false);
  const [deleteConfirmDialog, setDeleteConfirmDialog] = useState(false);
  const [deleteConfirmText, setDeleteConfirmText] = useState('');
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success'
  });

  // Charger les données de consentement de l'utilisateur
  useEffect(() => {
    const loadUserConsent = async () => {
      try {
        setLoading(true);
        setError(null);
        
        if (user && user.id) {
          const consentData = await securityService.checkUserConsent(user.id);
          setUserConsent(consentData);
          
          if (consentData && consentData.consentData) {
            setConsentForm(consentData.consentData);
          }
        }
        
        setLoading(false);
      } catch (err) {
        setError(err.message || 'Une erreur est survenue lors du chargement des données de consentement');
        setLoading(false);
      }
    };

    loadUserConsent();
  }, [user]);

  // Vérifier la force du mot de passe
  useEffect(() => {
    if (passwordForm.newPassword) {
      const strength = securityService.checkPasswordStrength(passwordForm.newPassword);
      setPasswordStrength(strength);
    } else {
      setPasswordStrength(null);
    }
  }, [passwordForm.newPassword]);

  // Gestionnaires d'événements
  const handleConsentChange = (e) => {
    const { name, checked } = e.target;
    setConsentForm({
      ...consentForm,
      [name]: checked
    });
  };

  const handleSaveConsent = async () => {
    try {
      setLoading(true);
      setError(null);
      
      if (user && user.id) {
        await securityService.manageUserConsent(user.id, consentForm);
        
        setSnackbar({
          open: true,
          message: 'Préférences de confidentialité enregistrées avec succès',
          severity: 'success'
        });
      }
      
      setLoading(false);
    } catch (err) {
      setError(err.message || 'Une erreur est survenue lors de l\'enregistrement des préférences');
      setLoading(false);
    }
  };

  const handlePasswordChange = (e) => {
    const { name, value } = e.target;
    setPasswordForm({
      ...passwordForm,
      [name]: value
    });
  };

  const handleChangePassword = async () => {
    try {
      setLoading(true);
      setError(null);
      
      // Vérifier que les mots de passe correspondent
      if (passwordForm.newPassword !== passwordForm.confirmPassword) {
        throw new Error('Les mots de passe ne correspondent pas');
      }
      
      // Vérifier la force du mot de passe
      const strength = securityService.checkPasswordStrength(passwordForm.newPassword);
      if (!strength.isStrong) {
        throw new Error('Le mot de passe n\'est pas assez fort: ' + strength.suggestions.join(', '));
      }
      
      // Appel API pour changer le mot de passe (à implémenter)
      // await authService.changePassword(passwordForm.currentPassword, passwordForm.newPassword);
      
      // Réinitialiser le formulaire
      setPasswordForm({
        currentPassword: '',
        newPassword: '',
        confirmPassword: ''
      });
      
      setSnackbar({
        open: true,
        message: 'Mot de passe modifié avec succès',
        severity: 'success'
      });
      
      setLoading(false);
    } catch (err) {
      setError(err.message || 'Une erreur est survenue lors du changement de mot de passe');
      setLoading(false);
    }
  };

  const handleExportData = async () => {
    try {
      setExportLoading(true);
      setError(null);
      
      if (user && user.id) {
        const exportData = await securityService.exportUserData(user.id);
        
        // Créer un fichier JSON à télécharger
        const dataStr = JSON.stringify(exportData, null, 2);
        const dataBlob = new Blob([dataStr], { type: 'application/json' });
        const url = URL.createObjectURL(dataBlob);
        
        // Créer un lien de téléchargement et cliquer dessus
        const a = document.createElement('a');
        a.href = url;
        a.download = `export_donnees_${user.nom}_${user.prenom}_${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        
        setSnackbar({
          open: true,
          message: 'Données exportées avec succès',
          severity: 'success'
        });
      }
      
      setExportLoading(false);
    } catch (err) {
      setError(err.message || 'Une erreur est survenue lors de l\'exportation des données');
      setExportLoading(false);
    }
  };

  const handleOpenDeleteDialog = () => {
    setDeleteConfirmDialog(true);
    setDeleteConfirmText('');
  };

  const handleCloseDeleteDialog = () => {
    setDeleteConfirmDialog(false);
    setDeleteConfirmText('');
  };

  const handleDeleteConfirmTextChange = (e) => {
    setDeleteConfirmText(e.target.value);
  };

  const handleDeleteAccount = async () => {
    try {
      setLoading(true);
      setError(null);
      
      if (user && user.id) {
        const success = await securityService.deleteUserData(user.id);
        
        if (success) {
          // Déconnecter l'utilisateur et rediriger vers la page d'accueil
          securityService.clearSensitiveData();
          window.location.href = '/';
        } else {
          throw new Error('Échec de la suppression du compte');
        }
      }
      
      setLoading(false);
    } catch (err) {
      setError(err.message || 'Une erreur est survenue lors de la suppression du compte');
      setLoading(false);
    }
  };

  if (loading && !user) return <Loader />;

  return (
    <Container maxWidth="lg">
      <Box sx={{ my: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          Paramètres de sécurité et confidentialité
        </Typography>
        <Typography variant="subtitle1" color="textSecondary" paragraph>
          Gérez vos préférences de confidentialité, la sécurité de votre compte et vos données personnelles
        </Typography>
        
        {error && <ErrorAlert message={error} sx={{ mb: 3 }} />}
        
        <Grid container spacing={3}>
          {/* Préférences de confidentialité */}
          <Grid item xs={12}>
            <Paper sx={{ p: 3 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <SecurityIcon color="primary" sx={{ mr: 2 }} />
                <Typography variant="h6">
                  Préférences de confidentialité
                </Typography>
              </Box>
              
              <Typography variant="body2" color="textSecondary" paragraph>
                Conformément au Règlement Général sur la Protection des Données (RGPD), veuillez indiquer vos préférences concernant l'utilisation de vos données personnelles.
              </Typography>
              
              <FormGroup sx={{ mt: 2 }}>
                <FormControlLabel
                  control={
                    <Checkbox
                      checked={consentForm.dataProcessing}
                      onChange={handleConsentChange}
                      name="dataProcessing"
                      color="primary"
                    />
                  }
                  label="J'accepte le traitement de mes données personnelles dans le cadre de l'utilisation de la plateforme de bilans de compétences"
                />
                <FormControlLabel
                  control={
                    <Checkbox
                      checked={consentForm.dataSharing}
                      onChange={handleConsentChange}
                      name="dataSharing"
                      color="primary"
                    />
                  }
                  label="J'accepte le partage de mes données avec les consultants impliqués dans mon bilan de compétences"
                />
                <FormControlLabel
                  control={
                    <Checkbox
                      checked={consentForm.marketing}
                      onChange={handleConsentChange}
                      name="marketing"
                      color="primary"
                    />
                  }
                  label="J'accepte de recevoir des communications marketing et des newsletters"
                />
                <FormControlLabel
                  control={
                    <Checkbox
                      checked={consentForm.cookies}
                      onChange={handleConsentChange}
                      name="cookies"
                      color="primary"
                    />
                  }
                  label="J'accepte l'utilisation de cookies pour améliorer mon expérience sur la plateforme"
                />
              </FormGroup>
              
              <Box sx={{ mt: 3, display: 'flex', justifyContent: 'flex-end' }}>
                <Button
                  variant="contained"
                  color="primary"
                  onClick={handleSaveConsent}
                  disabled={loading}
                >
                  {loading ? <CircularProgress size={24} /> : 'Enregistrer les préférences'}
                </Button>
              </Box>
            </Paper>
          </Grid>
          
          {/* Sécurité du compte */}
          <Grid item xs={12} md={6}>
            <Paper sx={{ p: 3, height: '100%' }}>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <LockIcon color="primary" sx={{ mr: 2 }} />
                <Typography variant="h6">
                  Sécurité du compte
                </Typography>
              </Box>
              
              <Typography variant="body2" color="textSecondary" paragraph>
                Modifiez votre mot de passe et renforcez la sécurité de votre compte.
              </Typography>
              
              <Box sx={{ mt: 3 }}>
                <TextField
                  fullWidth
                  label="Mot de passe actuel"
                  name="currentPassword"
                  type={showPassword ? 'text' : 'password'}
                  value={passwordForm.currentPassword}
                  onChange={handlePasswordChange}
                  margin="normal"
                  InputProps={{
                    endAdornment: (
                      <IconButton
                        onClick={() => setShowPassword(!showPassword)}
                        edge="end"
                      >
                        {showPassword ? <VisibilityOffIcon /> : <VisibilityIcon />}
                      </IconButton>
                    )
                  }}
                />
                
                <TextField
                  fullWidth
                  label="Nouveau mot de passe"
                  name="newPassword"
                  type={showPassword ? 'text' : 'password'}
                  value={passwordForm.newPassword}
                  onChange={handlePasswordChange}
                  margin="normal"
                />
                
                <TextField
                  fullWidth
                  label="Confirmer le nouveau mot de passe"
                  name="confirmPassword"
                  type={showPassword ? 'text' : 'password'}
                  value={passwordForm.confirmPassword}
                  onChange={handlePasswordChange}
                  margin="normal"
                  error={passwordForm.confirmPassword !== '' && passwordForm.newPassword !== passwordForm.confirmPassword}
                  helperText={passwordForm.confirmPassword !== '' && passwordForm.newPassword !== passwordForm.confirmPassword ? 'Les mots de passe ne correspondent pas' : ''}
                />
                
                {passwordStrength && (
                  <Box sx={{ mt: 2 }}>
                    <Typography variant="body2" gutterBottom>
                      Force du mot de passe:
                    </Typography>
                    <LinearProgress
                      variant="determinate"
                      value={(passwordStrength.score / 5) * 100}
                      color={passwordStrength.isStrong ? 'success' : 'warning'}
                      sx={{ mb: 1 }}
                    />
                    <Typography variant="caption" color="textSecondary">
                      {passwordStrength.suggestions.join(', ')}
                    </Typography>
                  </Box>
                )}
                
                <Box sx={{ mt: 3, display: 'flex', justifyContent: 'flex-end' }}>
                  <Button
                    variant="contained"
                    color="primary"
                    onClick={handleChangePassword}
                    disabled={loading || !passwordForm.currentPassword || !passwordForm.newPassword || !passwordForm.confirmPassword || passwordForm.newPassword !== passwordForm.confirmPassword || (passwordStrength && !passwordStrength.isStrong)}
                  >
                    {loading ? <CircularProgress size={24} /> : 'Changer le mot de passe'}
                  </Button>
                </Box>
              </Box>
            </Paper>
          </Grid>
          
          {/* Gestion des données personnelles */}
          <Grid item xs={12} md={6}>
            <Paper sx={{ p: 3, height: '100%' }}>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <LockOpenIcon color="primary" sx={{ mr: 2 }} />
                <Typography variant="h6">
                  Gestion des données personnelles
                </Typography>
              </Box>
              
              <Typography variant="body2" color="textSecondary" paragraph>
                Exercez vos droits RGPD : exportez vos données personnelles ou supprimez définitivement votre compte.
              </Typography>
              
              <Accordion sx={{ mt: 3 }}>
                <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                  <Typography>Exporter mes données (droit à la portabilité)</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <Typography variant="body2" color="textSecondary" paragraph>
                    Vous pouvez télécharger toutes vos données personnelles dans un format structuré et lisible par machine.
                  </Typography>
                  <Button
                    variant="outlined"
                    color="primary"
                    startIcon={<DownloadIcon />}
                    onClick={handleExportData}
                    disabled={exportLoading}
                    sx={{ mt: 1 }}
                  >
                    {exportLoading ? <CircularProgress size={24} /> : 'Exporter mes données'}
                  </Button>
                </AccordionDetails>
              </Accordion>
              
              <Accordion sx={{ mt: 2 }}>
                <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                  <Typography>Supprimer mon compte (droit à l'oubli)</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <Typography variant="body2" color="error" paragraph>
                    Attention : cette action est irréversible. Toutes vos données personnelles seront définitivement supprimées.
                  </Typography>
                  <Button
                    variant="outlined"
                    color="error"
                    startIcon={<DeleteIcon />}
                    onClick={handleOpenDeleteDialog}
                    sx={{ mt: 1 }}
                  >
                    Supprimer mon compte
                  </Button>
                </AccordionDetails>
              </Accordion>
            </Paper>
          </Grid>
          
          {/* Informations sur la sécurité */}
          <Grid item xs={12}>
            <Paper sx={{ p: 3 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <InfoIcon color="primary" sx={{ mr: 2 }} />
                <Typography variant="h6">
                  Informations sur la sécurité
                </Typography>
              </Box>
              
              <Typography variant="body2" paragraph>
                Notre plateforme met en œuvre les mesures de sécurité suivantes pour protéger vos données :
              </Typography>
              
              <List>
                <ListItem>
                  <ListItemIcon>
                    <CheckIcon color="success" />
                  </ListItemIcon>
                  <ListItemText 
                    primary="Chiffrement des données sensibles" 
                    secondary="Toutes les données sensibles sont chiffrées en utilisant des algorithmes de pointe" 
                  />
                </ListItem>
                <ListItem>
                  <ListItemIcon>
                    <CheckIcon color="success" />
                  </ListItemIcon>
                  <ListItemText 
                    primary="Authentification sécurisée" 
                    secondary="Connexion sécurisée avec vérification en deux étapes disponible" 
                  />
                </ListItem>
                <ListItem>
                  <ListItemIcon>
                    <CheckIcon color="success" />
                  </ListItemIcon>
                  <ListItemText 
                    primary="Journalisation des accès" 
                    secondary="Tous les accès aux données sont enregistrés pour garantir la traçabilité" 
                  />
                </ListItem>
                <ListItem>
                  <ListItemIcon>
                    <CheckIcon color="success" />
                  </ListItemIcon>
                  <ListItemText 
                    primary="Conformité RGPD" 
                    secondary="Notre plateforme est entièrement conforme au Règlement Général sur la Protection des Données" 
                  />
                </ListItem>
              </List>
            </Paper>
          </Grid>
        </Grid>
      </Box>
      
      {/* Dialogue de confirmation de suppression */}
      <Dialog open={deleteConfirmDialog} onClose={handleCloseDeleteDialog} maxWidth="sm" fullWidth>
        <DialogTitle>Confirmer la suppression du compte</DialogTitle>
        <DialogContent>
          <Typography variant="body1" paragraph>
            Cette action est irréversible. Toutes vos données personnelles seront définitivement supprimées.
          </Typography>
          <Typography variant="body1" paragraph>
            Pour confirmer, veuillez saisir "SUPPRIMER" ci-dessous :
          </Typography>
          <TextField
            fullWidth
            value={deleteConfirmText}
            onChange={handleDeleteConfirmTextChange}
            margin="normal"
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDeleteDialog}>Annuler</Button>
          <Button 
            onClick={handleDeleteAccount} 
            variant="contained" 
            color="error"
            disabled={deleteConfirmText !== 'SUPPRIMER'}
          >
            Supprimer définitivement
          </Button>
        </DialogActions>
      </Dialog>
      
      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
      >
        <Alert 
          onClose={() => setSnackbar({ ...snackbar, open: false })} 
          severity={snackbar.severity}
          sx={{ width: '100%' }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Container>
  );
};

export default SecuritySettings;
