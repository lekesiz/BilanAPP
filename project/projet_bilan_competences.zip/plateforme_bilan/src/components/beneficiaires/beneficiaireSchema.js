// Modèle de données pour les bénéficiaires
const beneficiaireSchema = {
  // Informations personnelles
  id: "String", // Identifiant unique
  nom: "String",
  prenom: "String",
  email: "String",
  telephone: "String",
  adresse: {
    rue: "String",
    codePostal: "String",
    ville: "String",
    pays: "String"
  },
  dateNaissance: "Date",
  
  // Situation professionnelle
  situationProfessionnelle: "String", // Salarié, Demandeur d'emploi, Indépendant, etc.
  entrepriseActuelle: "String",
  posteActuel: "String",
  secteurActivite: "String",
  anciennete: "Number", // en mois
  
  // Informations administratives
  statutBilan: "String", // En cours, Terminé, Annulé, etc.
  dateDebutBilan: "Date",
  dateFinBilan: "Date",
  phaseActuelle: "String", // Préliminaire, Investigation, Conclusions
  consultant: "ObjectId", // Référence au consultant assigné
  
  // Financement
  typeFinancement: "String", // CPF, OPCO, Entreprise, Personnel
  organismePrestataireId: "String", // Référence à l'organisme prestataire
  montantFinancement: "Number",
  statutFinancement: "String", // Validé, En attente, Refusé
  
  // Suivi
  rendezVous: [{
    date: "Date",
    duree: "Number", // en minutes
    type: "String", // Présentiel, Visioconférence
    statut: "String", // Planifié, Confirmé, Annulé, Terminé
    notes: "String"
  }],
  
  // Tests et évaluations
  evaluations: [{
    type: "String", // Auto-évaluation, Test personnalité, etc.
    dateAssignation: "Date",
    dateCompletion: "Date",
    statut: "String", // Assigné, En cours, Complété
    resultats: "Object" // Structure dépendant du type de test
  }],
  
  // Documents
  documents: [{
    titre: "String",
    type: "String", // Convention, Synthèse, etc.
    dateCreation: "Date",
    url: "String",
    statut: "String" // Brouillon, Finalisé, Signé
  }],
  
  // Projet professionnel
  projetProfessionnel: {
    objectifs: "String",
    competencesIdentifiees: ["String"],
    pistesExplorees: ["String"],
    projetRetenu: "String",
    planAction: "String"
  },
  
  // Métadonnées
  dateCreation: "Date",
  derniereModification: "Date",
  creePar: "ObjectId", // Référence à l'utilisateur qui a créé le bénéficiaire
  modifiePar: "ObjectId" // Référence à l'utilisateur qui a modifié le bénéficiaire
};

// Export du modèle
module.exports = beneficiaireSchema;
