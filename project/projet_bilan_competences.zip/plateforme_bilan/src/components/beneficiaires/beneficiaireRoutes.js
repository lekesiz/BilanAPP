// API pour la gestion des bénéficiaires
const express = require('express');
const router = express.Router();
const BeneficiaireController = require('./beneficiaireController');

// Routes pour les bénéficiaires
// GET - Récupérer tous les bénéficiaires (avec pagination et filtres)
router.get('/', BeneficiaireController.getAllBeneficiaires);

// GET - Récupérer un bénéficiaire par son ID
router.get('/:id', BeneficiaireController.getBeneficiaireById);

// POST - Créer un nouveau bénéficiaire
router.post('/', BeneficiaireController.createBeneficiaire);

// PUT - Mettre à jour un bénéficiaire
router.put('/:id', BeneficiaireController.updateBeneficiaire);

// DELETE - Supprimer un bénéficiaire
router.delete('/:id', BeneficiaireController.deleteBeneficiaire);

// GET - Récupérer les rendez-vous d'un bénéficiaire
router.get('/:id/rendez-vous', BeneficiaireController.getBeneficiaireRendezVous);

// POST - Ajouter un rendez-vous à un bénéficiaire
router.post('/:id/rendez-vous', BeneficiaireController.addRendezVous);

// PUT - Mettre à jour un rendez-vous
router.put('/:id/rendez-vous/:rendezVousId', BeneficiaireController.updateRendezVous);

// DELETE - Supprimer un rendez-vous
router.delete('/:id/rendez-vous/:rendezVousId', BeneficiaireController.deleteRendezVous);

// GET - Récupérer les évaluations d'un bénéficiaire
router.get('/:id/evaluations', BeneficiaireController.getBeneficiaireEvaluations);

// POST - Assigner une évaluation à un bénéficiaire
router.post('/:id/evaluations', BeneficiaireController.assignEvaluation);

// PUT - Mettre à jour le statut d'une évaluation
router.put('/:id/evaluations/:evaluationId', BeneficiaireController.updateEvaluationStatus);

// GET - Récupérer les documents d'un bénéficiaire
router.get('/:id/documents', BeneficiaireController.getBeneficiaireDocuments);

// POST - Ajouter un document à un bénéficiaire
router.post('/:id/documents', BeneficiaireController.addDocument);

// PUT - Mettre à jour un document
router.put('/:id/documents/:documentId', BeneficiaireController.updateDocument);

// DELETE - Supprimer un document
router.delete('/:id/documents/:documentId', BeneficiaireController.deleteDocument);

// PUT - Mettre à jour le projet professionnel d'un bénéficiaire
router.put('/:id/projet-professionnel', BeneficiaireController.updateProjetProfessionnel);

// GET - Récupérer les statistiques des bénéficiaires (pour les tableaux de bord)
router.get('/statistiques', BeneficiaireController.getBeneficiaireStats);

// GET - Rechercher des bénéficiaires
router.get('/recherche', BeneficiaireController.searchBeneficiaires);

module.exports = router;
