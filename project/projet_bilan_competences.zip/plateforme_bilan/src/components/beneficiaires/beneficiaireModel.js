const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// Schéma pour les rendez-vous
const RendezVousSchema = new Schema({
  date: {
    type: Date,
    required: [true, 'La date du rendez-vous est requise']
  },
  duree: {
    type: Number,
    required: [true, 'La durée du rendez-vous est requise'],
    min: [15, 'La durée minimale est de 15 minutes']
  },
  type: {
    type: String,
    enum: ['Présentiel', 'Visioconférence'],
    required: [true, 'Le type de rendez-vous est requis']
  },
  statut: {
    type: String,
    enum: ['Planifié', 'Confirmé', 'Annulé', 'Terminé'],
    default: 'Planifié'
  },
  notes: {
    type: String
  }
}, { timestamps: true });

// Schéma pour les évaluations
const EvaluationSchema = new Schema({
  type: {
    type: String,
    required: [true, 'Le type d\'évaluation est requis'],
    enum: ['Auto-évaluation', 'Test personnalité', 'Grille compétences', 'Projection professionnelle']
  },
  dateAssignation: {
    type: Date,
    default: Date.now
  },
  dateCompletion: {
    type: Date
  },
  statut: {
    type: String,
    enum: ['Assigné', 'En cours', 'Complété'],
    default: 'Assigné'
  },
  resultats: {
    type: Schema.Types.Mixed
  }
}, { timestamps: true });

// Schéma pour les documents
const DocumentSchema = new Schema({
  titre: {
    type: String,
    required: [true, 'Le titre du document est requis']
  },
  type: {
    type: String,
    required: [true, 'Le type de document est requis'],
    enum: ['Convention', 'Consentement', 'Synthèse', 'Plan action', 'Autre']
  },
  dateCreation: {
    type: Date,
    default: Date.now
  },
  url: {
    type: String,
    required: [true, 'L\'URL du document est requise']
  },
  statut: {
    type: String,
    enum: ['Brouillon', 'Finalisé', 'Signé'],
    default: 'Brouillon'
  }
}, { timestamps: true });

// Schéma pour le projet professionnel
const ProjetProfessionnelSchema = new Schema({
  objectifs: {
    type: String
  },
  competencesIdentifiees: [{
    type: String
  }],
  pistesExplorees: [{
    type: String
  }],
  projetRetenu: {
    type: String
  },
  planAction: {
    type: String
  }
}, { timestamps: true });

// Schéma principal pour les bénéficiaires
const BeneficiaireSchema = new Schema({
  // Informations personnelles
  nom: {
    type: String,
    required: [true, 'Le nom est requis'],
    trim: true
  },
  prenom: {
    type: String,
    required: [true, 'Le prénom est requis'],
    trim: true
  },
  email: {
    type: String,
    required: [true, 'L\'email est requis'],
    unique: true,
    match: [
      /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/,
      'Veuillez fournir un email valide'
    ]
  },
  telephone: {
    type: String,
    match: [
      /^(?:(?:\+|00)33|0)\s*[1-9](?:[\s.-]*\d{2}){4}$/,
      'Veuillez fournir un numéro de téléphone valide'
    ]
  },
  adresse: {
    rue: String,
    codePostal: String,
    ville: String,
    pays: {
      type: String,
      default: 'France'
    }
  },
  dateNaissance: {
    type: Date
  },
  
  // Situation professionnelle
  situationProfessionnelle: {
    type: String,
    enum: ['Salarié', 'Demandeur d\'emploi', 'Indépendant', 'Autre'],
    required: [true, 'La situation professionnelle est requise']
  },
  entrepriseActuelle: {
    type: String
  },
  posteActuel: {
    type: String
  },
  secteurActivite: {
    type: String
  },
  anciennete: {
    type: Number // en mois
  },
  
  // Informations administratives
  statutBilan: {
    type: String,
    enum: ['En cours', 'Terminé', 'Annulé', 'En attente'],
    default: 'En attente'
  },
  dateDebutBilan: {
    type: Date
  },
  dateFinBilan: {
    type: Date
  },
  phaseActuelle: {
    type: String,
    enum: ['Préliminaire', 'Investigation', 'Conclusions', 'Non démarré'],
    default: 'Non démarré'
  },
  consultant: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: [true, 'Le consultant assigné est requis']
  },
  
  // Financement
  typeFinancement: {
    type: String,
    enum: ['CPF', 'OPCO', 'Entreprise', 'Personnel', 'Autre'],
    required: [true, 'Le type de financement est requis']
  },
  organismePrestataireId: {
    type: String
  },
  montantFinancement: {
    type: Number
  },
  statutFinancement: {
    type: String,
    enum: ['Validé', 'En attente', 'Refusé'],
    default: 'En attente'
  },
  
  // Suivi
  rendezVous: [RendezVousSchema],
  
  // Tests et évaluations
  evaluations: [EvaluationSchema],
  
  // Documents
  documents: [DocumentSchema],
  
  // Projet professionnel
  projetProfessionnel: ProjetProfessionnelSchema,
  
  // Métadonnées
  dateCreation: {
    type: Date,
    default: Date.now
  },
  derniereModification: {
    type: Date,
    default: Date.now
  },
  creePar: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  modifiePar: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Middleware pre-save pour mettre à jour la date de dernière modification
BeneficiaireSchema.pre('save', function(next) {
  this.derniereModification = Date.now();
  next();
});

// Virtuel pour le nom complet
BeneficiaireSchema.virtual('nomComplet').get(function() {
  return `${this.prenom} ${this.nom}`;
});

// Virtuel pour l'âge
BeneficiaireSchema.virtual('age').get(function() {
  if (!this.dateNaissance) return null;
  const today = new Date();
  const birthDate = new Date(this.dateNaissance);
  let age = today.getFullYear() - birthDate.getFullYear();
  const m = today.getMonth() - birthDate.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
    age--;
  }
  return age;
});

// Virtuel pour la durée du bilan (en jours)
BeneficiaireSchema.virtual('dureeBilan').get(function() {
  if (!this.dateDebutBilan || !this.dateFinBilan) return null;
  const debut = new Date(this.dateDebutBilan);
  const fin = new Date(this.dateFinBilan);
  const diffTime = Math.abs(fin - debut);
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  return diffDays;
});

// Virtuel pour le prochain rendez-vous
BeneficiaireSchema.virtual('prochainRendezVous').get(function() {
  if (!this.rendezVous || this.rendezVous.length === 0) return null;
  
  const now = new Date();
  const futureRdv = this.rendezVous
    .filter(rdv => new Date(rdv.date) > now && rdv.statut !== 'Annulé')
    .sort((a, b) => new Date(a.date) - new Date(b.date));
  
  return futureRdv.length > 0 ? futureRdv[0] : null;
});

// Index pour améliorer les performances des requêtes
BeneficiaireSchema.index({ nom: 1, prenom: 1 });
BeneficiaireSchema.index({ email: 1 }, { unique: true });
BeneficiaireSchema.index({ consultant: 1 });
BeneficiaireSchema.index({ statutBilan: 1 });
BeneficiaireSchema.index({ phaseActuelle: 1 });
BeneficiaireSchema.index({ typeFinancement: 1 });
BeneficiaireSchema.index({ dateDebutBilan: -1 });

module.exports = mongoose.model('Beneficiaire', BeneficiaireSchema);
