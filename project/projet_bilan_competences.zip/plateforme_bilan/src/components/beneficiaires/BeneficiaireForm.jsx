import React, { useState, useEffect } from 'react';
import { 
  Container, 
  Typography, 
  Box, 
  Grid, 
  Paper, 
  Button, 
  TextField, 
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  FormHelperText,
  Divider,
  Stepper,
  Step,
  StepLabel,
  Card,
  CardContent,
  Alert,
  Snackbar
} from '@mui/material';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { useNavigate, useParams } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { 
  createBeneficiaire, 
  updateBeneficiaire, 
  getBeneficiaireById 
} from '../../services/beneficiaireService';
import { getConsultants } from '../../services/userService';
import Loader from '../common/Loader';
import ErrorAlert from '../common/ErrorAlert';

const BeneficiaireForm = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const isEditMode = Boolean(id);
  
  // États
  const [formData, setFormData] = useState({
    nom: '',
    prenom: '',
    email: '',
    telephone: '',
    adresse: {
      rue: '',
      codePostal: '',
      ville: '',
      pays: 'France'
    },
    dateNaissance: null,
    situationProfessionnelle: '',
    entrepriseActuelle: '',
    posteActuel: '',
    secteurActivite: '',
    anciennete: '',
    statutBilan: 'En attente',
    dateDebutBilan: null,
    dateFinBilan: null,
    phaseActuelle: 'Non démarré',
    consultant: user.role === 'consultant' ? user.id : '',
    typeFinancement: '',
    organismePrestataireId: '',
    montantFinancement: '',
    statutFinancement: 'En attente'
  });
  
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [loadingData, setLoadingData] = useState(isEditMode);
  const [error, setError] = useState(null);
  const [consultants, setConsultants] = useState([]);
  const [activeStep, setActiveStep] = useState(0);
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success'
  });
  
  // Étapes du formulaire
  const steps = [
    'Informations personnelles',
    'Situation professionnelle',
    'Informations du bilan'
  ];
  
  // Charger les données pour l'édition
  useEffect(() => {
    const loadData = async () => {
      try {
        setLoadingData(true);
        
        // Charger les consultants
        const consultantsData = await getConsultants();
        setConsultants(consultantsData);
        
        // Si mode édition, charger les données du bénéficiaire
        if (isEditMode) {
          const beneficiaireData = await getBeneficiaireById(id);
          
          // Formater les dates
          const formattedData = {
            ...beneficiaireData,
            dateNaissance: beneficiaireData.dateNaissance ? new Date(beneficiaireData.dateNaissance) : null,
            dateDebutBilan: beneficiaireData.dateDebutBilan ? new Date(beneficiaireData.dateDebutBilan) : null,
            dateFinBilan: beneficiaireData.dateFinBilan ? new Date(beneficiaireData.dateFinBilan) : null,
            consultant: beneficiaireData.consultant?.id || ''
          };
          
          setFormData(formattedData);
        }
        
        setLoadingData(false);
      } catch (err) {
        setError(err.message || 'Une erreur est survenue lors du chargement des données');
        setLoadingData(false);
      }
    };
    
    loadData();
  }, [id, isEditMode]);
  
  // Gestionnaires d'événements
  const handleChange = (e) => {
    const { name, value } = e.target;
    
    // Gérer les champs imbriqués (adresse)
    if (name.includes('.')) {
      const [parent, child] = name.split('.');
      setFormData({
        ...formData,
        [parent]: {
          ...formData[parent],
          [child]: value
        }
      });
    } else {
      setFormData({
        ...formData,
        [name]: value
      });
    }
    
    // Effacer l'erreur si le champ est rempli
    if (errors[name] && value) {
      setErrors({
        ...errors,
        [name]: ''
      });
    }
  };
  
  const handleDateChange = (name, date) => {
    setFormData({
      ...formData,
      [name]: date
    });
    
    // Effacer l'erreur si le champ est rempli
    if (errors[name] && date) {
      setErrors({
        ...errors,
        [name]: ''
      });
    }
  };
  
  const handleNext = () => {
    // Valider l'étape actuelle
    const currentErrors = validateStep(activeStep);
    
    if (Object.keys(currentErrors).length === 0) {
      setActiveStep((prevActiveStep) => prevActiveStep + 1);
    } else {
      setErrors(currentErrors);
    }
  };
  
  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };
  
  const validateStep = (step) => {
    const stepErrors = {};
    
    switch (step) {
      case 0: // Informations personnelles
        if (!formData.nom) stepErrors.nom = 'Le nom est requis';
        if (!formData.prenom) stepErrors.prenom = 'Le prénom est requis';
        if (!formData.email) {
          stepErrors.email = 'L\'email est requis';
        } else if (!/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(formData.email)) {
          stepErrors.email = 'Format d\'email invalide';
        }
        if (formData.telephone && !/^(?:(?:\+|00)33|0)\s*[1-9](?:[\s.-]*\d{2}){4}$/.test(formData.telephone)) {
          stepErrors.telephone = 'Format de téléphone invalide';
        }
        break;
        
      case 1: // Situation professionnelle
        if (!formData.situationProfessionnelle) {
          stepErrors.situationProfessionnelle = 'La situation professionnelle est requise';
        }
        break;
        
      case 2: // Informations du bilan
        if (!formData.consultant) stepErrors.consultant = 'Le consultant est requis';
        if (!formData.typeFinancement) stepErrors.typeFinancement = 'Le type de financement est requis';
        break;
        
      default:
        break;
    }
    
    return stepErrors;
  };
  
  const validateForm = () => {
    let formErrors = {};
    
    // Valider toutes les étapes
    for (let i = 0; i < steps.length; i++) {
      const stepErrors = validateStep(i);
      formErrors = { ...formErrors, ...stepErrors };
    }
    
    return formErrors;
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Valider le formulaire complet
    const formErrors = validateForm();
    
    if (Object.keys(formErrors).length > 0) {
      setErrors(formErrors);
      
      // Trouver la première étape avec des erreurs
      for (let i = 0; i < steps.length; i++) {
        const stepFields = getStepFields(i);
        const hasStepError = stepFields.some(field => formErrors[field]);
        
        if (hasStepError) {
          setActiveStep(i);
          break;
        }
      }
      
      return;
    }
    
    try {
      setLoading(true);
      
      if (isEditMode) {
        await updateBeneficiaire(id, formData);
        setSnackbar({
          open: true,
          message: 'Bénéficiaire mis à jour avec succès',
          severity: 'success'
        });
      } else {
        await createBeneficiaire(formData);
        setSnackbar({
          open: true,
          message: 'Bénéficiaire créé avec succès',
          severity: 'success'
        });
      }
      
      // Rediriger après un court délai
      setTimeout(() => {
        navigate('/beneficiaires');
      }, 1500);
    } catch (err) {
      setError(err.message || 'Une erreur est survenue lors de l\'enregistrement');
      setLoading(false);
    }
  };
  
  const handleCancel = () => {
    navigate('/beneficiaires');
  };
  
  const handleCloseSnackbar = () => {
    setSnackbar({
      ...snackbar,
      open: false
    });
  };
  
  // Obtenir les champs d'une étape
  const getStepFields = (step) => {
    switch (step) {
      case 0: // Informations personnelles
        return ['nom', 'prenom', 'email', 'telephone', 'adresse.rue', 'adresse.codePostal', 'adresse.ville', 'dateNaissance'];
      case 1: // Situation professionnelle
        return ['situationProfessionnelle', 'entrepriseActuelle', 'posteActuel', 'secteurActivite', 'anciennete'];
      case 2: // Informations du bilan
        return ['statutBilan', 'dateDebutBilan', 'dateFinBilan', 'phaseActuelle', 'consultant', 'typeFinancement', 'montantFinancement', 'statutFinancement'];
      default:
        return [];
    }
  };
  
  // Rendu du contenu de l'étape
  const getStepContent = (step) => {
    switch (step) {
      case 0:
        return (
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Nom"
                name="nom"
                value={formData.nom}
                onChange={handleChange}
                error={Boolean(errors.nom)}
                helperText={errors.nom}
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Prénom"
                name="prenom"
                value={formData.prenom}
                onChange={handleChange}
                error={Boolean(errors.prenom)}
                helperText={errors.prenom}
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                error={Boolean(errors.email)}
                helperText={errors.email}
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Téléphone"
                name="telephone"
                value={formData.telephone}
                onChange={handleChange}
                error={Boolean(errors.telephone)}
                helperText={errors.telephone}
                placeholder="06 12 34 56 78"
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Adresse"
                name="adresse.rue"
                value={formData.adresse.rue}
                onChange={handleChange}
                error={Boolean(errors['adresse.rue'])}
                helperText={errors['adresse.rue']}
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <TextField
                fullWidth
                label="Code postal"
                name="adresse.codePostal"
                value={formData.adresse.codePostal}
                onChange={handleChange}
                error={Boolean(errors['adresse.codePostal'])}
                helperText={errors['adresse.codePostal']}
              />
            </Grid>
            <Grid item xs={12} md={8}>
              <TextField
                fullWidth
                label="Ville"
                name="adresse.ville"
                value={formData.adresse.ville}
                onChange={handleChange}
                error={Boolean(errors['adresse.ville'])}
                helperText={errors['adresse.ville']}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <LocalizationProvider dateAdapter={AdapterDateFns}>
                <DatePicker
                  label="Date de naissance"
                  value={formData.dateNaissance}
                  onChange={(date) => handleDateChange('dateNaissance', date)}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      fullWidth
                      error={Boolean(errors.dateNaissance)}
                      helperText={errors.dateNaissance}
                    />
                  )}
                />
              </LocalizationProvider>
            </Grid>
          </Grid>
        );
      case 1:
        return (
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <FormControl 
                fullWidth 
                error={Boolean(errors.situationProfessionnelle)}
                required
              >
                <InputLabel>Situation professionnelle</InputLabel>
                <Select
                  name="situationProfessionnelle"
                  value={formData.situationProfessionnelle}
                  onChange={handleChange}
                  label="Situation professionnelle"
                >
                  <MenuItem value="Salarié">Salarié</MenuItem>
                  <MenuItem value="Demandeur d'emploi">Demandeur d'emploi</MenuItem>
                  <MenuItem value="Indépendant">Indépendant</MenuItem>
                  <MenuItem value="Autre">Autre</MenuItem>
                </Select>
                {errors.situationProfessionnelle && (
                  <FormHelperText>{errors.situationProfessionnelle}</FormHelperText>
                )}
              </FormControl>
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Entreprise actuelle"
                name="entrepriseActuelle"
                value={formData.entrepriseActuelle}
                onChange={handleChange}
                error={Boolean(errors.entrepriseActuelle)}
                helperText={errors.entrepriseActuelle}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Poste actuel"
                name="posteActuel"
                value={formData.posteActuel}
                onChange={handleChange}
                error={Boolean(errors.posteActuel)}
                helperText={errors.posteActuel}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Secteur d'activité"
                name="secteurActivite"
                value={formData.secteurActivite}
                onChange={handleChange}
                error={Boolean(errors.secteurActivite)}
                helperText={errors.secteurActivite}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Ancienneté (en mois)"
                name="anciennete"
                type="number"
                value={formData.anciennete}
                onChange={handleChange}
                error={Boolean(errors.anciennete)}
                helperText={errors.anciennete}
              />
            </Grid>
          </Grid>
        );
      case 2:
        return (
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <FormControl 
                fullWidth 
                error={Boolean(errors.statutBilan)}
              >
                <InputLabel>Statut du bilan</InputLabel>
                <Select
                  name="statutBilan"
                  value={formData.statutBilan}
                  onChange={handleChange}
                  label="Statut du bilan"
                >
                  <MenuItem value="En attente">En attente</MenuItem>
                  <MenuItem value="En cours">En cours</MenuItem>
                  <MenuItem value="Terminé">Terminé</MenuItem>
                  <MenuItem value="Annulé">Annulé</MenuItem>
                </Select>
                {errors.statutBilan && (
                  <FormHelperText>{errors.statutBilan}</FormHelperText>
                )}
              </FormControl>
            </Grid>
            <Grid item xs={12} md={6}>
              <FormControl 
                fullWidth 
                error={Boolean(errors.phaseActuelle)}
              >
                <InputLabel>Phase actuelle</InputLabel>
                <Select
                  name="phaseActuelle"
                  value={formData.phaseActuelle}
                  onChange={handleChange}
                  label="Phase actuelle"
                >
                  <MenuItem value="Non démarré">Non démarré</MenuItem>
                  <MenuItem value="Préliminaire">Préliminaire</MenuItem>
                  <MenuItem value="Investigation">Investigation</MenuItem>
                  <MenuItem value="Conclusions">Conclusions</MenuItem>
                </Select>
                {errors.phaseActuelle && (
                  <FormHelperText>{errors.phaseActuelle}</FormHelperText>
                )}
              </FormControl>
            </Grid>
            <Grid item xs={12} md={6}>
              <LocalizationProvider dateAdapter={AdapterDateFns}>
                <DatePicker
                  label="Date de début"
                  value={formData.dateDebutBilan}
                  onChange={(date) => handleDateChange('dateDebutBilan', date)}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      fullWidth
                      error={Boolean(errors.dateDebutBilan)}
                      helperText={errors.dateDebutBilan}
                    />
                  )}
                />
              </LocalizationProvider>
            </Grid>
            <Grid item xs={12} md={6}>
              <LocalizationProvider dateAdapter={AdapterDateFns}>
                <DatePicker
                  label="Date de fin"
                  value={formData.dateFinBilan}
                  onChange={(date) => handleDateChange('dateFinBilan', date)}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      fullWidth
                      error={Boolean(errors.dateFinBilan)}
                      helperText={errors.dateFinBilan}
                    />
                  )}
                />
              </LocalizationProvider>
            </Grid>
            <Grid item xs={12}>
              <FormControl 
                fullWidth 
                error={Boolean(errors.consultant)}
                required
              >
                <InputLabel>Consultant</InputLabel>
                <Select
                  name="consultant"
                  value={formData.consultant}
                  onChange={handleChange}
                  label="Consultant"
                  disabled={user.role === 'consultant'}
                >
                  {consultants.map((consultant) => (
                    <MenuItem key={consultant.id} value={consultant.id}>
                      {consultant.prenom} {consultant.nom}
                    </MenuItem>
                  ))}
                </Select>
                {errors.consultant && (
                  <FormHelperText>{errors.consultant}</FormHelperText>
                )}
              </FormControl>
            </Grid>
            <Grid item xs={12} md={6}>
              <FormControl 
                fullWidth 
                error={Boolean(errors.typeFinancement)}
                required
              >
                <InputLabel>Type de financement</InputLabel>
                <Select
                  name="typeFinancement"
                  value={formData.typeFinancement}
                  onChange={handleChange}
                  label="Type de financement"
                >
                  <MenuItem value="CPF">CPF</MenuItem>
                  <MenuItem value="OPCO">OPCO</MenuItem>
                  <MenuItem value="Entreprise">Entreprise</MenuItem>
                  <MenuItem value="Personnel">Personnel</MenuItem>
                  <MenuItem value="Autre">Autre</MenuItem>
                </Select>
                {errors.typeFinancement && (
                  <FormHelperText>{errors.typeFinancement}</FormHelperText>
                )}
              </FormControl>
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Montant du financement"
                name="montantFinancement"
                type="number"
                value={formData.montantFinancement}
                onChange={handleChange}
                error={Boolean(errors.montantFinancement)}
                helperText={errors.montantFinancement}
                InputProps={{
                  endAdornment: '€'
                }}
              />
            </Grid>
            <Grid item xs={12}>
              <FormControl 
                fullWidth 
                error={Boolean(errors.statutFinancement)}
              >
                <InputLabel>Statut du financement</InputLabel>
                <Select
                  name="statutFinancement"
                  value={formData.statutFinancement}
                  onChange={handleChange}
                  label="Statut du financement"
                >
                  <MenuItem value="En attente">En attente</MenuItem>
                  <MenuItem value="Validé">Validé</MenuItem>
                  <MenuItem value="Refusé">Refusé</MenuItem>
                </Select>
                {errors.statutFinancement && (
                  <FormHelperText>{errors.statutFinancement}</FormHelperText>
                )}
              </FormControl>
            </Grid>
          </Grid>
        );
      default:
        return 'Étape inconnue';
    }
  };
  
  if (loadingData) return <Loader />;
  
  return (
    <Container maxWidth="lg">
      <Box sx={{ my: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          {isEditMode ? 'Modifier le bénéficiaire' : 'Ajouter un bénéficiaire'}
        </Typography>
        
        {error && <ErrorAlert message={error} sx={{ mb: 3 }} />}
        
        <Paper sx={{ p: 3 }}>
          <Stepper activeStep={activeStep} sx={{ mb: 4 }}>
            {steps.map((label) => (
              <Step key={label}>
                <StepLabel>{label}</StepLabel>
              </Step>
            ))}
          </Stepper>
          
          <form onSubmit={handleSubmit}>
            <Box sx={{ mb: 4 }}>
              {getStepContent(activeStep)}
            </Box>
            
            <Divider sx={{ mb: 2 }} />
            
            <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
              <Button
                variant="outlined"
                onClick={activeStep === 0 ? handleCancel : handleBack}
                sx={{ mr: 1 }}
              >
                {activeStep === 0 ? 'Annuler' : 'Précédent'}
              </Button>
              <Box>
                {activeStep === steps.length - 1 ? (
                  <Button
                    variant="contained"
                    color="primary"
                    type="submit"
                    disabled={loading}
                  >
                    {loading ? 'Enregistrement...' : 'Enregistrer'}
                  </Button>
                ) : (
                  <Button
                    variant="contained"
                    color="primary"
                    onClick={handleNext}
                  >
                    Suivant
                  </Button>
                )}
              </Box>
            </Box>
          </form>
        </Paper>
      </Box>
      
      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={handleCloseSnackbar}
      >
        <Alert 
          onClose={handleCloseSnackbar} 
          severity={snackbar.severity}
          sx={{ width: '100%' }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Container>
  );
};

export default BeneficiaireForm;
