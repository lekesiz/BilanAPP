// Contrôleur pour la gestion des bénéficiaires
const Beneficiaire = require('./beneficiaireModel');

// Classe contrôleur pour les bénéficiaires
class BeneficiaireController {
  
  // Récupérer tous les bénéficiaires avec pagination et filtres
  static async getAllBeneficiaires(req, res) {
    try {
      const { page = 1, limit = 10, statut, phase, consultant } = req.query;
      const skip = (page - 1) * limit;
      
      // Construction des filtres
      const filter = {};
      if (statut) filter.statutBilan = statut;
      if (phase) filter.phaseActuelle = phase;
      if (consultant) filter.consultant = consultant;
      
      // Si l'utilisateur est un consultant, ne montrer que ses bénéficiaires
      if (req.user.role === 'consultant') {
        filter.consultant = req.user.id;
      }
      
      // Récupération des bénéficiaires avec pagination
      const beneficiaires = await Beneficiaire.find(filter)
        .skip(skip)
        .limit(parseInt(limit))
        .sort({ derniereModification: -1 });
      
      // Comptage total pour la pagination
      const total = await Beneficiaire.countDocuments(filter);
      
      res.status(200).json({
        success: true,
        count: beneficiaires.length,
        total,
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          totalPages: Math.ceil(total / limit)
        },
        data: beneficiaires
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: "Erreur lors de la récupération des bénéficiaires",
        error: error.message
      });
    }
  }
  
  // Récupérer un bénéficiaire par son ID
  static async getBeneficiaireById(req, res) {
    try {
      const beneficiaire = await Beneficiaire.findById(req.params.id);
      
      // Vérifier si le bénéficiaire existe
      if (!beneficiaire) {
        return res.status(404).json({
          success: false,
          message: "Bénéficiaire non trouvé"
        });
      }
      
      // Vérifier les droits d'accès
      if (req.user.role === 'consultant' && beneficiaire.consultant.toString() !== req.user.id) {
        return res.status(403).json({
          success: false,
          message: "Accès non autorisé à ce bénéficiaire"
        });
      }
      
      res.status(200).json({
        success: true,
        data: beneficiaire
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: "Erreur lors de la récupération du bénéficiaire",
        error: error.message
      });
    }
  }
  
  // Créer un nouveau bénéficiaire
  static async createBeneficiaire(req, res) {
    try {
      // Ajouter les métadonnées
      req.body.dateCreation = new Date();
      req.body.derniereModification = new Date();
      req.body.creePar = req.user.id;
      req.body.modifiePar = req.user.id;
      
      // Si l'utilisateur est un consultant, l'assigner automatiquement
      if (req.user.role === 'consultant' && !req.body.consultant) {
        req.body.consultant = req.user.id;
      }
      
      // Créer le bénéficiaire
      const beneficiaire = await Beneficiaire.create(req.body);
      
      res.status(201).json({
        success: true,
        data: beneficiaire
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        message: "Erreur lors de la création du bénéficiaire",
        error: error.message
      });
    }
  }
  
  // Mettre à jour un bénéficiaire
  static async updateBeneficiaire(req, res) {
    try {
      // Vérifier si le bénéficiaire existe
      let beneficiaire = await Beneficiaire.findById(req.params.id);
      
      if (!beneficiaire) {
        return res.status(404).json({
          success: false,
          message: "Bénéficiaire non trouvé"
        });
      }
      
      // Vérifier les droits d'accès
      if (req.user.role === 'consultant' && beneficiaire.consultant.toString() !== req.user.id) {
        return res.status(403).json({
          success: false,
          message: "Accès non autorisé à ce bénéficiaire"
        });
      }
      
      // Mettre à jour les métadonnées
      req.body.derniereModification = new Date();
      req.body.modifiePar = req.user.id;
      
      // Mettre à jour le bénéficiaire
      beneficiaire = await Beneficiaire.findByIdAndUpdate(
        req.params.id,
        req.body,
        { new: true, runValidators: true }
      );
      
      res.status(200).json({
        success: true,
        data: beneficiaire
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        message: "Erreur lors de la mise à jour du bénéficiaire",
        error: error.message
      });
    }
  }
  
  // Supprimer un bénéficiaire
  static async deleteBeneficiaire(req, res) {
    try {
      // Vérifier si le bénéficiaire existe
      const beneficiaire = await Beneficiaire.findById(req.params.id);
      
      if (!beneficiaire) {
        return res.status(404).json({
          success: false,
          message: "Bénéficiaire non trouvé"
        });
      }
      
      // Vérifier les droits d'accès (seuls les admins peuvent supprimer)
      if (req.user.role !== 'admin') {
        return res.status(403).json({
          success: false,
          message: "Seuls les administrateurs peuvent supprimer des bénéficiaires"
        });
      }
      
      // Supprimer le bénéficiaire
      await beneficiaire.remove();
      
      res.status(200).json({
        success: true,
        data: {}
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: "Erreur lors de la suppression du bénéficiaire",
        error: error.message
      });
    }
  }
  
  // Récupérer les rendez-vous d'un bénéficiaire
  static async getBeneficiaireRendezVous(req, res) {
    try {
      const beneficiaire = await Beneficiaire.findById(req.params.id);
      
      if (!beneficiaire) {
        return res.status(404).json({
          success: false,
          message: "Bénéficiaire non trouvé"
        });
      }
      
      // Vérifier les droits d'accès
      if (req.user.role === 'consultant' && beneficiaire.consultant.toString() !== req.user.id) {
        return res.status(403).json({
          success: false,
          message: "Accès non autorisé à ce bénéficiaire"
        });
      }
      
      res.status(200).json({
        success: true,
        count: beneficiaire.rendezVous.length,
        data: beneficiaire.rendezVous
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: "Erreur lors de la récupération des rendez-vous",
        error: error.message
      });
    }
  }
  
  // Ajouter un rendez-vous à un bénéficiaire
  static async addRendezVous(req, res) {
    try {
      const beneficiaire = await Beneficiaire.findById(req.params.id);
      
      if (!beneficiaire) {
        return res.status(404).json({
          success: false,
          message: "Bénéficiaire non trouvé"
        });
      }
      
      // Vérifier les droits d'accès
      if (req.user.role === 'consultant' && beneficiaire.consultant.toString() !== req.user.id) {
        return res.status(403).json({
          success: false,
          message: "Accès non autorisé à ce bénéficiaire"
        });
      }
      
      // Ajouter le rendez-vous
      beneficiaire.rendezVous.push(req.body);
      
      // Mettre à jour les métadonnées
      beneficiaire.derniereModification = new Date();
      beneficiaire.modifiePar = req.user.id;
      
      await beneficiaire.save();
      
      res.status(201).json({
        success: true,
        data: beneficiaire.rendezVous[beneficiaire.rendezVous.length - 1]
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        message: "Erreur lors de l'ajout du rendez-vous",
        error: error.message
      });
    }
  }
  
  // Mettre à jour un rendez-vous
  static async updateRendezVous(req, res) {
    try {
      const beneficiaire = await Beneficiaire.findById(req.params.id);
      
      if (!beneficiaire) {
        return res.status(404).json({
          success: false,
          message: "Bénéficiaire non trouvé"
        });
      }
      
      // Vérifier les droits d'accès
      if (req.user.role === 'consultant' && beneficiaire.consultant.toString() !== req.user.id) {
        return res.status(403).json({
          success: false,
          message: "Accès non autorisé à ce bénéficiaire"
        });
      }
      
      // Trouver l'index du rendez-vous
      const rendezVousIndex = beneficiaire.rendezVous.findIndex(
        rv => rv._id.toString() === req.params.rendezVousId
      );
      
      if (rendezVousIndex === -1) {
        return res.status(404).json({
          success: false,
          message: "Rendez-vous non trouvé"
        });
      }
      
      // Mettre à jour le rendez-vous
      beneficiaire.rendezVous[rendezVousIndex] = {
        ...beneficiaire.rendezVous[rendezVousIndex].toObject(),
        ...req.body
      };
      
      // Mettre à jour les métadonnées
      beneficiaire.derniereModification = new Date();
      beneficiaire.modifiePar = req.user.id;
      
      await beneficiaire.save();
      
      res.status(200).json({
        success: true,
        data: beneficiaire.rendezVous[rendezVousIndex]
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        message: "Erreur lors de la mise à jour du rendez-vous",
        error: error.message
      });
    }
  }
  
  // Supprimer un rendez-vous
  static async deleteRendezVous(req, res) {
    try {
      const beneficiaire = await Beneficiaire.findById(req.params.id);
      
      if (!beneficiaire) {
        return res.status(404).json({
          success: false,
          message: "Bénéficiaire non trouvé"
        });
      }
      
      // Vérifier les droits d'accès
      if (req.user.role === 'consultant' && beneficiaire.consultant.toString() !== req.user.id) {
        return res.status(403).json({
          success: false,
          message: "Accès non autorisé à ce bénéficiaire"
        });
      }
      
      // Trouver l'index du rendez-vous
      const rendezVousIndex = beneficiaire.rendezVous.findIndex(
        rv => rv._id.toString() === req.params.rendezVousId
      );
      
      if (rendezVousIndex === -1) {
        return res.status(404).json({
          success: false,
          message: "Rendez-vous non trouvé"
        });
      }
      
      // Supprimer le rendez-vous
      beneficiaire.rendezVous.splice(rendezVousIndex, 1);
      
      // Mettre à jour les métadonnées
      beneficiaire.derniereModification = new Date();
      beneficiaire.modifiePar = req.user.id;
      
      await beneficiaire.save();
      
      res.status(200).json({
        success: true,
        data: {}
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: "Erreur lors de la suppression du rendez-vous",
        error: error.message
      });
    }
  }
  
  // Récupérer les évaluations d'un bénéficiaire
  static async getBeneficiaireEvaluations(req, res) {
    try {
      const beneficiaire = await Beneficiaire.findById(req.params.id);
      
      if (!beneficiaire) {
        return res.status(404).json({
          success: false,
          message: "Bénéficiaire non trouvé"
        });
      }
      
      // Vérifier les droits d'accès
      if (req.user.role === 'consultant' && beneficiaire.consultant.toString() !== req.user.id) {
        return res.status(403).json({
          success: false,
          message: "Accès non autorisé à ce bénéficiaire"
        });
      }
      
      res.status(200).json({
        success: true,
        count: beneficiaire.evaluations.length,
        data: beneficiaire.evaluations
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: "Erreur lors de la récupération des évaluations",
        error: error.message
      });
    }
  }
  
  // Assigner une évaluation à un bénéficiaire
  static async assignEvaluation(req, res) {
    try {
      const beneficiaire = await Beneficiaire.findById(req.params.id);
      
      if (!beneficiaire) {
        return res.status(404).json({
          success: false,
          message: "Bénéficiaire non trouvé"
        });
      }
      
      // Vérifier les droits d'accès
      if (req.user.role === 'consultant' && beneficiaire.consultant.toString() !== req.user.id) {
        return res.status(403).json({
          success: false,
          message: "Accès non autorisé à ce bénéficiaire"
        });
      }
      
      // Ajouter l'évaluation
      const evaluation = {
        ...req.body,
        dateAssignation: new Date(),
        statut: 'Assigné'
      };
      
      beneficiaire.evaluations.push(evaluation);
      
      // Mettre à jour les métadonnées
      beneficiaire.derniereModification = new Date();
      beneficiaire.modifiePar = req.user.id;
      
      await beneficiaire.save();
      
      res.status(201).json({
        success: true,
        data: beneficiaire.evaluations[beneficiaire.evaluations.length - 1]
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        message: "Erreur lors de l'assignation de l'évaluation",
        error: error.message
      });
    }
  }
  
  // Mettre à jour le statut d'une évaluation
  static async updateEvaluationStatus(req, res) {
    try {
      const beneficiaire = await Beneficiaire.findById(req.params.id);
      
      if (!beneficiaire) {
        return res.status(404).json({
          success: false,
          message: "Bénéficiaire non trouvé"
        });
      }
      
      // Trouver l'index de l'évaluation
      const evaluationIndex = beneficiaire.evaluations.findIndex(
        eval => eval._id.toString() === req.params.evaluationId
      );
      
      if (evaluationIndex === -1) {
        return res.status(404).json({
          success: false,
          message: "Évaluation non trouvée"
        });
      }
      
      // Mettre à jour le statut de l'évaluation
      beneficiaire.evaluations[evaluationIndex].statut = req.body.statut;
      
      // Si l'évaluation est complétée, ajouter la date de complétion
      if (req.body.statut === 'Complété') {
        beneficiaire.evaluations[evaluationIndex].dateCompletion = new Date();
      }
      
      // Si des résultats sont fournis, les ajouter
      if (req.body.resultats) {
        beneficiaire.evaluations[evaluationIndex].resultats = req.body.resultats;
      }
      
      // Mettre à jour les métadonnées
      beneficiaire.derniereModification = new Date();
      beneficiaire.modifiePar = req.user.id;
      
      await beneficiaire.save();
      
      res.status(200).json({
        success: true,
        data: beneficiaire.evaluations[evaluationIndex]
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        message: "Erreur lors de la mise à jour du statut de l'évaluation",
        error: error.message
      });
    }
  }
  
  // Récupérer les documents d'un bénéficiaire
  static async getBeneficiaireDocuments(req, res) {
    try {
      const beneficiaire = await Beneficiaire.findById(req.params.id);
      
      if (!beneficiaire) {
        return res.status(404).json({
          success: false,
          message: "Bénéficiaire non trouvé"
        });
      }
      
      // Vérifier les droits d'accès
      if (req.user.role === 'consultant' && beneficiaire.consultant.toString() !== req.user.id) {
        return res.status(403).json({
          success: false,
          message: "Accès non autorisé à ce bénéficiaire"
        });
      }
      
      res.status(200).json({
        success: true,
        count: beneficiaire.documents.length,
        data: beneficiaire.documents
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: "Erreur lors de la récupération des documents",
        error: error.message
      });
    }
  }
  
  // Ajouter un document à un bénéficiaire
  static async addDocument(req, res) {
    try {
      const beneficiaire = await Beneficiaire.findById(req.params.id);
      
      if (!beneficiaire) {
        return res.status(404).json({
          success: false,
          message: "Bénéficiaire non trouvé"
        });
      }
      
      // Vérifier les droits d'accès
      if (req.user.role === 'consultant' && beneficiaire.consultant.toString() !== req.user.id) {
        return res.status(403).json({
          success: false,
          message: "Accès non autorisé à ce bénéficiaire"
        });
      }
      
      // Ajouter le document
      const document = {
        ...req.body,
        dateCreation: new Date()
      };
      
      beneficiaire.documents.push(document);
      
      // Mettre à jour les métadonnées
      beneficiaire.derniereModification = new Date();
      beneficiaire.modifiePar = req.user.id;
      
      await beneficiaire.save();
      
      res.status(201).json({
        success: true,
        data: beneficiaire.documents[beneficiaire.documents.length - 1]
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        message: "Erreur lors de l'ajout du document",
        error: error.message
      });
    }
  }
  
  // Mettre à jour un document
  static async updateDocument(req, res) {
    try {
      const beneficiaire = await Beneficiaire.findById(req.params.id);
      
      if (!beneficiaire) {
        return res.status(404).json({
          success: false,
          message: "Bénéficiaire non trouvé"
        });
      }
      
      // Vérifier les droits d'accès
      if (req.user.role === 'consultant' && beneficiaire.consultant.toString() !== req.user.id) {
        return res.status(403).json({
          success: false,
          message: "Accès non autorisé à ce bénéficiaire"
        });
      }
      
      // Trouver l'index du document
      const documentIndex = beneficiaire.documents.findIndex(
        doc => doc._id.toString() === req.params.documentId
      );
      
      if (documentIndex === -1) {
        return res.status(404).json({
          success: false,
          message: "Document non trouvé"
        });
      }
      
      // Mettre à jour le document
      beneficiaire.documents[documentIndex] = {
        ...beneficiaire.documents[documentIndex].toObject(),
        ...req.body
      };
      
      // Mettre à jour les métadonnées
      beneficiaire.derniereModification = new Date();
      beneficiaire.modifiePar = req.user.id;
      
      await beneficiaire.save();
      
      res.status(200).json({
        success: true,
        data: beneficiaire.documents[documentIndex]
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        message: "Erreur lors de la mise à jour du document",
        error: error.message
      });
    }
  }
  
  // Supprimer un document
  static async deleteDocument(req, res) {
    try {
      const beneficiaire = await Beneficiaire.findById(req.params.id);
      
      if (!beneficiaire) {
        return res.status(404).json({
          success: false,
          message: "Bénéficiaire non trouvé"
        });
      }
      
      // Vérifier les droits d'accès
      if (req.user.role === 'consultant' && beneficiaire.consultant.toString() !== req.user.id) {
        return res.status(403).json({
          success: false,
          message: "Accès non autorisé à ce bénéficiaire"
        });
      }
      
      // Trouver l'index du document
      const documentIndex = beneficiaire.documents.findIndex(
        doc => doc._id.toString() === req.params.documentId
      );
      
      if (documentIndex === -1) {
        return res.status(404).json({
          success: false,
          message: "Document non trouvé"
        });
      }
      
      // Supprimer le document
      beneficiaire.documents.splice(documentIndex, 1);
      
      // Mettre à jour les métadonnées
      beneficiaire.derniereModification = new Date();
      beneficiaire.modifiePar = req.user.id;
      
      await beneficiaire.save();
      
      res.status(200).json({
        success: true,
        data: {}
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: "Erreur lors de la suppression du document",
        error: error.message
      });
    }
  }
  
  // Mettre à jour le projet professionnel d'un bénéficiaire
  static async updateProjetProfessionnel(req, res) {
    try {
      const beneficiaire = await Beneficiaire.findById(req.params.id);
      
      if (!beneficiaire) {
        return res.status(404).json({
          success: false,
          message: "Bénéficiaire non trouvé"
        });
      }
      
      // Vérifier les droits d'accès
      if (req.user.role === 'consultant' && beneficiaire.consultant.toString() !== req.user.id) {
        return res.status(403).json({
          success: false,
          message: "Accès non autorisé à ce bénéficiaire"
        });
      }
      
      // Mettre à jour le projet professionnel
      beneficiaire.projetProfessionnel = {
        ...beneficiaire.projetProfessionnel,
        ...req.body
      };
      
      // Mettre à jour les métadonnées
      beneficiaire.derniereModification = new Date();
      beneficiaire.modifiePar = req.user.id;
      
      await beneficiaire.save();
      
      res.status(200).json({
        success: true,
        data: beneficiaire.projetProfessionnel
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        message: "Erreur lors de la mise à jour du projet professionnel",
        error: error.message
      });
    }
  }
  
  // Récupérer les statistiques des bénéficiaires
  static async getBeneficiaireStats(req, res) {
    try {
      // Construire les filtres en fonction du rôle de l'utilisateur
      const filter = {};
      if (req.user.role === 'consultant') {
        filter.consultant = req.user.id;
      }
      
      // Statistiques par statut
      const statsByStatus = await Beneficiaire.aggregate([
        { $match: filter },
        { $group: { _id: "$statutBilan", count: { $sum: 1 } } }
      ]);
      
      // Statistiques par phase
      const statsByPhase = await Beneficiaire.aggregate([
        { $match: filter },
        { $group: { _id: "$phaseActuelle", count: { $sum: 1 } } }
      ]);
      
      // Statistiques par type de financement
      const statsByFinancement = await Beneficiaire.aggregate([
        { $match: filter },
        { $group: { _id: "$typeFinancement", count: { $sum: 1 } } }
      ]);
      
      // Statistiques par mois (bilans démarrés)
      const statsByMonth = await Beneficiaire.aggregate([
        { $match: filter },
        {
          $group: {
            _id: {
              year: { $year: "$dateDebutBilan" },
              month: { $month: "$dateDebutBilan" }
            },
            count: { $sum: 1 }
          }
        },
        { $sort: { "_id.year": -1, "_id.month": -1 } },
        { $limit: 12 }
      ]);
      
      res.status(200).json({
        success: true,
        data: {
          statsByStatus,
          statsByPhase,
          statsByFinancement,
          statsByMonth
        }
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: "Erreur lors de la récupération des statistiques",
        error: error.message
      });
    }
  }
  
  // Rechercher des bénéficiaires
  static async searchBeneficiaires(req, res) {
    try {
      const { q, page = 1, limit = 10 } = req.query;
      const skip = (page - 1) * limit;
      
      // Construire la requête de recherche
      const searchQuery = {
        $or: [
          { nom: { $regex: q, $options: 'i' } },
          { prenom: { $regex: q, $options: 'i' } },
          { email: { $regex: q, $options: 'i' } }
        ]
      };
      
      // Si l'utilisateur est un consultant, ne montrer que ses bénéficiaires
      if (req.user.role === 'consultant') {
        searchQuery.consultant = req.user.id;
      }
      
      // Exécuter la recherche
      const beneficiaires = await Beneficiaire.find(searchQuery)
        .skip(skip)
        .limit(parseInt(limit))
        .sort({ derniereModification: -1 });
      
      // Comptage total pour la pagination
      const total = await Beneficiaire.countDocuments(searchQuery);
      
      res.status(200).json({
        success: true,
        count: beneficiaires.length,
        total,
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          totalPages: Math.ceil(total / limit)
        },
        data: beneficiaires
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: "Erreur lors de la recherche des bénéficiaires",
        error: error.message
      });
    }
  }
}

module.exports = BeneficiaireController;
