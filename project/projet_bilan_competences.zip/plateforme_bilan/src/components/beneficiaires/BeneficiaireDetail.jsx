import React, { useState, useEffect } from 'react';
import { 
  Container, 
  Typography, 
  Box, 
  Grid, 
  Paper, 
  Button, 
  TextField, 
  Tabs,
  Tab,
  Divider,
  Card,
  CardContent,
  CardHeader,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  ListItemSecondary,
  Chip,
  Avatar,
  IconButton
} from '@mui/material';
import {
  Person as PersonIcon,
  Business as BusinessIcon,
  Event as EventIcon,
  Description as DescriptionIcon,
  Assessment as AssessmentIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Add as AddIcon,
  CalendarToday as CalendarIcon,
  Email as EmailIcon,
  Phone as PhoneIcon,
  LocationOn as LocationIcon
} from '@mui/icons-material';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { getBeneficiaireById } from '../../services/beneficiaireService';
import Loader from '../common/Loader';
import ErrorAlert from '../common/ErrorAlert';
import ConfirmDialog from '../common/ConfirmDialog';
import RendezVousList from './RendezVousList';
import EvaluationsList from './EvaluationsList';
import DocumentsList from './DocumentsList';
import ProjetProfessionnel from './ProjetProfessionnel';

// Composant TabPanel pour gérer les onglets
function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`beneficiaire-tabpanel-${index}`}
      aria-labelledby={`beneficiaire-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          {children}
        </Box>
      )}
    </div>
  );
}

const BeneficiaireDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  
  // États
  const [beneficiaire, setBeneficiaire] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [tabValue, setTabValue] = useState(0);
  const [confirmDialog, setConfirmDialog] = useState({
    open: false,
    title: '',
    message: '',
    onConfirm: null
  });

  // Charger les détails du bénéficiaire
  useEffect(() => {
    const loadBeneficiaire = async () => {
      try {
        setLoading(true);
        setError(null);
        const data = await getBeneficiaireById(id);
        setBeneficiaire(data);
        setLoading(false);
      } catch (err) {
        setError(err.message || 'Une erreur est survenue lors du chargement des détails du bénéficiaire');
        setLoading(false);
      }
    };

    loadBeneficiaire();
  }, [id]);

  // Gestionnaires d'événements
  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  const handleEdit = () => {
    navigate(`/beneficiaires/${id}/modifier`);
  };

  const handlePlanifierRdv = () => {
    navigate(`/beneficiaires/${id}/rendez-vous/nouveau`);
  };

  // Vérifier si l'utilisateur a les droits d'édition
  const canEdit = user.role === 'admin' || 
    (user.role === 'consultant' && beneficiaire?.consultant?.id === user.id);

  // Rendu des statuts avec des puces colorées
  const renderStatut = (statut) => {
    let color;
    switch (statut) {
      case 'En cours':
        color = 'primary';
        break;
      case 'Terminé':
        color = 'success';
        break;
      case 'Annulé':
        color = 'error';
        break;
      case 'En attente':
        color = 'warning';
        break;
      default:
        color = 'default';
    }
    return <Chip label={statut} color={color} />;
  };

  // Rendu des phases avec des puces colorées
  const renderPhase = (phase) => {
    let color;
    switch (phase) {
      case 'Préliminaire':
        color = 'info';
        break;
      case 'Investigation':
        color = 'warning';
        break;
      case 'Conclusions':
        color = 'success';
        break;
      case 'Non démarré':
        color = 'default';
        break;
      default:
        color = 'default';
    }
    return <Chip label={phase} color={color} />;
  };

  if (loading) return <Loader />;
  if (error) return <ErrorAlert message={error} />;
  if (!beneficiaire) return <Typography>Bénéficiaire non trouvé</Typography>;

  return (
    <Container maxWidth="lg">
      <Box sx={{ my: 4 }}>
        <Grid container spacing={2} alignItems="center" sx={{ mb: 3 }}>
          <Grid item xs={12} md={8}>
            <Typography variant="h4" component="h1" gutterBottom>
              {beneficiaire.prenom} {beneficiaire.nom}
            </Typography>
          </Grid>
          <Grid item xs={12} md={4} sx={{ textAlign: 'right' }}>
            {canEdit && (
              <>
                <Button
                  variant="outlined"
                  color="primary"
                  startIcon={<EditIcon />}
                  onClick={handleEdit}
                  sx={{ mr: 1 }}
                >
                  Modifier
                </Button>
                <Button
                  variant="contained"
                  color="primary"
                  startIcon={<EventIcon />}
                  onClick={handlePlanifierRdv}
                >
                  Planifier RDV
                </Button>
              </>
            )}
          </Grid>
        </Grid>

        <Grid container spacing={3}>
          <Grid item xs={12} md={4}>
            <Card>
              <CardHeader 
                title="Informations générales" 
                avatar={<Avatar><PersonIcon /></Avatar>}
              />
              <CardContent>
                <List>
                  <ListItem>
                    <ListItemIcon>
                      <EmailIcon />
                    </ListItemIcon>
                    <ListItemText primary="Email" secondary={beneficiaire.email} />
                  </ListItem>
                  <ListItem>
                    <ListItemIcon>
                      <PhoneIcon />
                    </ListItemIcon>
                    <ListItemText primary="Téléphone" secondary={beneficiaire.telephone || 'Non renseigné'} />
                  </ListItem>
                  <ListItem>
                    <ListItemIcon>
                      <LocationIcon />
                    </ListItemIcon>
                    <ListItemText 
                      primary="Adresse" 
                      secondary={
                        beneficiaire.adresse?.rue 
                          ? `${beneficiaire.adresse.rue}, ${beneficiaire.adresse.codePostal} ${beneficiaire.adresse.ville}`
                          : 'Non renseignée'
                      } 
                    />
                  </ListItem>
                  {beneficiaire.dateNaissance && (
                    <ListItem>
                      <ListItemIcon>
                        <CalendarIcon />
                      </ListItemIcon>
                      <ListItemText 
                        primary="Date de naissance" 
                        secondary={new Date(beneficiaire.dateNaissance).toLocaleDateString()} 
                      />
                    </ListItem>
                  )}
                </List>
              </CardContent>
            </Card>

            <Card sx={{ mt: 2 }}>
              <CardHeader 
                title="Situation professionnelle" 
                avatar={<Avatar><BusinessIcon /></Avatar>}
              />
              <CardContent>
                <List>
                  <ListItem>
                    <ListItemText 
                      primary="Situation" 
                      secondary={beneficiaire.situationProfessionnelle} 
                    />
                  </ListItem>
                  {beneficiaire.entrepriseActuelle && (
                    <ListItem>
                      <ListItemText 
                        primary="Entreprise actuelle" 
                        secondary={beneficiaire.entrepriseActuelle} 
                      />
                    </ListItem>
                  )}
                  {beneficiaire.posteActuel && (
                    <ListItem>
                      <ListItemText 
                        primary="Poste actuel" 
                        secondary={beneficiaire.posteActuel} 
                      />
                    </ListItem>
                  )}
                  {beneficiaire.secteurActivite && (
                    <ListItem>
                      <ListItemText 
                        primary="Secteur d'activité" 
                        secondary={beneficiaire.secteurActivite} 
                      />
                    </ListItem>
                  )}
                </List>
              </CardContent>
            </Card>

            <Card sx={{ mt: 2 }}>
              <CardHeader 
                title="Informations du bilan" 
                avatar={<Avatar><AssessmentIcon /></Avatar>}
              />
              <CardContent>
                <Box sx={{ mb: 2 }}>
                  <Typography variant="subtitle2" gutterBottom>
                    Statut
                  </Typography>
                  {renderStatut(beneficiaire.statutBilan)}
                </Box>
                <Box sx={{ mb: 2 }}>
                  <Typography variant="subtitle2" gutterBottom>
                    Phase actuelle
                  </Typography>
                  {renderPhase(beneficiaire.phaseActuelle)}
                </Box>
                <Box sx={{ mb: 2 }}>
                  <Typography variant="subtitle2" gutterBottom>
                    Consultant
                  </Typography>
                  <Typography>
                    {beneficiaire.consultant?.prenom} {beneficiaire.consultant?.nom}
                  </Typography>
                </Box>
                <Box sx={{ mb: 2 }}>
                  <Typography variant="subtitle2" gutterBottom>
                    Financement
                  </Typography>
                  <Typography>
                    {beneficiaire.typeFinancement}
                    {beneficiaire.statutFinancement && (
                      <Chip 
                        label={beneficiaire.statutFinancement} 
                        size="small" 
                        color={beneficiaire.statutFinancement === 'Validé' ? 'success' : 'warning'}
                        sx={{ ml: 1 }}
                      />
                    )}
                  </Typography>
                </Box>
                {beneficiaire.dateDebutBilan && (
                  <Box sx={{ mb: 2 }}>
                    <Typography variant="subtitle2" gutterBottom>
                      Date de début
                    </Typography>
                    <Typography>
                      {new Date(beneficiaire.dateDebutBilan).toLocaleDateString()}
                    </Typography>
                  </Box>
                )}
                {beneficiaire.dateFinBilan && (
                  <Box>
                    <Typography variant="subtitle2" gutterBottom>
                      Date de fin
                    </Typography>
                    <Typography>
                      {new Date(beneficiaire.dateFinBilan).toLocaleDateString()}
                    </Typography>
                  </Box>
                )}
              </CardContent>
            </Card>
          </Grid>

          <Grid item xs={12} md={8}>
            <Paper sx={{ width: '100%' }}>
              <Tabs
                value={tabValue}
                onChange={handleTabChange}
                indicatorColor="primary"
                textColor="primary"
                variant="fullWidth"
              >
                <Tab label="Rendez-vous" />
                <Tab label="Évaluations" />
                <Tab label="Documents" />
                <Tab label="Projet professionnel" />
              </Tabs>

              <TabPanel value={tabValue} index={0}>
                <RendezVousList 
                  beneficiaireId={id} 
                  rendezVous={beneficiaire.rendezVous} 
                  canEdit={canEdit} 
                />
              </TabPanel>

              <TabPanel value={tabValue} index={1}>
                <EvaluationsList 
                  beneficiaireId={id} 
                  evaluations={beneficiaire.evaluations} 
                  canEdit={canEdit} 
                />
              </TabPanel>

              <TabPanel value={tabValue} index={2}>
                <DocumentsList 
                  beneficiaireId={id} 
                  documents={beneficiaire.documents} 
                  canEdit={canEdit} 
                />
              </TabPanel>

              <TabPanel value={tabValue} index={3}>
                <ProjetProfessionnel 
                  beneficiaireId={id} 
                  projetProfessionnel={beneficiaire.projetProfessionnel} 
                  canEdit={canEdit} 
                />
              </TabPanel>
            </Paper>
          </Grid>
        </Grid>
      </Box>

      <ConfirmDialog
        open={confirmDialog.open}
        title={confirmDialog.title}
        message={confirmDialog.message}
        onConfirm={confirmDialog.onConfirm}
        onCancel={() => setConfirmDialog({ ...confirmDialog, open: false })}
      />
    </Container>
  );
};

export default BeneficiaireDetail;
