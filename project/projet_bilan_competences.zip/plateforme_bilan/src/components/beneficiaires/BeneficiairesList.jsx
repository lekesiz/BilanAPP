import React, { useState, useEffect } from 'react';
import { 
  Container, 
  Typography, 
  Box, 
  Grid, 
  Paper, 
  Button, 
  TextField, 
  Table, 
  TableBody, 
  TableCell, 
  TableContainer, 
  TableHead, 
  TableRow,
  TablePagination,
  IconButton,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  FormControl,
  InputLabel,
  Select,
  MenuItem
} from '@mui/material';
import { 
  Add as AddIcon, 
  Search as SearchIcon, 
  Edit as EditIcon, 
  Delete as DeleteIcon, 
  Visibility as VisibilityIcon,
  FilterList as FilterListIcon
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { getBeneficiaires, deleteBeneficiaire } from '../../services/beneficiaireService';
import BeneficiaireFilters from './BeneficiaireFilters';
import ConfirmDialog from '../common/ConfirmDialog';
import Loader from '../common/Loader';
import ErrorAlert from '../common/ErrorAlert';

const BeneficiairesList = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  
  // États
  const [beneficiaires, setBeneficiaires] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [totalCount, setTotalCount] = useState(0);
  const [searchQuery, setSearchQuery] = useState('');
  const [filters, setFilters] = useState({
    statut: '',
    phase: '',
    consultant: user.role === 'consultant' ? user.id : ''
  });
  const [showFilters, setShowFilters] = useState(false);
  const [confirmDialog, setConfirmDialog] = useState({
    open: false,
    title: '',
    message: '',
    onConfirm: null
  });

  // Charger les bénéficiaires
  const loadBeneficiaires = async () => {
    try {
      setLoading(true);
      setError(null);
      
      // Construire les paramètres de requête
      const params = {
        page: page + 1,
        limit: rowsPerPage,
        ...filters
      };
      
      if (searchQuery) {
        params.q = searchQuery;
      }
      
      const response = await getBeneficiaires(params);
      setBeneficiaires(response.data);
      setTotalCount(response.total);
      setLoading(false);
    } catch (err) {
      setError(err.message || 'Une erreur est survenue lors du chargement des bénéficiaires');
      setLoading(false);
    }
  };

  // Effet pour charger les bénéficiaires
  useEffect(() => {
    loadBeneficiaires();
  }, [page, rowsPerPage, filters]);

  // Gestionnaires d'événements
  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleSearch = (e) => {
    e.preventDefault();
    setPage(0);
    loadBeneficiaires();
  };

  const handleFilterChange = (newFilters) => {
    setFilters(newFilters);
    setPage(0);
  };

  const handleAddBeneficiaire = () => {
    navigate('/beneficiaires/nouveau');
  };

  const handleViewBeneficiaire = (id) => {
    navigate(`/beneficiaires/${id}`);
  };

  const handleEditBeneficiaire = (id) => {
    navigate(`/beneficiaires/${id}/modifier`);
  };

  const handleDeleteBeneficiaire = (id, nom) => {
    setConfirmDialog({
      open: true,
      title: 'Supprimer le bénéficiaire',
      message: `Êtes-vous sûr de vouloir supprimer le bénéficiaire ${nom} ? Cette action est irréversible.`,
      onConfirm: async () => {
        try {
          await deleteBeneficiaire(id);
          loadBeneficiaires();
          setConfirmDialog({ ...confirmDialog, open: false });
        } catch (err) {
          setError(err.message || 'Une erreur est survenue lors de la suppression');
          setConfirmDialog({ ...confirmDialog, open: false });
        }
      }
    });
  };

  // Rendu des statuts avec des puces colorées
  const renderStatut = (statut) => {
    let color;
    switch (statut) {
      case 'En cours':
        color = 'primary';
        break;
      case 'Terminé':
        color = 'success';
        break;
      case 'Annulé':
        color = 'error';
        break;
      case 'En attente':
        color = 'warning';
        break;
      default:
        color = 'default';
    }
    return <Chip label={statut} color={color} size="small" />;
  };

  // Rendu des phases avec des puces colorées
  const renderPhase = (phase) => {
    let color;
    switch (phase) {
      case 'Préliminaire':
        color = 'info';
        break;
      case 'Investigation':
        color = 'warning';
        break;
      case 'Conclusions':
        color = 'success';
        break;
      case 'Non démarré':
        color = 'default';
        break;
      default:
        color = 'default';
    }
    return <Chip label={phase} color={color} size="small" />;
  };

  return (
    <Container maxWidth="lg">
      <Box sx={{ my: 4 }}>
        <Grid container spacing={2} alignItems="center" sx={{ mb: 3 }}>
          <Grid item xs={12} md={6}>
            <Typography variant="h4" component="h1" gutterBottom>
              Bénéficiaires
            </Typography>
          </Grid>
          <Grid item xs={12} md={6} sx={{ textAlign: 'right' }}>
            {user.role !== 'beneficiaire' && (
              <Button
                variant="contained"
                color="primary"
                startIcon={<AddIcon />}
                onClick={handleAddBeneficiaire}
              >
                Ajouter un bénéficiaire
              </Button>
            )}
          </Grid>
        </Grid>

        <Paper sx={{ p: 2, mb: 3 }}>
          <Grid container spacing={2} alignItems="center">
            <Grid item xs={12} md={6}>
              <form onSubmit={handleSearch}>
                <TextField
                  fullWidth
                  placeholder="Rechercher un bénéficiaire..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  InputProps={{
                    endAdornment: (
                      <IconButton type="submit">
                        <SearchIcon />
                      </IconButton>
                    )
                  }}
                />
              </form>
            </Grid>
            <Grid item xs={12} md={6} sx={{ textAlign: 'right' }}>
              <Button
                startIcon={<FilterListIcon />}
                onClick={() => setShowFilters(!showFilters)}
              >
                Filtres
              </Button>
            </Grid>
            {showFilters && (
              <Grid item xs={12}>
                <BeneficiaireFilters
                  filters={filters}
                  onFilterChange={handleFilterChange}
                />
              </Grid>
            )}
          </Grid>
        </Paper>

        {error && <ErrorAlert message={error} />}

        {loading ? (
          <Loader />
        ) : (
          <>
            <TableContainer component={Paper}>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>Nom</TableCell>
                    <TableCell>Email</TableCell>
                    <TableCell>Statut</TableCell>
                    <TableCell>Phase</TableCell>
                    <TableCell>Consultant</TableCell>
                    <TableCell>Début</TableCell>
                    <TableCell align="right">Actions</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {beneficiaires.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={7} align="center">
                        Aucun bénéficiaire trouvé
                      </TableCell>
                    </TableRow>
                  ) : (
                    beneficiaires.map((beneficiaire) => (
                      <TableRow key={beneficiaire.id}>
                        <TableCell>
                          {beneficiaire.prenom} {beneficiaire.nom}
                        </TableCell>
                        <TableCell>{beneficiaire.email}</TableCell>
                        <TableCell>{renderStatut(beneficiaire.statutBilan)}</TableCell>
                        <TableCell>{renderPhase(beneficiaire.phaseActuelle)}</TableCell>
                        <TableCell>{beneficiaire.consultant?.nom || '-'}</TableCell>
                        <TableCell>
                          {beneficiaire.dateDebutBilan
                            ? new Date(beneficiaire.dateDebutBilan).toLocaleDateString()
                            : '-'}
                        </TableCell>
                        <TableCell align="right">
                          <IconButton
                            color="primary"
                            onClick={() => handleViewBeneficiaire(beneficiaire.id)}
                          >
                            <VisibilityIcon />
                          </IconButton>
                          {(user.role === 'admin' || 
                            (user.role === 'consultant' && 
                             beneficiaire.consultant?.id === user.id)) && (
                            <>
                              <IconButton
                                color="secondary"
                                onClick={() => handleEditBeneficiaire(beneficiaire.id)}
                              >
                                <EditIcon />
                              </IconButton>
                              {user.role === 'admin' && (
                                <IconButton
                                  color="error"
                                  onClick={() => 
                                    handleDeleteBeneficiaire(
                                      beneficiaire.id, 
                                      `${beneficiaire.prenom} ${beneficiaire.nom}`
                                    )
                                  }
                                >
                                  <DeleteIcon />
                                </IconButton>
                              )}
                            </>
                          )}
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </TableContainer>
            
            <TablePagination
              component="div"
              count={totalCount}
              page={page}
              onPageChange={handleChangePage}
              rowsPerPage={rowsPerPage}
              onRowsPerPageChange={handleChangeRowsPerPage}
              rowsPerPageOptions={[5, 10, 25, 50]}
              labelRowsPerPage="Lignes par page :"
              labelDisplayedRows={({ from, to, count }) => 
                `${from}-${to} sur ${count !== -1 ? count : `plus de ${to}`}`
              }
            />
          </>
        )}
      </Box>

      <ConfirmDialog
        open={confirmDialog.open}
        title={confirmDialog.title}
        message={confirmDialog.message}
        onConfirm={confirmDialog.onConfirm}
        onCancel={() => setConfirmDialog({ ...confirmDialog, open: false })}
      />
    </Container>
  );
};

export default BeneficiairesList;
