import React, { useState, useEffect } from 'react';
import { 
  Container, 
  Typography, 
  Box, 
  Grid, 
  Paper, 
  Button, 
  TextField, 
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Divider,
  Card,
  CardContent,
  CardHeader,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Alert,
  Snackbar,
  IconButton,
  Tooltip
} from '@mui/material';
import { 
  Google as GoogleIcon,
  CalendarToday as CalendarIcon,
  VideoCall as VideoCallIcon,
  Description as DescriptionIcon,
  CloudUpload as CloudUploadIcon,
  Link as LinkIcon,
  Add as AddIcon,
  Delete as DeleteIcon
} from '@mui/icons-material';
import { useAuth } from '../../contexts/AuthContext';
import googleWorkspaceService from '../../services/googleWorkspaceService';
import Loader from '../common/Loader';
import ErrorAlert from '../common/ErrorAlert';

const GoogleWorkspaceIntegration = () => {
  const { user, updateUser } = useAuth();
  
  // États
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [googleConnected, setGoogleConnected] = useState(false);
  const [googleUserInfo, setGoogleUserInfo] = useState(null);
  const [calendarEvents, setCalendarEvents] = useState([]);
  const [showNewEventDialog, setShowNewEventDialog] = useState(false);
  const [newEventData, setNewEventData] = useState({
    title: '',
    description: '',
    startDateTime: '',
    endDateTime: '',
    attendees: '',
    addConference: true
  });
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success'
  });

  // Vérifier si l'utilisateur est connecté à Google
  useEffect(() => {
    if (user && user.googleTokens) {
      setGoogleConnected(true);
      loadGoogleUserInfo();
      loadCalendarEvents();
    }
  }, [user]);

  // Charger les informations de l'utilisateur Google
  const loadGoogleUserInfo = async () => {
    try {
      setLoading(true);
      const userInfo = await googleWorkspaceService.getUserInfo(user.googleTokens);
      setGoogleUserInfo(userInfo);
      setLoading(false);
    } catch (err) {
      setError('Erreur lors du chargement des informations Google: ' + err.message);
      setLoading(false);
    }
  };

  // Charger les événements du calendrier
  const loadCalendarEvents = async () => {
    try {
      setLoading(true);
      
      // Définir la plage de dates (aujourd'hui + 7 jours)
      const now = new Date();
      const nextWeek = new Date();
      nextWeek.setDate(now.getDate() + 7);
      
      const events = await googleWorkspaceService.getCalendarEvents(
        user.googleTokens,
        now.toISOString(),
        nextWeek.toISOString()
      );
      
      setCalendarEvents(events);
      setLoading(false);
    } catch (err) {
      setError('Erreur lors du chargement des événements du calendrier: ' + err.message);
      setLoading(false);
    }
  };

  // Gérer la connexion à Google
  const handleGoogleConnect = () => {
    const authUrl = googleWorkspaceService.generateAuthUrl();
    window.location.href = authUrl;
  };

  // Gérer la déconnexion de Google
  const handleGoogleDisconnect = async () => {
    try {
      // Mettre à jour l'utilisateur sans les tokens Google
      const updatedUser = { ...user };
      delete updatedUser.googleTokens;
      
      await updateUser(updatedUser);
      
      setGoogleConnected(false);
      setGoogleUserInfo(null);
      setCalendarEvents([]);
      
      setSnackbar({
        open: true,
        message: 'Déconnecté de Google Workspace avec succès',
        severity: 'success'
      });
    } catch (err) {
      setError('Erreur lors de la déconnexion de Google: ' + err.message);
    }
  };

  // Gérer l'ouverture du dialogue de nouvel événement
  const handleOpenNewEventDialog = () => {
    // Initialiser avec l'heure actuelle + 1 heure
    const now = new Date();
    const oneHourLater = new Date(now);
    oneHourLater.setHours(oneHourLater.getHours() + 1);
    
    setNewEventData({
      title: '',
      description: '',
      startDateTime: now.toISOString().slice(0, 16),
      endDateTime: oneHourLater.toISOString().slice(0, 16),
      attendees: '',
      addConference: true
    });
    
    setShowNewEventDialog(true);
  };

  // Gérer la fermeture du dialogue de nouvel événement
  const handleCloseNewEventDialog = () => {
    setShowNewEventDialog(false);
  };

  // Gérer le changement des champs du nouvel événement
  const handleNewEventChange = (e) => {
    const { name, value, checked, type } = e.target;
    setNewEventData({
      ...newEventData,
      [name]: type === 'checkbox' ? checked : value
    });
  };

  // Créer un nouvel événement
  const handleCreateEvent = async () => {
    try {
      setLoading(true);
      
      // Formater les données de l'événement
      const eventData = {
        title: newEventData.title,
        description: newEventData.description,
        startDateTime: new Date(newEventData.startDateTime).toISOString(),
        endDateTime: new Date(newEventData.endDateTime).toISOString(),
        attendees: newEventData.attendees.split(',').map(email => email.trim()),
        addConference: newEventData.addConference
      };
      
      // Créer l'événement
      const createdEvent = await googleWorkspaceService.createCalendarEvent(
        user.googleTokens,
        eventData
      );
      
      // Recharger les événements
      await loadCalendarEvents();
      
      setShowNewEventDialog(false);
      setSnackbar({
        open: true,
        message: 'Événement créé avec succès',
        severity: 'success'
      });
      
      setLoading(false);
    } catch (err) {
      setError('Erreur lors de la création de l\'événement: ' + err.message);
      setLoading(false);
    }
  };

  // Créer un lien de visioconférence
  const handleCreateMeetLink = async () => {
    try {
      setLoading(true);
      
      // Créer un événement avec une conférence
      const now = new Date();
      const oneHourLater = new Date(now);
      oneHourLater.setHours(oneHourLater.getHours() + 1);
      
      const meetingDetails = {
        title: 'Entretien de bilan de compétences',
        description: 'Visioconférence pour le bilan de compétences',
        startDateTime: now.toISOString(),
        endDateTime: oneHourLater.toISOString(),
        attendees: [user.email],
        addConference: true
      };
      
      const result = await googleWorkspaceService.createMeetLink(
        user.googleTokens,
        meetingDetails
      );
      
      // Copier le lien dans le presse-papier
      navigator.clipboard.writeText(result.meetLink);
      
      // Recharger les événements
      await loadCalendarEvents();
      
      setSnackbar({
        open: true,
        message: 'Lien de visioconférence créé et copié dans le presse-papier',
        severity: 'success'
      });
      
      setLoading(false);
    } catch (err) {
      setError('Erreur lors de la création du lien de visioconférence: ' + err.message);
      setLoading(false);
    }
  };

  // Formater la date pour l'affichage
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleString('fr-FR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <Container maxWidth="lg">
      <Box sx={{ my: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          Intégration Google Workspace
        </Typography>
        
        {error && <ErrorAlert message={error} sx={{ mb: 3 }} />}
        
        <Paper sx={{ p: 3, mb: 3 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 2 }}>
            <Typography variant="h6">
              Statut de connexion
            </Typography>
            {googleConnected ? (
              <Button
                variant="outlined"
                color="secondary"
                onClick={handleGoogleDisconnect}
              >
                Déconnecter Google Workspace
              </Button>
            ) : (
              <Button
                variant="contained"
                color="primary"
                startIcon={<GoogleIcon />}
                onClick={handleGoogleConnect}
              >
                Connecter Google Workspace
              </Button>
            )}
          </Box>
          
          {googleConnected && googleUserInfo && (
            <Box sx={{ mt: 2 }}>
              <Typography variant="subtitle1">
                Connecté en tant que:
              </Typography>
              <Box sx={{ display: 'flex', alignItems: 'center', mt: 1 }}>
                {googleUserInfo.picture && (
                  <Box
                    component="img"
                    src={googleUserInfo.picture}
                    alt={googleUserInfo.name}
                    sx={{ width: 40, height: 40, borderRadius: '50%', mr: 2 }}
                  />
                )}
                <Box>
                  <Typography variant="body1">
                    {googleUserInfo.name}
                  </Typography>
                  <Typography variant="body2" color="textSecondary">
                    {googleUserInfo.email}
                  </Typography>
                </Box>
              </Box>
            </Box>
          )}
        </Paper>
        
        {googleConnected && (
          <>
            <Grid container spacing={3}>
              <Grid item xs={12} md={6}>
                <Card>
                  <CardHeader 
                    title="Google Calendar" 
                    action={
                      <Button
                        variant="contained"
                        color="primary"
                        startIcon={<AddIcon />}
                        onClick={handleOpenNewEventDialog}
                      >
                        Nouvel événement
                      </Button>
                    }
                  />
                  <CardContent>
                    <Typography variant="subtitle1" gutterBottom>
                      Prochains rendez-vous (7 jours)
                    </Typography>
                    
                    {loading ? (
                      <Loader size={30} />
                    ) : calendarEvents.length === 0 ? (
                      <Typography variant="body2" color="textSecondary">
                        Aucun événement à venir
                      </Typography>
                    ) : (
                      <List>
                        {calendarEvents.map((event) => (
                          <ListItem key={event.id} divider>
                            <ListItemIcon>
                              <CalendarIcon />
                            </ListItemIcon>
                            <ListItemText
                              primary={event.summary}
                              secondary={
                                <>
                                  {formatDate(event.start.dateTime || event.start.date)}
                                  {event.conferenceData && (
                                    <Chip
                                      icon={<VideoCallIcon />}
                                      label="Meet"
                                      size="small"
                                      color="primary"
                                      sx={{ ml: 1 }}
                                    />
                                  )}
                                </>
                              }
                            />
                          </ListItem>
                        ))}
                      </List>
                    )}
                  </CardContent>
                </Card>
              </Grid>
              
              <Grid item xs={12} md={6}>
                <Card>
                  <CardHeader 
                    title="Google Meet" 
                    action={
                      <Button
                        variant="contained"
                        color="primary"
                        startIcon={<VideoCallIcon />}
                        onClick={handleCreateMeetLink}
                      >
                        Créer un lien
                      </Button>
                    }
                  />
                  <CardContent>
                    <Typography variant="body1" paragraph>
                      Créez rapidement un lien de visioconférence Google Meet pour vos entretiens de bilan de compétences.
                    </Typography>
                    <Typography variant="body2" color="textSecondary">
                      Le lien sera automatiquement copié dans votre presse-papier et un événement sera créé dans votre calendrier.
                    </Typography>
                  </CardContent>
                </Card>
                
                <Card sx={{ mt: 3 }}>
                  <CardHeader title="Google Drive" />
                  <CardContent>
                    <Typography variant="body1" paragraph>
                      Les documents générés pour les bilans de compétences sont automatiquement stockés dans Google Drive.
                    </Typography>
                    <Typography variant="body2" color="textSecondary">
                      Un dossier est créé pour chaque bénéficiaire, contenant tous ses documents (convention, synthèse, etc.).
                    </Typography>
                  </CardContent>
                </Card>
              </Grid>
            </Grid>
          </>
        )}
      </Box>
      
      {/* Dialogue pour créer un nouvel événement */}
      <Dialog open={showNewEventDialog} onClose={handleCloseNewEventDialog} maxWidth="sm" fullWidth>
        <DialogTitle>Créer un nouvel événement</DialogTitle>
        <DialogContent>
          <Box sx={{ mt: 2 }}>
            <TextField
              fullWidth
              label="Titre"
              name="title"
              value={newEventData.title}
              onChange={handleNewEventChange}
              margin="normal"
              required
            />
            <TextField
              fullWidth
              label="Description"
              name="description"
              value={newEventData.description}
              onChange={handleNewEventChange}
              margin="normal"
              multiline
              rows={3}
            />
            <Grid container spacing={2}>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  label="Date et heure de début"
                  name="startDateTime"
                  type="datetime-local"
                  value={newEventData.startDateTime}
                  onChange={handleNewEventChange}
                  margin="normal"
                  required
                  InputLabelProps={{ shrink: true }}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  label="Date et heure de fin"
                  name="endDateTime"
                  type="datetime-local"
                  value={newEventData.endDateTime}
                  onChange={handleNewEventChange}
                  margin="normal"
                  required
                  InputLabelProps={{ shrink: true }}
                />
              </Grid>
            </Grid>
            <TextField
              fullWidth
              label="Participants (emails séparés par des virgules)"
              name="attendees"
              value={newEventData.attendees}
              onChange={handleNewEventChange}
              margin="normal"
              placeholder="exemple@email.com, autre@email.com"
            />
            <FormControl fullWidth margin="normal">
              <InputLabel id="add-conference-label">Ajouter une visioconférence</InputLabel>
              <Select
                labelId="add-conference-label"
                name="addConference"
                value={newEventData.addConference}
                onChange={handleNewEventChange}
                label="Ajouter une visioconférence"
              >
                <MenuItem value={true}>Oui</MenuItem>
                <MenuItem value={false}>Non</MenuItem>
              </Select>
            </FormControl>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseNewEventDialog}>Annuler</Button>
          <Button 
            onClick={handleCreateEvent} 
            variant="contained" 
            color="primary"
            disabled={!newEventData.title || !newEventData.startDateTime || !newEventData.endDateTime}
          >
            Créer
          </Button>
        </DialogActions>
      </Dialog>
      
      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
      >
        <Alert 
          onClose={() => setSnackbar({ ...snackbar, open: false })} 
          severity={snackbar.severity}
          sx={{ width: '100%' }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Container>
  );
};

export default GoogleWorkspaceIntegration;
