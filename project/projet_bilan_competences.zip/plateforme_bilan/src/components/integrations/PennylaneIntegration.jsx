import React, { useState, useEffect } from 'react';
import { 
  Container, 
  Typography, 
  Box, 
  Grid, 
  Paper, 
  Button, 
  TextField, 
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Divider,
  Card,
  CardContent,
  CardHeader,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Alert,
  Snackbar,
  IconButton,
  Tooltip,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TablePagination,
  Tab,
  Tabs
} from '@mui/material';
import { 
  Receipt as ReceiptIcon,
  Description as DescriptionIcon,
  Person as PersonIcon,
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Send as SendIcon,
  Payment as PaymentIcon,
  Euro as EuroIcon,
  CheckCircle as CheckCircleIcon
} from '@mui/icons-material';
import { useAuth } from '../../contexts/AuthContext';
import pennylaneService from '../../services/pennylaneService';
import Loader from '../common/Loader';
import ErrorAlert from '../common/ErrorAlert';
import ConfirmDialog from '../common/ConfirmDialog';

// Composant TabPanel pour gérer les onglets
function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`pennylane-tabpanel-${index}`}
      aria-labelledby={`pennylane-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          {children}
        </Box>
      )}
    </div>
  );
}

const PennylaneIntegration = () => {
  const { user } = useAuth();
  
  // États
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [tabValue, setTabValue] = useState(0);
  const [clients, setClients] = useState([]);
  const [invoices, setInvoices] = useState([]);
  const [quotes, setQuotes] = useState([]);
  const [products, setProducts] = useState([]);
  const [financialStats, setFinancialStats] = useState(null);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [showNewClientDialog, setShowNewClientDialog] = useState(false);
  const [showNewInvoiceDialog, setShowNewInvoiceDialog] = useState(false);
  const [showNewQuoteDialog, setShowNewQuoteDialog] = useState(false);
  const [showPaymentDialog, setShowPaymentDialog] = useState(false);
  const [showSendEmailDialog, setShowSendEmailDialog] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);
  const [newClientData, setNewClientData] = useState({
    prenom: '',
    nom: '',
    email: '',
    telephone: '',
    adresse: {
      rue: '',
      codePostal: '',
      ville: '',
      pays: 'FR'
    },
    entrepriseActuelle: '',
    siret: ''
  });
  const [newInvoiceData, setNewInvoiceData] = useState({
    clientId: '',
    date: new Date().toISOString().split('T')[0],
    dateEcheance: '',
    items: [
      {
        productId: '',
        description: '',
        quantite: 1,
        prixUnitaire: 0,
        tauxTVA: 20
      }
    ],
    conditionsPaiement: 'upon_receipt',
    notes: ''
  });
  const [newQuoteData, setNewQuoteData] = useState({
    clientId: '',
    date: new Date().toISOString().split('T')[0],
    dateExpiration: '',
    items: [
      {
        productId: '',
        description: '',
        quantite: 1,
        prixUnitaire: 0,
        tauxTVA: 20
      }
    ],
    notes: ''
  });
  const [paymentData, setPaymentData] = useState({
    date: new Date().toISOString().split('T')[0],
    montant: 0,
    methodePaiement: 'bank_transfer',
    notes: ''
  });
  const [emailData, setEmailData] = useState({
    destinataire: '',
    sujet: '',
    message: ''
  });
  const [confirmDialog, setConfirmDialog] = useState({
    open: false,
    title: '',
    message: '',
    onConfirm: null
  });
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success'
  });

  // Charger les données initiales
  useEffect(() => {
    loadClients();
    loadInvoices();
    loadQuotes();
    loadProducts();
    loadFinancialStats();
  }, []);

  // Charger les clients
  const loadClients = async () => {
    try {
      setLoading(true);
      // Simulation de chargement des clients (à remplacer par l'appel API réel)
      // const clientsData = await pennylaneService.getClients();
      const clientsData = [
        { id: 'client1', prenom: 'Jean', nom: 'Dupont', email: 'jean.dupont@example.com', entrepriseActuelle: 'Entreprise A' },
        { id: 'client2', prenom: 'Marie', nom: 'Martin', email: 'marie.martin@example.com', entrepriseActuelle: 'Entreprise B' },
        { id: 'client3', prenom: 'Pierre', nom: 'Durand', email: 'pierre.durand@example.com', entrepriseActuelle: 'Entreprise C' }
      ];
      setClients(clientsData);
      setLoading(false);
    } catch (err) {
      setError('Erreur lors du chargement des clients: ' + err.message);
      setLoading(false);
    }
  };

  // Charger les factures
  const loadInvoices = async () => {
    try {
      setLoading(true);
      // Simulation de chargement des factures (à remplacer par l'appel API réel)
      // const invoicesData = await pennylaneService.getInvoices();
      const invoicesData = [
        { id: 'inv1', numero: 'FACT-2025-001', clientId: 'client1', client: { prenom: 'Jean', nom: 'Dupont' }, date: '2025-04-01', montantHT: 1500, montantTTC: 1800, statut: 'paid' },
        { id: 'inv2', numero: 'FACT-2025-002', clientId: 'client2', client: { prenom: 'Marie', nom: 'Martin' }, date: '2025-04-05', montantHT: 2000, montantTTC: 2400, statut: 'pending' },
        { id: 'inv3', numero: 'FACT-2025-003', clientId: 'client3', client: { prenom: 'Pierre', nom: 'Durand' }, date: '2025-04-10', montantHT: 1800, montantTTC: 2160, statut: 'draft' }
      ];
      setInvoices(invoicesData);
      setLoading(false);
    } catch (err) {
      setError('Erreur lors du chargement des factures: ' + err.message);
      setLoading(false);
    }
  };

  // Charger les devis
  const loadQuotes = async () => {
    try {
      setLoading(true);
      // Simulation de chargement des devis (à remplacer par l'appel API réel)
      // const quotesData = await pennylaneService.getQuotes();
      const quotesData = [
        { id: 'quote1', numero: 'DEVIS-2025-001', clientId: 'client1', client: { prenom: 'Jean', nom: 'Dupont' }, date: '2025-03-25', montantHT: 1500, montantTTC: 1800, statut: 'accepted' },
        { id: 'quote2', numero: 'DEVIS-2025-002', clientId: 'client2', client: { prenom: 'Marie', nom: 'Martin' }, date: '2025-03-30', montantHT: 2000, montantTTC: 2400, statut: 'pending' }
      ];
      setQuotes(quotesData);
      setLoading(false);
    } catch (err) {
      setError('Erreur lors du chargement des devis: ' + err.message);
      setLoading(false);
    }
  };

  // Charger les produits
  const loadProducts = async () => {
    try {
      setLoading(true);
      // Simulation de chargement des produits (à remplacer par l'appel API réel)
      // const productsData = await pennylaneService.getProducts();
      const productsData = [
        { id: 'prod1', nom: 'Bilan de compétences standard', description: 'Bilan de compétences complet en 24h', prixUnitaire: 1500, tauxTVA: 20 },
        { id: 'prod2', nom: 'Bilan de compétences approfondi', description: 'Bilan de compétences approfondi en 30h', prixUnitaire: 2000, tauxTVA: 20 },
        { id: 'prod3', nom: 'Séance supplémentaire', description: 'Séance individuelle supplémentaire de 2h', prixUnitaire: 150, tauxTVA: 20 }
      ];
      setProducts(productsData);
      setLoading(false);
    } catch (err) {
      setError('Erreur lors du chargement des produits: ' + err.message);
      setLoading(false);
    }
  };

  // Charger les statistiques financières
  const loadFinancialStats = async () => {
    try {
      setLoading(true);
      // Simulation de chargement des statistiques (à remplacer par l'appel API réel)
      // const statsData = await pennylaneService.getFinancialStats();
      const statsData = {
        chiffreAffaires: {
          total: 15000,
          moisCourant: 4200,
          evolution: 12
        },
        factures: {
          total: 10,
          payees: 7,
          enAttente: 3
        },
        devis: {
          total: 5,
          acceptes: 3,
          enAttente: 2
        }
      };
      setFinancialStats(statsData);
      setLoading(false);
    } catch (err) {
      setError('Erreur lors du chargement des statistiques: ' + err.message);
      setLoading(false);
    }
  };

  // Gestionnaires d'événements
  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  // Gestionnaires pour les clients
  const handleOpenNewClientDialog = () => {
    setNewClientData({
      prenom: '',
      nom: '',
      email: '',
      telephone: '',
      adresse: {
        rue: '',
        codePostal: '',
        ville: '',
        pays: 'FR'
      },
      entrepriseActuelle: '',
      siret: ''
    });
    setShowNewClientDialog(true);
  };

  const handleCloseNewClientDialog = () => {
    setShowNewClientDialog(false);
  };

  const handleNewClientChange = (e) => {
    const { name, value } = e.target;
    
    // Gérer les champs imbriqués (adresse)
    if (name.includes('.')) {
      const [parent, child] = name.split('.');
      setNewClientData({
        ...newClientData,
        [parent]: {
          ...newClientData[parent],
          [child]: value
        }
      });
    } else {
      setNewClientData({
        ...newClientData,
        [name]: value
      });
    }
  };

  const handleCreateClient = async () => {
    try {
      setLoading(true);
      
      // Créer le client
      // const createdClient = await pennylaneService.createClient(newClientData);
      
      // Simuler la création
      const createdClient = {
        ...newClientData,
        id: `client${clients.length + 1}`
      };
      
      // Mettre à jour la liste des clients
      setClients([...clients, createdClient]);
      
      setShowNewClientDialog(false);
      setSnackbar({
        open: true,
        message: 'Client créé avec succès',
        severity: 'success'
      });
      
      setLoading(false);
    } catch (err) {
      setError('Erreur lors de la création du client: ' + err.message);
      setLoading(false);
    }
  };

  // Gestionnaires pour les factures
  const handleOpenNewInvoiceDialog = () => {
    setNewInvoiceData({
      clientId: '',
      date: new Date().toISOString().split('T')[0],
      dateEcheance: '',
      items: [
        {
          productId: '',
          description: '',
          quantite: 1,
          prixUnitaire: 0,
          tauxTVA: 20
        }
      ],
      conditionsPaiement: 'upon_receipt',
      notes: ''
    });
    setShowNewInvoiceDialog(true);
  };

  const handleCloseNewInvoiceDialog = () => {
    setShowNewInvoiceDialog(false);
  };

  const handleNewInvoiceChange = (e) => {
    const { name, value } = e.target;
    setNewInvoiceData({
      ...newInvoiceData,
      [name]: value
    });
  };

  const handleNewInvoiceItemChange = (index, field, value) => {
    const updatedItems = [...newInvoiceData.items];
    updatedItems[index][field] = value;
    
    // Si le produit change, mettre à jour la description et le prix
    if (field === 'productId') {
      const product = products.find(p => p.id === value);
      if (product) {
        updatedItems[index].description = product.description;
        updatedItems[index].prixUnitaire = product.prixUnitaire;
        updatedItems[index].tauxTVA = product.tauxTVA;
      }
    }
    
    setNewInvoiceData({
      ...newInvoiceData,
      items: updatedItems
    });
  };

  const handleAddInvoiceItem = () => {
    setNewInvoiceData({
      ...newInvoiceData,
      items: [
        ...newInvoiceData.items,
        {
          productId: '',
          description: '',
          quantite: 1,
          prixUnitaire: 0,
          tauxTVA: 20
        }
      ]
    });
  };

  const handleRemoveInvoiceItem = (index) => {
    const updatedItems = [...newInvoiceData.items];
    updatedItems.splice(index, 1);
    setNewInvoiceData({
      ...newInvoiceData,
      items: updatedItems
    });
  };

  const handleCreateInvoice = async () => {
    try {
      setLoading(true);
      
      // Créer la facture
      // const createdInvoice = await pennylaneService.createInvoice(newInvoiceData);
      
      // Simuler la création
      const client = clients.find(c => c.id === newInvoiceData.clientId);
      const montantHT = newInvoiceData.items.reduce((total, item) => total + (item.quantite * item.prixUnitaire), 0);
      const montantTTC = newInvoiceData.items.reduce((total, item) => total + (item.quantite * item.prixUnitaire * (1 + item.tauxTVA / 100)), 0);
      
      const createdInvoice = {
        id: `inv${invoices.length + 1}`,
        numero: `FACT-2025-${(invoices.length + 1).toString().padStart(3, '0')}`,
        clientId: newInvoiceData.clientId,
        client: { prenom: client.prenom, nom: client.nom },
        date: newInvoiceData.date,
        montantHT,
        montantTTC,
        statut: 'draft'
      };
      
      // Mettre à jour la liste des factures
      setInvoices([...invoices, createdInvoice]);
      
      setShowNewInvoiceDialog(false);
      setSnackbar({
        open: true,
        message: 'Facture créée avec succès',
        severity: 'success'
      });
      
      setLoading(false);
    } catch (err) {
      setError('Erreur lors de la création de la facture: ' + err.message);
      setLoading(false);
    }
  };

  // Gestionnaires pour les devis
  const handleOpenNewQuoteDialog = () => {
    setNewQuoteData({
      clientId: '',
      date: new Date().toISOString().split('T')[0],
      dateExpiration: '',
      items: [
        {
          productId: '',
          description: '',
          quantite: 1,
          prixUnitaire: 0,
          tauxTVA: 20
        }
      ],
      notes: ''
    });
    setShowNewQuoteDialog(true);
  };

  const handleCloseNewQuoteDialog = () => {
    setShowNewQuoteDialog(false);
  };

  const handleNewQuoteChange = (e) => {
    const { name, value } = e.target;
    setNewQuoteData({
      ...newQuoteData,
      [name]: value
    });
  };

  const handleNewQuoteItemChange = (index, field, value) => {
    const updatedItems = [...newQuoteData.items];
    updatedItems[index][field] = value;
    
    // Si le produit change, mettre à jour la description et le prix
    if (field === 'productId') {
      const product = products.find(p => p.id === value);
      if (product) {
        updatedItems[index].description = product.description;
        updatedItems[index].prixUnitaire = product.prixUnitaire;
        updatedItems[index].tauxTVA = product.tauxTVA;
      }
    }
    
    setNewQuoteData({
      ...newQuoteData,
      items: updatedItems
    });
  };

  const handleAddQuoteItem = () => {
    setNewQuoteData({
      ...newQuoteData,
      items: [
        ...newQuoteData.items,
        {
          productId: '',
          description: '',
          quantite: 1,
          prixUnitaire: 0,
          tauxTVA: 20
        }
      ]
    });
  };

  const handleRemoveQuoteItem = (index) => {
    const updatedItems = [...newQuoteData.items];
    updatedItems.splice(index, 1);
    setNewQuoteData({
      ...newQuoteData,
      items: updatedItems
    });
  };

  const handleCreateQuote = async () => {
    try {
      setLoading(true);
      
      // Créer le devis
      // const createdQuote = await pennylaneService.createQuote(newQuoteData);
      
      // Simuler la création
      const client = clients.find(c => c.id === newQuoteData.clientId);
      const montantHT = newQuoteData.items.reduce((total, item) => total + (item.quantite * item.prixUnitaire), 0);
      const montantTTC = newQuoteData.items.reduce((total, item) => total + (item.quantite * item.prixUnitaire * (1 + item.tauxTVA / 100)), 0);
      
      const createdQuote = {
        id: `quote${quotes.length + 1}`,
        numero: `DEVIS-2025-${(quotes.length + 1).toString().padStart(3, '0')}`,
        clientId: newQuoteData.clientId,
        client: { prenom: client.prenom, nom: client.nom },
        date: newQuoteData.date,
        montantHT,
        montantTTC,
        statut: 'pending'
      };
      
      // Mettre à jour la liste des devis
      setQuotes([...quotes, createdQuote]);
      
      setShowNewQuoteDialog(false);
      setSnackbar({
        open: true,
        message: 'Devis créé avec succès',
        severity: 'success'
      });
      
      setLoading(false);
    } catch (err) {
      setError('Erreur lors de la création du devis: ' + err.message);
      setLoading(false);
    }
  };

  // Gestionnaires pour les paiements
  const handleOpenPaymentDialog = (invoice) => {
    setSelectedItem(invoice);
    setPaymentData({
      date: new Date().toISOString().split('T')[0],
      montant: invoice.montantTTC,
      methodePaiement: 'bank_transfer',
      notes: ''
    });
    setShowPaymentDialog(true);
  };

  const handleClosePaymentDialog = () => {
    setShowPaymentDialog(false);
    setSelectedItem(null);
  };

  const handlePaymentChange = (e) => {
    const { name, value } = e.target;
    setPaymentData({
      ...paymentData,
      [name]: value
    });
  };

  const handleAddPayment = async () => {
    try {
      setLoading(true);
      
      // Enregistrer le paiement
      // await pennylaneService.markInvoiceAsPaid(selectedItem.id, paymentData);
      
      // Simuler l'enregistrement
      const updatedInvoices = invoices.map(invoice => 
        invoice.id === selectedItem.id 
          ? { ...invoice, statut: 'paid' } 
          : invoice
      );
      
      setInvoices(updatedInvoices);
      
      setShowPaymentDialog(false);
      setSelectedItem(null);
      setSnackbar({
        open: true,
        message: 'Paiement enregistré avec succès',
        severity: 'success'
      });
      
      setLoading(false);
    } catch (err) {
      setError('Erreur lors de l\'enregistrement du paiement: ' + err.message);
      setLoading(false);
    }
  };

  // Gestionnaires pour l'envoi d'emails
  const handleOpenSendEmailDialog = (item, type) => {
    setSelectedItem({ ...item, type });
    
    // Préparer les données d'email
    const client = clients.find(c => c.id === item.clientId);
    const emailSubject = type === 'invoice' 
      ? `Votre facture ${item.numero}` 
      : `Votre devis ${item.numero}`;
    const emailMessage = type === 'invoice'
      ? `Bonjour ${client.prenom},\n\nVeuillez trouver ci-joint votre facture ${item.numero} d'un montant de ${item.montantTTC}€.\n\nCordialement,\nL'équipe des bilans de compétences`
      : `Bonjour ${client.prenom},\n\nVeuillez trouver ci-joint votre devis ${item.numero} d'un montant de ${item.montantTTC}€.\n\nCordialement,\nL'équipe des bilans de compétences`;
    
    setEmailData({
      destinataire: client.email,
      sujet: emailSubject,
      message: emailMessage
    });
    
    setShowSendEmailDialog(true);
  };

  const handleCloseSendEmailDialog = () => {
    setShowSendEmailDialog(false);
    setSelectedItem(null);
  };

  const handleEmailChange = (e) => {
    const { name, value } = e.target;
    setEmailData({
      ...emailData,
      [name]: value
    });
  };

  const handleSendEmail = async () => {
    try {
      setLoading(true);
      
      // Envoyer l'email
      if (selectedItem.type === 'invoice') {
        // await pennylaneService.sendInvoiceByEmail(selectedItem.id, emailData);
      } else {
        // await pennylaneService.sendQuoteByEmail(selectedItem.id, emailData);
      }
      
      // Simuler l'envoi
      setShowSendEmailDialog(false);
      setSelectedItem(null);
      setSnackbar({
        open: true,
        message: 'Email envoyé avec succès',
        severity: 'success'
      });
      
      setLoading(false);
    } catch (err) {
      setError('Erreur lors de l\'envoi de l\'email: ' + err.message);
      setLoading(false);
    }
  };

  // Gestionnaire pour la conversion de devis en facture
  const handleConvertQuoteToInvoice = (quote) => {
    setConfirmDialog({
      open: true,
      title: 'Convertir en facture',
      message: `Êtes-vous sûr de vouloir convertir le devis ${quote.numero} en facture ?`,
      onConfirm: async () => {
        try {
          setLoading(true);
          
          // Convertir le devis en facture
          // const invoice = await pennylaneService.convertQuoteToInvoice(quote.id);
          
          // Simuler la conversion
          const newInvoice = {
            id: `inv${invoices.length + 1}`,
            numero: `FACT-2025-${(invoices.length + 1).toString().padStart(3, '0')}`,
            clientId: quote.clientId,
            client: quote.client,
            date: new Date().toISOString().split('T')[0],
            montantHT: quote.montantHT,
            montantTTC: quote.montantTTC,
            statut: 'pending'
          };
          
          // Mettre à jour les listes
          setInvoices([...invoices, newInvoice]);
          
          const updatedQuotes = quotes.map(q => 
            q.id === quote.id 
              ? { ...q, statut: 'accepted' } 
              : q
          );
          
          setQuotes(updatedQuotes);
          
          setConfirmDialog({ ...confirmDialog, open: false });
          setSnackbar({
            open: true,
            message: 'Devis converti en facture avec succès',
            severity: 'success'
          });
          
          setLoading(false);
        } catch (err) {
          setError('Erreur lors de la conversion du devis: ' + err.message);
          setLoading(false);
          setConfirmDialog({ ...confirmDialog, open: false });
        }
      }
    });
  };

  // Formater les montants
  const formatAmount = (amount) => {
    return new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(amount);
  };

  // Formater les dates
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('fr-FR');
  };

  // Rendu des statuts avec des puces colorées
  const renderInvoiceStatus = (status) => {
    let color, label;
    switch (status) {
      case 'paid':
        color = 'success';
        label = 'Payée';
        break;
      case 'pending':
        color = 'warning';
        label = 'En attente';
        break;
      case 'draft':
        color = 'default';
        label = 'Brouillon';
        break;
      default:
        color = 'default';
        label = status;
    }
    return <Chip label={label} color={color} size="small" />;
  };

  const renderQuoteStatus = (status) => {
    let color, label;
    switch (status) {
      case 'accepted':
        color = 'success';
        label = 'Accepté';
        break;
      case 'pending':
        color = 'warning';
        label = 'En attente';
        break;
      case 'rejected':
        color = 'error';
        label = 'Refusé';
        break;
      default:
        color = 'default';
        label = status;
    }
    return <Chip label={label} color={color} size="small" />;
  };

  return (
    <Container maxWidth="lg">
      <Box sx={{ my: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          Intégration Pennylane
        </Typography>
        
        {error && <ErrorAlert message={error} sx={{ mb: 3 }} />}
        
        {financialStats && (
          <Grid container spacing={3} sx={{ mb: 4 }}>
            <Grid item xs={12} md={4}>
              <Card>
                <CardContent>
                  <Typography variant="h6" gutterBottom>
                    Chiffre d'affaires
                  </Typography>
                  <Typography variant="h4" color="primary">
                    {formatAmount(financialStats.chiffreAffaires.total)}
                  </Typography>
                  <Typography variant="body2" color="textSecondary">
                    Ce mois-ci: {formatAmount(financialStats.chiffreAffaires.moisCourant)}
                    {financialStats.chiffreAffaires.evolution > 0 && (
                      <Chip 
                        label={`+${financialStats.chiffreAffaires.evolution}%`} 
                        color="success" 
                        size="small" 
                        sx={{ ml: 1 }} 
                      />
                    )}
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
            <Grid item xs={12} md={4}>
              <Card>
                <CardContent>
                  <Typography variant="h6" gutterBottom>
                    Factures
                  </Typography>
                  <Typography variant="h4" color="primary">
                    {financialStats.factures.total}
                  </Typography>
                  <Typography variant="body2" color="textSecondary">
                    Payées: {financialStats.factures.payees} | En attente: {financialStats.factures.enAttente}
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
            <Grid item xs={12} md={4}>
              <Card>
                <CardContent>
                  <Typography variant="h6" gutterBottom>
                    Devis
                  </Typography>
                  <Typography variant="h4" color="primary">
                    {financialStats.devis.total}
                  </Typography>
                  <Typography variant="body2" color="textSecondary">
                    Acceptés: {financialStats.devis.acceptes} | En attente: {financialStats.devis.enAttente}
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
        )}
        
        <Paper sx={{ width: '100%', mb: 4 }}>
          <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
            <Tabs value={tabValue} onChange={handleTabChange} aria-label="pennylane tabs">
              <Tab label="Factures" id="pennylane-tab-0" aria-controls="pennylane-tabpanel-0" />
              <Tab label="Devis" id="pennylane-tab-1" aria-controls="pennylane-tabpanel-1" />
              <Tab label="Clients" id="pennylane-tab-2" aria-controls="pennylane-tabpanel-2" />
            </Tabs>
          </Box>
          
          <TabPanel value={tabValue} index={0}>
            <Box sx={{ display: 'flex', justifyContent: 'flex-end', mb: 2 }}>
              <Button
                variant="contained"
                color="primary"
                startIcon={<AddIcon />}
                onClick={handleOpenNewInvoiceDialog}
              >
                Nouvelle facture
              </Button>
            </Box>
            
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>Numéro</TableCell>
                    <TableCell>Client</TableCell>
                    <TableCell>Date</TableCell>
                    <TableCell>Montant HT</TableCell>
                    <TableCell>Montant TTC</TableCell>
                    <TableCell>Statut</TableCell>
                    <TableCell align="right">Actions</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {loading ? (
                    <TableRow>
                      <TableCell colSpan={7} align="center">
                        <Loader size={30} />
                      </TableCell>
                    </TableRow>
                  ) : invoices.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={7} align="center">
                        Aucune facture trouvée
                      </TableCell>
                    </TableRow>
                  ) : (
                    invoices
                      .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                      .map((invoice) => (
                        <TableRow key={invoice.id}>
                          <TableCell>{invoice.numero}</TableCell>
                          <TableCell>{invoice.client.prenom} {invoice.client.nom}</TableCell>
                          <TableCell>{formatDate(invoice.date)}</TableCell>
                          <TableCell>{formatAmount(invoice.montantHT)}</TableCell>
                          <TableCell>{formatAmount(invoice.montantTTC)}</TableCell>
                          <TableCell>{renderInvoiceStatus(invoice.statut)}</TableCell>
                          <TableCell align="right">
                            <Tooltip title="Envoyer par email">
                              <IconButton
                                color="primary"
                                onClick={() => handleOpenSendEmailDialog(invoice, 'invoice')}
                              >
                                <SendIcon />
                              </IconButton>
                            </Tooltip>
                            {invoice.statut !== 'paid' && (
                              <Tooltip title="Enregistrer un paiement">
                                <IconButton
                                  color="success"
                                  onClick={() => handleOpenPaymentDialog(invoice)}
                                >
                                  <PaymentIcon />
                                </IconButton>
                              </Tooltip>
                            )}
                          </TableCell>
                        </TableRow>
                      ))
                  )}
                </TableBody>
              </Table>
            </TableContainer>
            
            <TablePagination
              component="div"
              count={invoices.length}
              page={page}
              onPageChange={handleChangePage}
              rowsPerPage={rowsPerPage}
              onRowsPerPageChange={handleChangeRowsPerPage}
              rowsPerPageOptions={[5, 10, 25]}
              labelRowsPerPage="Lignes par page :"
              labelDisplayedRows={({ from, to, count }) => 
                `${from}-${to} sur ${count !== -1 ? count : `plus de ${to}`}`
              }
            />
          </TabPanel>
          
          <TabPanel value={tabValue} index={1}>
            <Box sx={{ display: 'flex', justifyContent: 'flex-end', mb: 2 }}>
              <Button
                variant="contained"
                color="primary"
                startIcon={<AddIcon />}
                onClick={handleOpenNewQuoteDialog}
              >
                Nouveau devis
              </Button>
            </Box>
            
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>Numéro</TableCell>
                    <TableCell>Client</TableCell>
                    <TableCell>Date</TableCell>
                    <TableCell>Montant HT</TableCell>
                    <TableCell>Montant TTC</TableCell>
                    <TableCell>Statut</TableCell>
                    <TableCell align="right">Actions</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {loading ? (
                    <TableRow>
                      <TableCell colSpan={7} align="center">
                        <Loader size={30} />
                      </TableCell>
                    </TableRow>
                  ) : quotes.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={7} align="center">
                        Aucun devis trouvé
                      </TableCell>
                    </TableRow>
                  ) : (
                    quotes
                      .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                      .map((quote) => (
                        <TableRow key={quote.id}>
                          <TableCell>{quote.numero}</TableCell>
                          <TableCell>{quote.client.prenom} {quote.client.nom}</TableCell>
                          <TableCell>{formatDate(quote.date)}</TableCell>
                          <TableCell>{formatAmount(quote.montantHT)}</TableCell>
                          <TableCell>{formatAmount(quote.montantTTC)}</TableCell>
                          <TableCell>{renderQuoteStatus(quote.statut)}</TableCell>
                          <TableCell align="right">
                            <Tooltip title="Envoyer par email">
                              <IconButton
                                color="primary"
                                onClick={() => handleOpenSendEmailDialog(quote, 'quote')}
                              >
                                <SendIcon />
                              </IconButton>
                            </Tooltip>
                            {quote.statut === 'pending' && (
                              <Tooltip title="Convertir en facture">
                                <IconButton
                                  color="success"
                                  onClick={() => handleConvertQuoteToInvoice(quote)}
                                >
                                  <ReceiptIcon />
                                </IconButton>
                              </Tooltip>
                            )}
                          </TableCell>
                        </TableRow>
                      ))
                  )}
                </TableBody>
              </Table>
            </TableContainer>
            
            <TablePagination
              component="div"
              count={quotes.length}
              page={page}
              onPageChange={handleChangePage}
              rowsPerPage={rowsPerPage}
              onRowsPerPageChange={handleChangeRowsPerPage}
              rowsPerPageOptions={[5, 10, 25]}
              labelRowsPerPage="Lignes par page :"
              labelDisplayedRows={({ from, to, count }) => 
                `${from}-${to} sur ${count !== -1 ? count : `plus de ${to}`}`
              }
            />
          </TabPanel>
          
          <TabPanel value={tabValue} index={2}>
            <Box sx={{ display: 'flex', justifyContent: 'flex-end', mb: 2 }}>
              <Button
                variant="contained"
                color="primary"
                startIcon={<AddIcon />}
                onClick={handleOpenNewClientDialog}
              >
                Nouveau client
              </Button>
            </Box>
            
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>Nom</TableCell>
                    <TableCell>Email</TableCell>
                    <TableCell>Entreprise</TableCell>
                    <TableCell align="right">Actions</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {loading ? (
                    <TableRow>
                      <TableCell colSpan={4} align="center">
                        <Loader size={30} />
                      </TableCell>
                    </TableRow>
                  ) : clients.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={4} align="center">
                        Aucun client trouvé
                      </TableCell>
                    </TableRow>
                  ) : (
                    clients
                      .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                      .map((client) => (
                        <TableRow key={client.id}>
                          <TableCell>{client.prenom} {client.nom}</TableCell>
                          <TableCell>{client.email}</TableCell>
                          <TableCell>{client.entrepriseActuelle || '-'}</TableCell>
                          <TableCell align="right">
                            <Tooltip title="Créer une facture">
                              <IconButton
                                color="primary"
                                onClick={() => {
                                  setNewInvoiceData({
                                    ...newInvoiceData,
                                    clientId: client.id
                                  });
                                  setShowNewInvoiceDialog(true);
                                }}
                              >
                                <ReceiptIcon />
                              </IconButton>
                            </Tooltip>
                            <Tooltip title="Créer un devis">
                              <IconButton
                                color="secondary"
                                onClick={() => {
                                  setNewQuoteData({
                                    ...newQuoteData,
                                    clientId: client.id
                                  });
                                  setShowNewQuoteDialog(true);
                                }}
                              >
                                <DescriptionIcon />
                              </IconButton>
                            </Tooltip>
                          </TableCell>
                        </TableRow>
                      ))
                  )}
                </TableBody>
              </Table>
            </TableContainer>
            
            <TablePagination
              component="div"
              count={clients.length}
              page={page}
              onPageChange={handleChangePage}
              rowsPerPage={rowsPerPage}
              onRowsPerPageChange={handleChangeRowsPerPage}
              rowsPerPageOptions={[5, 10, 25]}
              labelRowsPerPage="Lignes par page :"
              labelDisplayedRows={({ from, to, count }) => 
                `${from}-${to} sur ${count !== -1 ? count : `plus de ${to}`}`
              }
            />
          </TabPanel>
        </Paper>
      </Box>
      
      {/* Dialogue pour créer un nouveau client */}
      <Dialog open={showNewClientDialog} onClose={handleCloseNewClientDialog} maxWidth="md" fullWidth>
        <DialogTitle>Nouveau client</DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Prénom"
                name="prenom"
                value={newClientData.prenom}
                onChange={handleNewClientChange}
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Nom"
                name="nom"
                value={newClientData.nom}
                onChange={handleNewClientChange}
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Email"
                name="email"
                type="email"
                value={newClientData.email}
                onChange={handleNewClientChange}
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Téléphone"
                name="telephone"
                value={newClientData.telephone}
                onChange={handleNewClientChange}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Adresse"
                name="adresse.rue"
                value={newClientData.adresse.rue}
                onChange={handleNewClientChange}
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <TextField
                fullWidth
                label="Code postal"
                name="adresse.codePostal"
                value={newClientData.adresse.codePostal}
                onChange={handleNewClientChange}
              />
            </Grid>
            <Grid item xs={12} md={8}>
              <TextField
                fullWidth
                label="Ville"
                name="adresse.ville"
                value={newClientData.adresse.ville}
                onChange={handleNewClientChange}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Entreprise"
                name="entrepriseActuelle"
                value={newClientData.entrepriseActuelle}
                onChange={handleNewClientChange}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="SIRET"
                name="siret"
                value={newClientData.siret}
                onChange={handleNewClientChange}
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseNewClientDialog}>Annuler</Button>
          <Button 
            onClick={handleCreateClient} 
            variant="contained" 
            color="primary"
            disabled={!newClientData.prenom || !newClientData.nom || !newClientData.email}
          >
            Créer
          </Button>
        </DialogActions>
      </Dialog>
      
      {/* Dialogue pour créer une nouvelle facture */}
      <Dialog open={showNewInvoiceDialog} onClose={handleCloseNewInvoiceDialog} maxWidth="md" fullWidth>
        <DialogTitle>Nouvelle facture</DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            <Grid item xs={12}>
              <FormControl fullWidth required>
                <InputLabel>Client</InputLabel>
                <Select
                  name="clientId"
                  value={newInvoiceData.clientId}
                  onChange={handleNewInvoiceChange}
                  label="Client"
                >
                  {clients.map((client) => (
                    <MenuItem key={client.id} value={client.id}>
                      {client.prenom} {client.nom} - {client.email}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Date"
                name="date"
                type="date"
                value={newInvoiceData.date}
                onChange={handleNewInvoiceChange}
                InputLabelProps={{ shrink: true }}
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Date d'échéance"
                name="dateEcheance"
                type="date"
                value={newInvoiceData.dateEcheance}
                onChange={handleNewInvoiceChange}
                InputLabelProps={{ shrink: true }}
              />
            </Grid>
            
            <Grid item xs={12}>
              <Typography variant="h6" gutterBottom sx={{ mt: 2 }}>
                Articles
              </Typography>
              
              {newInvoiceData.items.map((item, index) => (
                <Box key={index} sx={{ mb: 2, p: 2, border: '1px solid #e0e0e0', borderRadius: 1 }}>
                  <Grid container spacing={2}>
                    <Grid item xs={12}>
                      <FormControl fullWidth required>
                        <InputLabel>Produit</InputLabel>
                        <Select
                          value={item.productId}
                          onChange={(e) => handleNewInvoiceItemChange(index, 'productId', e.target.value)}
                          label="Produit"
                        >
                          {products.map((product) => (
                            <MenuItem key={product.id} value={product.id}>
                              {product.nom} - {formatAmount(product.prixUnitaire)}
                            </MenuItem>
                          ))}
                        </Select>
                      </FormControl>
                    </Grid>
                    <Grid item xs={12}>
                      <TextField
                        fullWidth
                        label="Description"
                        value={item.description}
                        onChange={(e) => handleNewInvoiceItemChange(index, 'description', e.target.value)}
                        multiline
                        rows={2}
                      />
                    </Grid>
                    <Grid item xs={12} md={4}>
                      <TextField
                        fullWidth
                        label="Quantité"
                        type="number"
                        value={item.quantite}
                        onChange={(e) => handleNewInvoiceItemChange(index, 'quantite', parseInt(e.target.value))}
                        InputProps={{ inputProps: { min: 1 } }}
                        required
                      />
                    </Grid>
                    <Grid item xs={12} md={4}>
                      <TextField
                        fullWidth
                        label="Prix unitaire (€)"
                        type="number"
                        value={item.prixUnitaire}
                        onChange={(e) => handleNewInvoiceItemChange(index, 'prixUnitaire', parseFloat(e.target.value))}
                        InputProps={{ inputProps: { min: 0, step: 0.01 } }}
                        required
                      />
                    </Grid>
                    <Grid item xs={12} md={4}>
                      <TextField
                        fullWidth
                        label="TVA (%)"
                        type="number"
                        value={item.tauxTVA}
                        onChange={(e) => handleNewInvoiceItemChange(index, 'tauxTVA', parseFloat(e.target.value))}
                        InputProps={{ inputProps: { min: 0, max: 100, step: 0.1 } }}
                        required
                      />
                    </Grid>
                    {newInvoiceData.items.length > 1 && (
                      <Grid item xs={12} sx={{ textAlign: 'right' }}>
                        <Button
                          color="error"
                          startIcon={<DeleteIcon />}
                          onClick={() => handleRemoveInvoiceItem(index)}
                        >
                          Supprimer
                        </Button>
                      </Grid>
                    )}
                  </Grid>
                </Box>
              ))}
              
              <Button
                variant="outlined"
                startIcon={<AddIcon />}
                onClick={handleAddInvoiceItem}
                sx={{ mt: 1 }}
              >
                Ajouter un article
              </Button>
            </Grid>
            
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Notes"
                name="notes"
                value={newInvoiceData.notes}
                onChange={handleNewInvoiceChange}
                multiline
                rows={3}
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseNewInvoiceDialog}>Annuler</Button>
          <Button 
            onClick={handleCreateInvoice} 
            variant="contained" 
            color="primary"
            disabled={!newInvoiceData.clientId || !newInvoiceData.date || newInvoiceData.items.some(item => !item.productId)}
          >
            Créer
          </Button>
        </DialogActions>
      </Dialog>
      
      {/* Dialogue pour créer un nouveau devis */}
      <Dialog open={showNewQuoteDialog} onClose={handleCloseNewQuoteDialog} maxWidth="md" fullWidth>
        <DialogTitle>Nouveau devis</DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            <Grid item xs={12}>
              <FormControl fullWidth required>
                <InputLabel>Client</InputLabel>
                <Select
                  name="clientId"
                  value={newQuoteData.clientId}
                  onChange={handleNewQuoteChange}
                  label="Client"
                >
                  {clients.map((client) => (
                    <MenuItem key={client.id} value={client.id}>
                      {client.prenom} {client.nom} - {client.email}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Date"
                name="date"
                type="date"
                value={newQuoteData.date}
                onChange={handleNewQuoteChange}
                InputLabelProps={{ shrink: true }}
                required
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Date d'expiration"
                name="dateExpiration"
                type="date"
                value={newQuoteData.dateExpiration}
                onChange={handleNewQuoteChange}
                InputLabelProps={{ shrink: true }}
              />
            </Grid>
            
            <Grid item xs={12}>
              <Typography variant="h6" gutterBottom sx={{ mt: 2 }}>
                Articles
              </Typography>
              
              {newQuoteData.items.map((item, index) => (
                <Box key={index} sx={{ mb: 2, p: 2, border: '1px solid #e0e0e0', borderRadius: 1 }}>
                  <Grid container spacing={2}>
                    <Grid item xs={12}>
                      <FormControl fullWidth required>
                        <InputLabel>Produit</InputLabel>
                        <Select
                          value={item.productId}
                          onChange={(e) => handleNewQuoteItemChange(index, 'productId', e.target.value)}
                          label="Produit"
                        >
                          {products.map((product) => (
                            <MenuItem key={product.id} value={product.id}>
                              {product.nom} - {formatAmount(product.prixUnitaire)}
                            </MenuItem>
                          ))}
                        </Select>
                      </FormControl>
                    </Grid>
                    <Grid item xs={12}>
                      <TextField
                        fullWidth
                        label="Description"
                        value={item.description}
                        onChange={(e) => handleNewQuoteItemChange(index, 'description', e.target.value)}
                        multiline
                        rows={2}
                      />
                    </Grid>
                    <Grid item xs={12} md={4}>
                      <TextField
                        fullWidth
                        label="Quantité"
                        type="number"
                        value={item.quantite}
                        onChange={(e) => handleNewQuoteItemChange(index, 'quantite', parseInt(e.target.value))}
                        InputProps={{ inputProps: { min: 1 } }}
                        required
                      />
                    </Grid>
                    <Grid item xs={12} md={4}>
                      <TextField
                        fullWidth
                        label="Prix unitaire (€)"
                        type="number"
                        value={item.prixUnitaire}
                        onChange={(e) => handleNewQuoteItemChange(index, 'prixUnitaire', parseFloat(e.target.value))}
                        InputProps={{ inputProps: { min: 0, step: 0.01 } }}
                        required
                      />
                    </Grid>
                    <Grid item xs={12} md={4}>
                      <TextField
                        fullWidth
                        label="TVA (%)"
                        type="number"
                        value={item.tauxTVA}
                        onChange={(e) => handleNewQuoteItemChange(index, 'tauxTVA', parseFloat(e.target.value))}
                        InputProps={{ inputProps: { min: 0, max: 100, step: 0.1 } }}
                        required
                      />
                    </Grid>
                    {newQuoteData.items.length > 1 && (
                      <Grid item xs={12} sx={{ textAlign: 'right' }}>
                        <Button
                          color="error"
                          startIcon={<DeleteIcon />}
                          onClick={() => handleRemoveQuoteItem(index)}
                        >
                          Supprimer
                        </Button>
                      </Grid>
                    )}
                  </Grid>
                </Box>
              ))}
              
              <Button
                variant="outlined"
                startIcon={<AddIcon />}
                onClick={handleAddQuoteItem}
                sx={{ mt: 1 }}
              >
                Ajouter un article
              </Button>
            </Grid>
            
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Notes"
                name="notes"
                value={newQuoteData.notes}
                onChange={handleNewQuoteChange}
                multiline
                rows={3}
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseNewQuoteDialog}>Annuler</Button>
          <Button 
            onClick={handleCreateQuote} 
            variant="contained" 
            color="primary"
            disabled={!newQuoteData.clientId || !newQuoteData.date || newQuoteData.items.some(item => !item.productId)}
          >
            Créer
          </Button>
        </DialogActions>
      </Dialog>
      
      {/* Dialogue pour enregistrer un paiement */}
      <Dialog open={showPaymentDialog} onClose={handleClosePaymentDialog} maxWidth="sm" fullWidth>
        <DialogTitle>Enregistrer un paiement</DialogTitle>
        <DialogContent>
          {selectedItem && (
            <Grid container spacing={2} sx={{ mt: 1 }}>
              <Grid item xs={12}>
                <Typography variant="subtitle1">
                  Facture: {selectedItem.numero}
                </Typography>
                <Typography variant="subtitle2" color="textSecondary">
                  Client: {selectedItem.client.prenom} {selectedItem.client.nom}
                </Typography>
                <Typography variant="h6" color="primary" sx={{ mt: 1 }}>
                  Montant: {formatAmount(selectedItem.montantTTC)}
                </Typography>
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Date du paiement"
                  name="date"
                  type="date"
                  value={paymentData.date}
                  onChange={handlePaymentChange}
                  InputLabelProps={{ shrink: true }}
                  required
                />
              </Grid>
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="Montant (€)"
                  name="montant"
                  type="number"
                  value={paymentData.montant}
                  onChange={handlePaymentChange}
                  InputProps={{ inputProps: { min: 0, step: 0.01 } }}
                  required
                />
              </Grid>
              <Grid item xs={12}>
                <FormControl fullWidth required>
                  <InputLabel>Méthode de paiement</InputLabel>
                  <Select
                    name="methodePaiement"
                    value={paymentData.methodePaiement}
                    onChange={handlePaymentChange}
                    label="Méthode de paiement"
                  >
                    <MenuItem value="bank_transfer">Virement bancaire</MenuItem>
                    <MenuItem value="credit_card">Carte bancaire</MenuItem>
                    <MenuItem value="check">Chèque</MenuItem>
                    <MenuItem value="cash">Espèces</MenuItem>
                    <MenuItem value="other">Autre</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Notes"
                  name="notes"
                  value={paymentData.notes}
                  onChange={handlePaymentChange}
                  multiline
                  rows={2}
                />
              </Grid>
            </Grid>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClosePaymentDialog}>Annuler</Button>
          <Button 
            onClick={handleAddPayment} 
            variant="contained" 
            color="primary"
            disabled={!paymentData.date || paymentData.montant <= 0}
          >
            Enregistrer
          </Button>
        </DialogActions>
      </Dialog>
      
      {/* Dialogue pour envoyer un email */}
      <Dialog open={showSendEmailDialog} onClose={handleCloseSendEmailDialog} maxWidth="md" fullWidth>
        <DialogTitle>Envoyer par email</DialogTitle>
        <DialogContent>
          {selectedItem && (
            <Grid container spacing={2} sx={{ mt: 1 }}>
              <Grid item xs={12}>
                <Typography variant="subtitle1">
                  {selectedItem.type === 'invoice' ? 'Facture' : 'Devis'}: {selectedItem.numero}
                </Typography>
                <Typography variant="subtitle2" color="textSecondary">
                  Client: {selectedItem.client.prenom} {selectedItem.client.nom}
                </Typography>
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Destinataire"
                  name="destinataire"
                  value={emailData.destinataire}
                  onChange={handleEmailChange}
                  required
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Sujet"
                  name="sujet"
                  value={emailData.sujet}
                  onChange={handleEmailChange}
                  required
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Message"
                  name="message"
                  value={emailData.message}
                  onChange={handleEmailChange}
                  multiline
                  rows={6}
                  required
                />
              </Grid>
            </Grid>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseSendEmailDialog}>Annuler</Button>
          <Button 
            onClick={handleSendEmail} 
            variant="contained" 
            color="primary"
            disabled={!emailData.destinataire || !emailData.sujet || !emailData.message}
          >
            Envoyer
          </Button>
        </DialogActions>
      </Dialog>
      
      <ConfirmDialog
        open={confirmDialog.open}
        title={confirmDialog.title}
        message={confirmDialog.message}
        onConfirm={confirmDialog.onConfirm}
        onCancel={() => setConfirmDialog({ ...confirmDialog, open: false })}
      />
      
      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
      >
        <Alert 
          onClose={() => setSnackbar({ ...snackbar, open: false })} 
          severity={snackbar.severity}
          sx={{ width: '100%' }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Container>
  );
};

export default PennylaneIntegration;
