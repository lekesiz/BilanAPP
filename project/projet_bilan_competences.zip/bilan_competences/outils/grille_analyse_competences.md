# Grille d'analyse des compétences

## Instructions pour le consultant

Cette grille d'analyse est un outil destiné au consultant pour structurer l'analyse approfondie des compétences du bénéficiaire lors de la phase d'investigation du bilan de compétences. Elle permet d'identifier, de catégoriser et d'évaluer les compétences acquises tout au long du parcours professionnel et personnel.

La grille doit être complétée par le consultant lors des entretiens, en se basant sur :
- Les déclarations du bénéficiaire
- L'analyse du parcours professionnel et des réalisations
- Les résultats du questionnaire d'auto-évaluation
- Les observations faites pendant les entretiens

## Grille d'analyse des compétences

### Identification du bénéficiaire
- Nom et prénom : 
- Date de l'analyse :
- Consultant référent :

### 1. Cartographie des compétences techniques

| Domaine de compétence | Compétences spécifiques | Niveau d'expertise (1-4) | Contexte d'acquisition | Fréquence d'utilisation | Transférabilité | Évolutivité |
|------------------------|--------------------------|--------------------------|------------------------|--------------------------|-----------------|-------------|
| | | | | | | |
| | | | | | | |
| | | | | | | |

**Légende :**
- Niveau d'expertise : 1 = Notions, 2 = Application, 3 = Maîtrise, 4 = Expert
- Fréquence d'utilisation : Rare, Occasionnelle, Régulière, Quotidienne
- Transférabilité : Faible, Moyenne, Élevée, Très élevée
- Évolutivité : Obsolescence, Stabilité, Développement, Forte demande

### 2. Analyse des compétences transversales

| Famille de compétences | Compétences identifiées | Niveau de maîtrise (1-4) | Contexte de mise en œuvre | Points forts observés | Axes d'amélioration |
|------------------------|--------------------------|--------------------------|---------------------------|------------------------|---------------------|
| **Cognitives** | | | | | |
| **Organisationnelles** | | | | | |
| **Relationnelles** | | | | | |
| **Adaptatives** | | | | | |
| **Managériales** | | | | | |

### 3. Analyse des compétences comportementales (soft skills)

| Compétence comportementale | Manifestations observées | Niveau (1-4) | Impact professionnel | Contextes favorables | Contextes défavorables |
|----------------------------|--------------------------|--------------|----------------------|----------------------|------------------------|
| | | | | | |
| | | | | | |
| | | | | | |

### 4. Compétences issues d'activités extra-professionnelles

| Activité | Compétences développées | Niveau (1-4) | Transférabilité professionnelle | Contextes de valorisation possibles |
|----------|--------------------------|--------------|----------------------------------|-------------------------------------|
| | | | | |
| | | | | |
| | | | | |

### 5. Analyse des motivations liées aux compétences

| Compétence | Niveau de satisfaction lors de l'utilisation (1-4) | Conditions optimales d'utilisation | Freins identifiés |
|------------|---------------------------------------------------|-----------------------------------|-------------------|
| | | | |
| | | | |
| | | | |

### 6. Synthèse des compétences clés

#### 6.1 Compétences distinctives
*Compétences qui différencient le bénéficiaire et constituent ses atouts majeurs*

1. 
2. 
3. 
4. 
5. 

#### 6.2 Compétences à développer
*Compétences à acquérir ou renforcer pour le projet professionnel envisagé*

1. 
2. 
3. 
4. 
5. 

#### 6.3 Compétences transférables
*Compétences mobilisables dans d'autres contextes professionnels*

1. 
2. 
3. 
4. 
5. 

### 7. Analyse de l'adéquation compétences/projet professionnel

| Projet envisagé | Compétences requises | Compétences acquises | Écart | Actions de développement proposées |
|-----------------|----------------------|----------------------|-------|-----------------------------------|
| | | | | |
| | | | | |
| | | | | |

### 8. Observations complémentaires du consultant

*Éléments qualitatifs d'analyse, observations sur le mode d'acquisition des compétences, particularités du profil, etc.*

...

### 9. Recommandations pour la phase de conclusion

*Pistes à explorer, points à approfondir, ressources à mobiliser*

...

---

Date de l'analyse : ________________

Consultant : ____________________

Signature : ________________________
