# Test de personnalité et d'intérêts professionnels

## Instructions pour le consultant

Ce document présente un test de personnalité et d'intérêts professionnels à utiliser lors de la phase d'investigation du bilan de compétences. Il s'agit d'un outil complémentaire aux entretiens et aux autres évaluations pour aider le bénéficiaire à mieux se connaître et à identifier des pistes professionnelles en adéquation avec sa personnalité.

Points importants à respecter :
- Préciser au bénéficiaire qu'il n'y a pas de bonnes ou mauvaises réponses
- Expliquer que ce test est un outil d'aide à la réflexion et non un outil de diagnostic définitif
- Prévoir un temps d'échange pour analyser les résultats avec le bénéficiaire
- Croiser les résultats avec les autres éléments du bilan de compétences

## Test à remettre au bénéficiaire

# TEST DE PERSONNALITÉ ET D'INTÉRÊTS PROFESSIONNELS

Ce test vous permettra de mieux comprendre votre personnalité, vos valeurs et vos intérêts professionnels. Il constitue un outil de réflexion qui sera analysé et approfondi lors de nos entretiens.

## Instructions
- Répondez spontanément aux questions
- Il n'y a pas de bonnes ou mauvaises réponses
- Choisissez la réponse qui vous correspond le mieux, même si parfois plusieurs réponses pourraient vous convenir
- Prenez votre temps pour répondre à toutes les questions

## Partie 1 : Traits de personnalité

Pour chaque paire d'affirmations, indiquez celle qui vous correspond le mieux en entourant la lettre correspondante.

1. **A.** Je préfère travailler en équipe et échanger des idées.
   **B.** Je préfère travailler seul(e) et me concentrer sur mes tâches.

2. **A.** J'aime planifier à l'avance et suivre un programme établi.
   **B.** Je préfère rester flexible et m'adapter aux circonstances.

3. **A.** Je prends mes décisions en analysant objectivement les faits.
   **B.** Je prends mes décisions en tenant compte des valeurs et des personnes concernées.

4. **A.** J'aime explorer de nouvelles idées et possibilités.
   **B.** Je préfère m'appuyer sur des méthodes éprouvées et concrètes.

5. **A.** Je suis généralement calme et posé(e), même sous pression.
   **B.** Je peux être tendu(e) et inquiet(ète) face aux défis importants.

6. **A.** Je m'exprime facilement et j'engage volontiers la conversation.
   **B.** Je suis plutôt réservé(e) et j'observe avant de m'exprimer.

7. **A.** Je préfère un environnement structuré avec des règles claires.
   **B.** Je préfère un environnement souple avec peu de contraintes.

8. **A.** Je me base sur la logique et l'analyse pour résoudre les problèmes.
   **B.** Je me fie à mon intuition et à mes valeurs pour trouver des solutions.

9. **A.** J'aime innover et remettre en question les méthodes établies.
   **B.** Je valorise la stabilité et les approches qui ont fait leurs preuves.

10. **A.** Je reste généralement optimiste face aux difficultés.
    **B.** J'ai tendance à anticiper les problèmes potentiels.

11. **A.** Je préfère être au centre de l'action et des interactions.
    **B.** Je préfère un environnement calme avec des interactions limitées.

12. **A.** J'apprécie quand tout est organisé et décidé à l'avance.
    **B.** J'aime garder mes options ouvertes et décider au dernier moment.

13. **A.** Je privilégie l'efficacité et les résultats concrets.
    **B.** Je privilégie l'harmonie et le bien-être des personnes.

14. **A.** Je m'intéresse aux concepts abstraits et aux possibilités futures.
    **B.** Je m'intéresse aux réalités concrètes et aux applications pratiques.

15. **A.** Je gère bien le stress et reste serein(e) face aux défis.
    **B.** Je peux être sensible au stress et aux pressions extérieures.

## Partie 2 : Intérêts professionnels

Pour chaque groupe d'activités, notez de 1 à 5 votre niveau d'intérêt (1 = aucun intérêt, 5 = très fort intérêt).

### Groupe A : Réaliste
___ Travailler avec des outils ou des machines
___ Construire ou réparer des objets
___ Travailler en plein air ou dans la nature
___ Pratiquer une activité physique dans le cadre professionnel
___ Résoudre des problèmes concrets et pratiques

### Groupe B : Investigateur
___ Analyser des données ou des informations
___ Faire des recherches ou des expériences
___ Résoudre des problèmes complexes
___ Étudier des phénomènes ou des systèmes
___ Explorer des idées nouvelles ou des théories

### Groupe C : Artistique
___ Créer des œuvres artistiques ou artisanales
___ Exprimer des idées de façon originale
___ Concevoir des designs ou des mises en page
___ Jouer d'un instrument ou chanter
___ Écrire des textes créatifs ou expressifs

### Groupe D : Social
___ Enseigner ou former des personnes
___ Aider les autres à résoudre leurs problèmes
___ Travailler en équipe sur des projets communs
___ Participer à des activités communautaires
___ Conseiller ou orienter des personnes

### Groupe E : Entreprenant
___ Diriger une équipe ou un projet
___ Vendre des produits ou des services
___ Négocier ou convaincre
___ Prendre des initiatives et des risques
___ Organiser des événements ou des activités

### Groupe F : Conventionnel
___ Suivre des procédures précises
___ Organiser et classer des informations
___ Travailler avec des chiffres ou des données
___ Vérifier l'exactitude de documents
___ Gérer des systèmes administratifs

## Partie 3 : Valeurs professionnelles

Classez les valeurs suivantes par ordre d'importance pour vous (de 1 à 10, 1 étant la plus importante).

___ Autonomie (liberté de décision et d'action)
___ Créativité (possibilité d'innover et d'exprimer ses idées)
___ Sécurité (stabilité de l'emploi et des revenus)
___ Reconnaissance (être valorisé(e) pour son travail)
___ Utilité sociale (contribuer au bien-être de la société)
___ Équilibre vie professionnelle/vie personnelle
___ Défi intellectuel (stimulation et apprentissage continu)
___ Rémunération (salaire et avantages matériels)
___ Pouvoir (influence et responsabilités)
___ Variété (diversité des tâches et des missions)

## Partie 4 : Environnement de travail idéal

Pour chaque paire d'options, choisissez celle qui correspond le mieux à vos préférences en entourant la lettre correspondante.

1. **A.** Un grand groupe avec beaucoup d'interactions sociales
   **B.** Une petite structure avec une ambiance familiale

2. **A.** Un environnement dynamique avec des changements fréquents
   **B.** Un cadre stable et prévisible

3. **A.** Un lieu de travail formel avec des codes établis
   **B.** Une atmosphère décontractée et informelle

4. **A.** Un travail principalement en équipe
   **B.** Un travail principalement individuel

5. **A.** Un rythme soutenu avec des délais serrés
   **B.** Un rythme modéré permettant d'approfondir les sujets

6. **A.** Un cadre urbain, au cœur de l'activité
   **B.** Un environnement calme, éloigné de l'agitation

7. **A.** Des horaires fixes et réguliers
   **B.** Des horaires flexibles ou variables

8. **A.** Un travail nécessitant des déplacements fréquents
   **B.** Un poste sédentaire, dans un lieu fixe

9. **A.** Un environnement compétitif, orienté résultats
   **B.** Un climat collaboratif, orienté processus

10. **A.** Un cadre hiérarchique clair et structuré
    **B.** Une organisation horizontale avec peu de niveaux hiérarchiques

## Partie 5 : Questions ouvertes

1. Décrivez une réalisation professionnelle ou personnelle dont vous êtes particulièrement fier(ère). Qu'est-ce qui vous a plu dans cette expérience ?

...

2. Quels sont les aspects de votre travail actuel (ou passé) que vous appréciez le plus ? Pourquoi ?

...

3. À l'inverse, quels sont les aspects que vous appréciez le moins ? Pourquoi ?

...

4. Si vous pouviez exercer n'importe quelle profession, sans contrainte de formation ou de rémunération, que choisiriez-vous ? Pourquoi ?

...

5. Quelles sont les compétences ou les activités que votre entourage reconnaît comme vos points forts ?

...

---

Date de remplissage : ________________

Nom et prénom : ____________________

Signature : ________________________

## Guide d'interprétation pour le consultant

### Partie 1 : Traits de personnalité
Cette section s'inspire du MBTI (Myers-Briggs Type Indicator) et évalue quatre dimensions de la personnalité :
- Questions 1, 6, 11 : Extraversion (A) vs Introversion (B)
- Questions 2, 7, 12 : Jugement (A) vs Perception (B)
- Questions 3, 8, 13 : Pensée (A) vs Sentiment (B)
- Questions 4, 9, 14 : Intuition (A) vs Sensation (B)
- Questions 5, 10, 15 : Stabilité émotionnelle (A) vs Réactivité émotionnelle (B)

### Partie 2 : Intérêts professionnels
Basée sur la typologie RIASEC de Holland :
- Groupe A : Réaliste (R) - Préférence pour les activités concrètes et pratiques
- Groupe B : Investigateur (I) - Goût pour l'analyse et la recherche
- Groupe C : Artistique (A) - Intérêt pour l'expression créative
- Groupe D : Social (S) - Attrait pour les relations d'aide et d'enseignement
- Groupe E : Entreprenant (E) - Orientation vers l'influence et la direction
- Groupe F : Conventionnel (C) - Préférence pour l'ordre et la méthode

Les trois groupes ayant obtenu les scores les plus élevés constituent le code RIASEC du bénéficiaire, à mettre en relation avec les familles de métiers correspondantes.

### Partie 3 : Valeurs professionnelles
Les valeurs classées en tête de liste sont déterminantes pour la satisfaction professionnelle à long terme. Elles doivent être prises en compte dans l'élaboration du projet professionnel.

### Partie 4 : Environnement de travail idéal
Ces préférences permettent d'identifier le type de structure et d'ambiance de travail qui conviendrait le mieux au bénéficiaire.

### Partie 5 : Questions ouvertes
Ces réponses fournissent des informations qualitatives précieuses sur les motivations profondes, les sources de satisfaction et les aspirations du bénéficiaire.

### Croisement des résultats
L'analyse croisée des différentes parties permet d'identifier :
- Les cohérences et incohérences entre personnalité, intérêts et valeurs
- Les pistes professionnelles à explorer en priorité
- Les environnements de travail à privilégier ou à éviter
- Les potentiels freins ou obstacles à la réalisation du projet professionnel
