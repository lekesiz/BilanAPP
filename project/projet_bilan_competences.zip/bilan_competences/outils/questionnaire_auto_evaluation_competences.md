# Questionnaire d'auto-évaluation des compétences

## Instructions pour le consultant

Ce questionnaire est à remettre au bénéficiaire lors de la phase d'investigation du bilan de compétences. Il permet d'identifier et d'évaluer les compétences techniques et transversales acquises tout au long du parcours professionnel et personnel.

Instructions à donner au bénéficiaire :
- Prenez le temps de réfléchir à chaque compétence listée
- Évaluez votre niveau pour chaque compétence sur une échelle de 1 à 4
- Ajoutez des exemples concrets d'utilisation de ces compétences
- Complétez la liste avec d'autres compétences que vous possédez
- N'hésitez pas à ajouter des commentaires pour nuancer vos réponses

## Questionnaire à remettre au bénéficiaire

# QUESTIONNAIRE D'AUTO-ÉVALUATION DES COMPÉTENCES

Ce questionnaire vous permet d'identifier et d'évaluer vos compétences professionnelles et personnelles. Il constitue une base de réflexion qui sera approfondie lors de nos entretiens.

## Échelle d'évaluation
1 = Notions de base / Débutant
2 = Niveau intermédiaire / Autonome sur des tâches simples
3 = Niveau avancé / Autonome sur des tâches complexes
4 = Expert / Capable de former d'autres personnes

## 1. Compétences techniques

### 1.1 Compétences liées à votre métier actuel ou principal

| Compétence technique | Niveau (1-4) | Exemple concret d'utilisation | Commentaires |
|----------------------|--------------|-------------------------------|--------------|
| | | | |
| | | | |
| | | | |
| | | | |
| | | | |

### 1.2 Compétences informatiques et numériques

| Compétence | Niveau (1-4) | Exemple concret d'utilisation | Commentaires |
|------------|--------------|-------------------------------|--------------|
| Bureautique (Word, Excel, etc.) | | | |
| Outils collaboratifs | | | |
| Réseaux sociaux professionnels | | | |
| Logiciels spécifiques | | | |
| Autres compétences numériques | | | |

### 1.3 Compétences linguistiques

| Langue | Niveau (1-4) | Contexte d'utilisation | Commentaires |
|--------|--------------|------------------------|--------------|
| Français | | | |
| Anglais | | | |
| Autre : | | | |
| Autre : | | | |

## 2. Compétences transversales

### 2.1 Compétences organisationnelles

| Compétence | Niveau (1-4) | Exemple concret d'utilisation | Commentaires |
|------------|--------------|-------------------------------|--------------|
| Gestion du temps | | | |
| Organisation du travail | | | |
| Planification de projets | | | |
| Gestion des priorités | | | |
| Résolution de problèmes | | | |
| Prise de décision | | | |

### 2.2 Compétences relationnelles

| Compétence | Niveau (1-4) | Exemple concret d'utilisation | Commentaires |
|------------|--------------|-------------------------------|--------------|
| Communication orale | | | |
| Communication écrite | | | |
| Travail en équipe | | | |
| Gestion des conflits | | | |
| Négociation | | | |
| Animation de réunions | | | |
| Capacité d'adaptation | | | |

### 2.3 Compétences managériales (si applicable)

| Compétence | Niveau (1-4) | Exemple concret d'utilisation | Commentaires |
|------------|--------------|-------------------------------|--------------|
| Leadership | | | |
| Délégation | | | |
| Motivation d'équipe | | | |
| Évaluation et feedback | | | |
| Développement des collaborateurs | | | |
| Gestion de projet | | | |

## 3. Autres compétences et talents

### 3.1 Compétences acquises dans le cadre d'activités extra-professionnelles

| Compétence | Niveau (1-4) | Contexte d'acquisition | Transférabilité professionnelle |
|------------|--------------|------------------------|----------------------------------|
| | | | |
| | | | |
| | | | |

### 3.2 Talents naturels et points forts

| Talent ou point fort | Comment se manifeste-t-il ? | Dans quels contextes ? |
|----------------------|----------------------------|------------------------|
| | | |
| | | |
| | | |

## 4. Analyse réflexive

### 4.1 Parmi toutes vos compétences, lesquelles vous procurent le plus de satisfaction lorsque vous les utilisez ?

...

### 4.2 Quelles compétences souhaiteriez-vous développer davantage ?

...

### 4.3 Quelles compétences vous semblent les plus transférables vers d'autres métiers ou secteurs ?

...

### 4.4 Y a-t-il des compétences que vous possédez mais que vous n'utilisez pas ou peu dans votre poste actuel ?

...

## 5. Compétences à développer

| Compétence à acquérir ou développer | Pourquoi cette compétence ? | Comment envisagez-vous de la développer ? |
|-------------------------------------|-----------------------------|--------------------------------------------|
| | | |
| | | |
| | | |

---

Date de remplissage : ________________

Nom et prénom : ____________________

Signature : ________________________
