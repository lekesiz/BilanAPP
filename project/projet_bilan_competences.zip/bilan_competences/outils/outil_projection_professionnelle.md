# Outil de projection professionnelle

## Instructions pour le consultant

Cet outil est destiné à être utilisé lors de la phase d'investigation du bilan de compétences, particulièrement dans sa dernière partie consacrée à l'élaboration et à la validation du projet professionnel. Il permet au bénéficiaire de structurer sa réflexion sur les différentes pistes professionnelles envisagées et d'évaluer leur pertinence et leur faisabilité.

Le consultant doit :
- Présenter l'outil au bénéficiaire et expliquer son objectif
- Accompagner le bénéficiaire dans l'identification des pistes professionnelles à explorer
- Guider la recherche d'informations sur ces pistes
- Aider à l'analyse objective des résultats
- Faciliter la prise de décision concernant le projet à retenir

## Outil à utiliser avec le bénéficiaire

# OUTIL DE PROJECTION PROFESSIONNELLE

Cet outil vous aidera à explorer, analyser et évaluer différentes pistes professionnelles afin de déterminer celle(s) qui correspond(ent) le mieux à votre profil, vos aspirations et votre situation.

## Partie 1 : Identification des pistes professionnelles

### 1.1 Pistes issues de l'analyse du parcours et des compétences

| Piste professionnelle | Compétences mobilisables | Expériences en lien | Intérêt pour cette piste (1-10) |
|------------------------|--------------------------|---------------------|--------------------------------|
| | | | |
| | | | |
| | | | |

### 1.2 Pistes issues des tests et questionnaires

| Piste suggérée par les tests | Test ou questionnaire source | Correspondance avec vos valeurs (1-10) | Intérêt pour cette piste (1-10) |
|------------------------------|------------------------------|----------------------------------------|--------------------------------|
| | | | |
| | | | |
| | | | |

### 1.3 Pistes issues de vos aspirations personnelles

| Aspiration ou rêve professionnel | Origine de cette aspiration | Obstacles potentiels | Intérêt pour cette piste (1-10) |
|----------------------------------|-----------------------------|-----------------------|--------------------------------|
| | | | |
| | | | |
| | | | |

## Partie 2 : Exploration des pistes retenues

Pour chaque piste professionnelle que vous souhaitez approfondir (3 maximum), complétez une fiche d'exploration.

### FICHE D'EXPLORATION - PISTE N°1

**Intitulé de la piste professionnelle :** _______________________________

#### 2.1 Recherche d'informations

| Source d'information | Informations clés recueillies | Date de consultation |
|----------------------|--------------------------------|----------------------|
| Fiches métier (préciser) | | |
| Sites spécialisés (préciser) | | |
| Entretiens avec des professionnels | | |
| Autres sources | | |

#### 2.2 Analyse du métier/secteur

**Description du métier/secteur :**
...

**Principales missions et activités :**
1. 
2. 
3. 
4. 
5. 

**Compétences requises :**
- Compétences techniques : 
- Compétences transversales : 
- Qualités personnelles : 

**Conditions d'exercice :**
- Environnement de travail : 
- Horaires et rythme : 
- Contraintes spécifiques : 
- Niveau de rémunération : 

**Évolutions possibles :**
...

#### 2.3 Analyse du marché de l'emploi

**État du marché :**
- Secteur en croissance, stable ou en déclin : 
- Nombre d'offres d'emploi identifiées : 
- Zones géographiques dynamiques : 
- Profils recherchés : 

**Modes d'accès :**
- Statut possible (salarié, indépendant, etc.) : 
- Réseaux professionnels à mobiliser : 
- Stratégies de candidature recommandées : 

#### 2.4 Formation nécessaire

**Formation requise :**
- Niveau de formation : 
- Diplômes ou certifications spécifiques : 
- Durée de la formation : 

**Options de formation :**
- Organismes de formation identifiés : 
- Modalités (présentiel, distanciel, alternance) : 
- Coût estimé : 
- Financement possible : 

### FICHE D'EXPLORATION - PISTE N°2

[Reproduire la même structure que pour la piste n°1]

### FICHE D'EXPLORATION - PISTE N°3

[Reproduire la même structure que pour la piste n°1]

## Partie 3 : Évaluation comparative des pistes

### 3.1 Tableau d'évaluation

Évaluez chaque piste selon les critères suivants (1 = très faible, 10 = très élevé) :

| Critères | Piste n°1 | Piste n°2 | Piste n°3 |
|----------|-----------|-----------|-----------|
| **Adéquation avec vos compétences actuelles** | | | |
| **Adéquation avec vos intérêts et valeurs** | | | |
| **Compatibilité avec vos contraintes personnelles** | | | |
| **Opportunités sur le marché de l'emploi** | | | |
| **Faisabilité à court/moyen terme** | | | |
| **Potentiel d'évolution et de développement** | | | |
| **Satisfaction anticipée** | | | |
| **Niveau de rémunération** | | | |
| **Équilibre vie professionnelle/vie personnelle** | | | |
| **TOTAL** | | | |

### 3.2 Analyse SWOT de la piste prioritaire

Pour la piste ayant obtenu le meilleur score, réalisez l'analyse suivante :

**Forces (internes, liées à vous) :**
1. 
2. 
3. 

**Faiblesses (internes, liées à vous) :**
1. 
2. 
3. 

**Opportunités (externes, liées à l'environnement) :**
1. 
2. 
3. 

**Menaces (externes, liées à l'environnement) :**
1. 
2. 
3. 

## Partie 4 : Plan d'action pour le projet retenu

### 4.1 Projet professionnel retenu

**Intitulé du projet :** _______________________________

**Description détaillée :**
...

**Objectifs à atteindre :**
1. 
2. 
3. 

### 4.2 Étapes de réalisation

| Étape | Actions à mener | Ressources nécessaires | Échéance | Indicateurs de réussite |
|-------|-----------------|------------------------|----------|-------------------------|
| | | | | |
| | | | | |
| | | | | |
| | | | | |
| | | | | |

### 4.3 Plan de formation (si nécessaire)

| Formation | Organisme | Durée | Coût | Financement | Dates |
|-----------|-----------|-------|------|-------------|-------|
| | | | | | |
| | | | | | |

### 4.4 Alternatives et plan B

**Alternative principale :**
...

**Conditions de mise en œuvre de l'alternative :**
...

### 4.5 Réseau à mobiliser

| Contact/Structure | Apport potentiel | Modalités de contact | Échéance |
|-------------------|------------------|----------------------|----------|
| | | | |
| | | | |
| | | | |

## Partie 5 : Validation finale du projet

### 5.1 Auto-évaluation de la motivation

Sur une échelle de 1 à 10, évaluez votre niveau de motivation pour ce projet : ____

Justifiez votre évaluation :
...

### 5.2 Validation par l'entourage

Avez-vous partagé ce projet avec votre entourage ? □ Oui □ Non

Si oui, quels retours avez-vous reçus ?
...

### 5.3 Engagement personnel

Quels engagements êtes-vous prêt(e) à prendre pour réaliser ce projet ?
...

Quels seraient les signes qui vous indiqueraient que vous êtes sur la bonne voie ?
...

---

Date de finalisation : ________________

Nom et prénom : ____________________

Signature : ________________________

## Guide d'utilisation pour le consultant

### Objectifs de l'outil
- Structurer l'exploration des pistes professionnelles
- Faciliter la prise de décision basée sur des critères objectifs
- Préparer un plan d'action réaliste et concret
- Renforcer l'engagement du bénéficiaire dans son projet

### Conseils d'utilisation
- Encourager le bénéficiaire à explorer au moins 2-3 pistes différentes
- Insister sur l'importance de la recherche d'informations concrètes
- Accompagner la réalisation des enquêtes métier
- Aider à l'analyse objective des avantages et inconvénients de chaque piste
- Veiller à ce que le plan d'action soit réaliste et échelonné dans le temps
- S'assurer que le bénéficiaire s'approprie pleinement le projet retenu

### Points de vigilance
- Éviter les projections basées uniquement sur des représentations idéalisées
- Vérifier la cohérence entre le projet et les contraintes personnelles du bénéficiaire
- S'assurer que le projet valorise les compétences clés identifiées
- Anticiper les obstacles potentiels et prévoir des stratégies pour les surmonter
- Prévoir systématiquement un plan B en cas de difficulté avec le projet principal
