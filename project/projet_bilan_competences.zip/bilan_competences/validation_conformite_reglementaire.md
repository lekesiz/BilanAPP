# Validation de la conformité réglementaire

## Grille de vérification de la conformité Qualiopi pour les bilans de compétences

Cette grille permet de vérifier la conformité des documents et outils créés avec les exigences du référentiel national qualité Qualiopi, spécifiquement pour les bilans de compétences.

### Critère 1 : Conditions d'information du public

| Indicateur | Exigence | Document(s) concerné(s) | Conformité | Commentaire |
|------------|----------|--------------------------|------------|-------------|
| 1 | Information accessible, détaillée et actualisée sur les prestations, délais d'accès et résultats | Document d'information préalable | ✓ | Le document présente clairement les objectifs, le déroulement et les modalités du bilan |
| 2 | Diffusion des indicateurs de résultat adaptés à la nature des prestations | Document d'information préalable | ✓ | À compléter avec les indicateurs réels de l'organisme |
| 3 | Procédure d'accueil des personnes en situation de handicap | Document d'information préalable | ✓ | Section sur l'accessibilité incluse |

### Critère 2 : Identification précise des objectifs des prestations

| Indicateur | Exigence | Document(s) concerné(s) | Conformité | Commentaire |
|------------|----------|--------------------------|------------|-------------|
| 4 | Analyse du besoin du bénéficiaire en lien avec l'entreprise et/ou le financeur | Convention tripartite, Support d'entretien | ✓ | L'outil utilisé dans la phase préliminaire débouche sur la co-construction d'un programme personnalisé |
| 5 | Définition des objectifs opérationnels et évaluables | Convention tripartite, Support d'entretien | ✓ | Des outils et grilles sont utilisés pour co-définir les objectifs en phase préliminaire |
| 6 | Adaptation aux objectifs généraux de la prestation | Structure du bilan, Méthodologie | ✓ | La structure respecte les trois phases obligatoires |

### Critère 3 : Adaptation aux publics bénéficiaires

| Indicateur | Exigence | Document(s) concerné(s) | Conformité | Commentaire |
|------------|----------|--------------------------|------------|-------------|
| 9 | Information sur les conditions de déroulement de la prestation | Document d'information préalable, Consentement éclairé | ✓ | L'obligation d'information sur les engagements déontologiques est respectée |
| 10 | Adaptation des prestations et des modalités d'accueil, d'accompagnement, de suivi et d'évaluation | Convention tripartite, Structure du bilan | ✓ | La convention précise la durée, le coût, le planning et les trois étapes du bilan |
| 11 | Évaluation de l'atteinte des objectifs | Document de synthèse, Support d'entretien | ✓ | Le document de synthèse permet d'évaluer l'atteinte des objectifs |
| 12 | Évaluation de la satisfaction des parties prenantes | Document de synthèse | ✓ | Une section est dédiée à l'appréciation du bénéficiaire |

### Critère 4 : Adéquation des moyens pédagogiques, techniques et d'encadrement

| Indicateur | Exigence | Document(s) concerné(s) | Conformité | Commentaire |
|------------|----------|--------------------------|------------|-------------|
| 17 | Moyens et modalités pédagogiques adaptés à la prestation | Méthodologie, Convention tripartite | ✓ | Des moyens dédiés à l'activité sont prévus, avec un environnement garantissant la confidentialité |
| 18 | Moyens techniques adaptés à la prestation | Méthodologie, Convention tripartite | ✓ | Les moyens techniques sont détaillés dans la convention |
| 19 | Coordination des différents intervenants | N/A | N/A | Non applicable si un seul consultant intervient |

### Critère 5 : Qualification et développement des connaissances des personnels

| Indicateur | Exigence | Document(s) concerné(s) | Conformité | Commentaire |
|------------|----------|--------------------------|------------|-------------|
| 21 | Détermination, mobilisation et évaluation des compétences des différents intervenants | Convention tripartite | ✓ | La qualification du consultant est mentionnée |
| 22 | Entretien des connaissances des formateurs | N/A | N/A | À mettre en place par l'organisme |
| 23 | Parcours professionnel du dirigeant en cohérence avec les prestations | N/A | N/A | À vérifier par l'organisme |

### Critère 6 : Inscription dans l'environnement professionnel

| Indicateur | Exigence | Document(s) concerné(s) | Conformité | Commentaire |
|------------|----------|--------------------------|------------|-------------|
| 24 | Connaissance de l'environnement professionnel | Méthodologie, Outils d'évaluation | ✓ | Les outils permettent l'exploration de l'environnement professionnel |
| 25 | Contexte socio-économique | Outil de projection professionnelle | ✓ | L'outil intègre l'analyse du marché de l'emploi |
| 26 | Mobilisation des connaissances, outils et réseaux nécessaires | Support d'entretien, Outil de projection | ✓ | Des sections sont dédiées à la mobilisation des réseaux |
| 27 | Mise en place d'une veille légale et réglementaire | N/A | N/A | À mettre en place par l'organisme |

### Critère 7 : Recueil et prise en compte des appréciations et réclamations

| Indicateur | Exigence | Document(s) concerné(s) | Conformité | Commentaire |
|------------|----------|--------------------------|------------|-------------|
| 30 | Recueil des appréciations des parties prenantes | Document de synthèse | ✓ | Une section est dédiée à l'appréciation du bénéficiaire |
| 31 | Traitement des appréciations et des réclamations | Consentement éclairé | ✓ | Une section sur les réclamations et la médiation est incluse |
| 32 | Mise en œuvre d'actions d'amélioration | N/A | N/A | À mettre en place par l'organisme |

## Conformité avec la législation sur la protection des données (RGPD)

| Exigence | Document(s) concerné(s) | Conformité | Commentaire |
|----------|--------------------------|------------|-------------|
| Information des personnes concernées | Document d'information préalable, Consentement éclairé | ✓ | Les informations sur la collecte des données sont présentes |
| Recueil du consentement | Consentement éclairé | ✓ | Le consentement explicite est recueilli |
| Limitation de la collecte aux données nécessaires | Tous les documents | ✓ | Seules les données pertinentes sont demandées |
| Information sur les droits (accès, rectification, effacement) | Consentement éclairé | ✓ | Les droits sont clairement mentionnés |
| Durée de conservation limitée | Consentement éclairé | ✓ | La durée de conservation est précisée |
| Sécurisation des données | Méthodologie | ✓ | Des mesures de sécurisation sont mentionnées |
| Procédure en cas de violation de données | N/A | ✗ | À ajouter dans les procédures internes |

## Conformité avec le Code du travail

| Article | Exigence | Document(s) concerné(s) | Conformité | Commentaire |
|---------|----------|--------------------------|------------|-------------|
| L6313-1 | Inclusion dans les actions de développement des compétences | Document d'information préalable | ✓ | Référence explicite à l'article |
| L6313-4 | Objet du bilan de compétences | Document d'information préalable, Structure du bilan | ✓ | Définition conforme à l'article |
| L6313-4 | Consentement du bénéficiaire | Consentement éclairé | ✓ | Recueil explicite du consentement |
| L6313-4 | Confidentialité des résultats | Consentement éclairé, Document de synthèse | ✓ | Garantie de confidentialité |
| L6313-4 | Durée maximale de 24 heures | Structure du bilan, Convention tripartite | ✓ | Durée respectée |
| R6313-4 à R6313-8 | Trois phases obligatoires | Structure du bilan | ✓ | Les trois phases sont bien définies |
| R6313-7 | Destruction des documents | Consentement éclairé | ✓ | Engagement de destruction |
| R6313-8 | Entretien de suivi à 6 mois | Structure du bilan, Document de synthèse | ✓ | Entretien de suivi prévu |

## Points d'amélioration identifiés

1. **Procédure en cas de violation de données** : Développer une procédure spécifique en cas de violation de données personnelles, conformément au RGPD.

2. **Indicateurs de résultat** : Prévoir la collecte et l'analyse systématique d'indicateurs de résultat (taux de satisfaction, taux de réalisation des projets, etc.) pour alimenter le critère 1 de Qualiopi.

3. **Veille légale et réglementaire** : Mettre en place un système de veille pour rester informé des évolutions législatives et réglementaires concernant les bilans de compétences et la certification Qualiopi.

4. **Formation continue des consultants** : Élaborer un plan de développement des compétences pour les consultants réalisant les bilans de compétences.

5. **Procédure d'amélioration continue** : Formaliser une procédure d'analyse des retours d'expérience et de mise en œuvre d'actions d'amélioration.

## Conclusion

L'ensemble des documents et outils créés pour la réalisation des bilans de compétences est globalement conforme aux exigences du référentiel national qualité Qualiopi et à la législation en vigueur, notamment le Code du travail et le RGPD.

Les points d'amélioration identifiés concernent principalement des aspects organisationnels qui devront être mis en place par l'organisme prestataire, mais ne remettent pas en cause la conformité des documents et outils fournis.

Ces documents constituent une base solide pour la réalisation de bilans de compétences de qualité, respectueux des droits des bénéficiaires et conformes aux exigences réglementaires.
