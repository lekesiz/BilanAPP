# Liste des tâches pour la réalisation de bilans de compétences conformes Qualiopi

## Recherche des exigences et de la législation
- [x] Rechercher les exigences Qualiopi spécifiques aux bilans de compétences
- [x] Identifier la législation en vigueur concernant les bilans de compétences
- [x] Comprendre le cadre légal du financement des bilans de compétences
- [x] Identifier les organismes certificateurs et leurs critères

## Création de la structure du bilan de compétences
- [x] Définir les phases obligatoires du bilan de compétences
- [x] Établir un calendrier type pour le déroulement du bilan
- [ ] Créer un modèle de convention tripartite
- [ ] Élaborer un modèle de synthèse finale conforme

## Élaboration d'une méthodologie conforme
- [x] Définir les méthodes d'investigation et d'évaluation
- [x] Créer un processus d'accompagnement personnalisé
- [x] Établir des protocoles de confidentialité
- [x] Définir les modalités de suivi post-bilan

## Création d'outils d'évaluation
- [x] Développer des questionnaires d'auto-évaluation
- [x] Créer des grilles d'analyse des compétences
- [x] Élaborer des tests de personnalité conformes
- [x] Concevoir des outils de projection professionnelle

## Préparation de la documentation client
- [x] Créer des documents d'information préalable
- [x] Élaborer des modèles de consentement éclairé
- [x] Développer des supports pour les entretiens
- [x] Préparer des modèles de rapports intermédiaires et finaux

## Validation de la conformité réglementaire
- [x] Vérifier la conformité avec les critères Qualiopi
- [x] S'assurer du respect de la législation sur la protection des données
- [x] Valider les procédures d'archivage et de conservation des documents
- [x] Confirmer les modalités de financement conformes
