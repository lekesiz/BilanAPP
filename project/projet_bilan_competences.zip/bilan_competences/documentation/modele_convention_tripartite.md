# Modèle de convention tripartite pour le bilan de compétences

## CONVENTION TRIPARTITE DE BILAN DE COMPÉTENCES

**Entre les soussignés :**

**L'organisme prestataire :**
- Raison sociale : ................................................................
- Adresse : ........................................................................
- SIRET : ...........................................................................
- Numéro de déclaration d'activité : ..........................................
- Certification Qualiopi n° : ...................................................
- Représenté par : ................................................................
- En qualité de : ..................................................................

Ci-après dénommé « l'organisme prestataire »

**Le bénéficiaire :**
- Nom et prénom : ................................................................
- Adresse : ........................................................................
- Téléphone : .....................................................................
- Email : ...........................................................................
- Date de naissance : ............................................................
- Fonction actuelle : .............................................................

Ci-après dénommé « le bénéficiaire »

**L'employeur (le cas échéant) :**
- Raison sociale : ................................................................
- Adresse : ........................................................................
- SIRET : ...........................................................................
- Représenté par : ................................................................
- En qualité de : ..................................................................

Ci-après dénommé « l'employeur »

**Il est convenu ce qui suit :**

### Article 1 : Objet de la convention

La présente convention a pour objet de définir les conditions de réalisation d'un bilan de compétences pour le bénéficiaire, conformément aux dispositions des articles L6313-1, L6313-4 et R6313-4 à R6313-8 du Code du travail.

### Article 2 : Nature et objectifs du bilan de compétences

Le bilan de compétences a pour objectif de permettre au bénéficiaire d'analyser ses compétences professionnelles et personnelles, ses aptitudes et ses motivations afin de définir un projet professionnel et, le cas échéant, un projet de formation.

Les objectifs spécifiques définis avec le bénéficiaire sont les suivants :
- ................................................................
- ................................................................
- ................................................................

### Article 3 : Contenu et déroulement du bilan de compétences

Le bilan de compétences comprend obligatoirement les trois phases suivantes :

**Phase préliminaire** (durée : .......... heures)
- Analyse de la demande et du besoin du bénéficiaire
- Détermination du format le plus adapté à la situation et au besoin
- Définition conjointe des modalités de déroulement du bilan

**Phase d'investigation** (durée : .......... heures)
- Analyse des compétences, aptitudes et motivations
- Construction du projet professionnel et vérification de sa pertinence
- Élaboration d'alternatives

**Phase de conclusions** (durée : .......... heures)
- Appropriation des résultats détaillés de la phase d'investigation
- Recensement des conditions et moyens favorisant la réalisation du projet
- Définition des étapes de mise en œuvre du projet

**Entretien de suivi à 6 mois** (durée : .......... heure)
- Évaluation de la mise en œuvre du projet
- Analyse des difficultés rencontrées
- Ajustement du plan d'action

### Article 4 : Moyens et méthodes mis en œuvre

L'organisme prestataire s'engage à mettre en œuvre les moyens suivants :

**Moyens humains :**
- Un consultant référent qualifié : ................................................................
- Qualification et expérience : ....................................................................

**Moyens techniques :**
- Locaux adaptés garantissant la confidentialité des échanges
- Ressources documentaires et outils numériques
- Tests et outils d'évaluation validés

**Méthodes :**
- Entretiens individuels
- Questionnaires d'auto-évaluation
- Tests psychométriques
- Recherches documentaires
- Enquêtes métier

### Article 5 : Organisation et calendrier

**Durée totale :** .......... heures réparties sur .......... semaines

**Lieu de réalisation :** ................................................................

**Modalités :** □ Présentiel □ Distanciel □ Mixte

**Calendrier prévisionnel :**
- Phase préliminaire : du ........................ au ........................
- Phase d'investigation : du ........................ au ........................
- Phase de conclusions : du ........................ au ........................
- Entretien de suivi : le ........................

### Article 6 : Conditions financières

**Coût total du bilan :** ........................ € HT, soit ........................ € TTC

**Modalités de financement :**
□ CPF
□ Plan de développement des compétences
□ France Travail
□ OPCO : ........................
□ Financement personnel
□ Autre : ........................

**Modalités de règlement :**
- Acompte de ........................ € à la signature de la convention
- Solde de ........................ € à l'issue du bilan

### Article 7 : Engagements des parties

**L'organisme prestataire s'engage à :**
- Respecter les dispositions légales et réglementaires relatives au bilan de compétences
- Mettre en œuvre l'ensemble des moyens nécessaires à la réalisation du bilan
- Garantir la confidentialité des informations recueillies
- Remettre au bénéficiaire un document de synthèse à l'issue du bilan

**Le bénéficiaire s'engage à :**
- Participer activement à l'ensemble des phases du bilan
- Fournir les informations nécessaires à la réalisation du bilan
- Respecter le calendrier établi
- Informer l'organisme prestataire de tout empêchement

**L'employeur (le cas échéant) s'engage à :**
- Permettre au bénéficiaire de suivre le bilan selon le calendrier établi
- Respecter la confidentialité des informations communiquées par le bénéficiaire

### Article 8 : Confidentialité

Les informations demandées au bénéficiaire doivent présenter un lien direct et nécessaire avec l'objet du bilan. Le bénéficiaire est tenu d'y répondre de bonne foi.

Le document de synthèse est remis exclusivement au bénéficiaire. Il ne peut être communiqué à un tiers qu'avec son accord explicite.

L'organisme prestataire s'engage à détruire l'ensemble des documents élaborés pour la réalisation du bilan dès son terme, à l'exception du document de synthèse qui pourra être conservé pendant un an avec l'accord écrit du bénéficiaire.

### Article 9 : Interruption du bilan

**En cas d'abandon par le bénéficiaire :**
- Pour cas de force majeure dûment reconnue : seules les prestations effectivement réalisées sont dues au prorata temporis de leur valeur prévue
- Pour un autre motif : l'organisme prestataire facturera les heures réalisées plus 30% du montant restant dû

**En cas d'annulation par l'organisme prestataire :**
- Pour cas de force majeure : report du bilan ou remboursement intégral des sommes versées
- Pour un autre motif : remboursement intégral des sommes versées et indemnité compensatoire de 10% du montant total

### Article 10 : Différends éventuels

Si une contestation ou un différend ne peut être réglé à l'amiable, le Tribunal de ........................ sera seul compétent pour régler le litige.

### Article 11 : Date d'effet et durée de la convention

La présente convention prend effet à compter de sa signature par les parties et prendra fin à l'issue de l'entretien de suivi à 6 mois.

Fait en trois exemplaires à ........................, le ........................

**Pour l'organisme prestataire :**
Signature et cachet

**Le bénéficiaire :**
Signature

**Pour l'employeur (le cas échéant) :**
Signature et cachet
