#!/usr/bin/env node

/**
 * Script pour initialiser la base de données avec des utilisateurs de test
 */

const sequelize = require('../config/database');
const { User } = require('../models');
const bcrypt = require('bcrypt');

async function initializeDatabase() {
  try {
    // Synchroniser les modèles avec la base de données (force: true pour recréer les tables)
    await sequelize.sync({ force: true });
    console.log('Base de données synchronisée avec succès (tables recréées).');

    // Créer des utilisateurs de test
    const saltRounds = 10;
    const consultantPassword = await bcrypt.hash('consultant123', saltRounds);
    const beneficiaryPassword = await bcrypt.hash('beneficiary123', saltRounds);
    
    // Créer un consultant de test
    await User.create({
      email: 'consultant@test.com',
      password: consultantPassword,
      firstName: 'Jean',
      lastName: 'Dupont',
      userType: 'consultant'
    });
    
    // Créer un bénéficiaire de test
    await User.create({
      email: 'beneficiaire@test.com',
      password: beneficiaryPassword,
      firstName: 'Marie',
      lastName: 'Martin',
      userType: 'beneficiary'
    });
    
    console.log('Utilisateurs de test créés avec succès !');
    console.log('Consultant: consultant@test.com / consultant123');
    console.log('Bénéficiaire: beneficiaire@test.com / beneficiary123');
    
    console.log('Initialisation terminée avec succès.');
    process.exit(0);
  } catch (error) {
    console.error('Erreur lors de l\'initialisation de la base de données:', error);
    process.exit(1);
  }
}

// Exécuter la fonction d'initialisation
initializeDatabase();
