const express = require('express');
const router = express.Router();
const passport = require('passport');
const { ensureAuthenticated } = require('../middlewares/auth');

// Page de connexion
router.get('/login', (req, res) => {
  if (req.isAuthenticated()) {
    return res.redirect('/dashboard');
  }
  res.render('auth/login', { 
    title: 'Connexion',
    layout: 'auth'
  });
});

// Traitement de la connexion
router.post('/login', passport.authenticate('local', {
  successRedirect: '/dashboard',
  failureRedirect: '/auth/login',
  failureFlash: true
}));

// Déconnexion
router.get('/logout', ensureAuthenticated, (req, res, next) => {
  req.logout(function(err) {
    if (err) { return next(err); }
    req.flash('success_msg', 'Vous êtes déconnecté');
    res.redirect('/');
  });
});

module.exports = router;
